#include <stdio.h>
#include <string.h>

/* gcc -Wl,-z,relro,-z,now -no-pie -fno-stack-protector chall.c -o chall */

void win(int mantra)
{
    puts("noice!");
    FILE *f = fopen("flag.txt", "r");
    if (f == NULL)
    {
        printf("File flag.txt does not exist! >:(");
        return ;
    }
    char flag[0x100];
    fgets(flag, 0x100, f);
    puts(flag);
}

void vuln()
{
    char buff[32];

    read(0, buff, 0x200);

    puts("buru-buru dibuat :V\n");
}

int main()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    vuln();
    puts("yah, jelek...");
    return 0;
}