// gcc -Os -o chall chall.c -l:libseccomp.a

#include <seccomp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char *buf = NULL;
    size_t n = 0;
    while (1)
    {
        printf("Gamma ray? ");
        size_t len = getline(&buf, &n, stdin);
        buf[len - 1] = '\0';
        if (strcmp(buf, "no") == 0)
        {
            free(buf);
            return 0;
        }
        else
        {
            printf(buf);
        }
        printf("\n");
    }
}

void __attribute__((constructor)) init()
{
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);

    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_KILL);
    if (ctx == NULL)
    {
        perror("seccomp_init failed");
        exit(1);
    }

    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(getdents), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(getdents64), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(openat), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0);

    if (seccomp_load(ctx) < 0)
    {
        perror("seccomp_load failed");
        seccomp_release(ctx);
        exit(1);
    }

    seccomp_release(ctx);
}
