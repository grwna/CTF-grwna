// gcc -no-pie -o chall chall.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    size_t price;
    char *title;
    char *description;
} Wish;

Wish wishlist[100]; // surely you don't have > 100 wishlists, right?
int count = 0;

int readint()
{
    char buf[24];
    fgets(buf, 24, stdin);
    return atoi(buf);
}

void add_wish()
{
    Wish *wish = &wishlist[count++];
    size_t n = 0;
    printf("Title: ");
    getline(&wish->title, &n, stdin);
    printf("Description: ");
    getline(&wish->description, &n, stdin);
    printf("Price: ");
    scanf("%zu%*c", &wish->price);
    printf("\n");
    printf("Wish added\n");
}

void view_wishlist()
{
    if (count <= 0)
    {
        printf("No wishes yet\n");
        return;
    }
    printf("Wishlist:\n");
    for (size_t i = 0; i < count; i++)
    {
        printf("%zu. %s", i + 1, wishlist[i].title);
    }
    printf("\n");
    printf("See more details? [y/n] ");
    char c;
    scanf("%c%*c", &c);
    if (c == 'y' || c == 'Y')
    {
        printf("Index (1-%zu): ", count);
        int index = readint() - 1;
        if (index < count)
        {
            printf("\n");
            printf("Title: %s", wishlist[index].title);
            printf("Price: %zu\n", wishlist[index].price);
            printf("Description: %s", wishlist[index].description);
        }
        else
        {
            printf("\n");
            printf("Invalid index\n");
        }
    }
}

void edit_wish()
{
    if (count <= 0)
    {
        printf("No wishes yet\n");
        return;
    }
    printf("Index (1-%zu): ", count);
    int index = readint() - 1;
    if (index < count)
    {
        Wish *wish = &wishlist[index];
        size_t n = 0;
        printf("Title: ");
        getline(&wish->title, &n, stdin);
        printf("Description: ");
        getline(&wish->description, &n, stdin);
        printf("Price: ");
        scanf("%zu%*c", &wish->price);
        printf("\n");
        printf("Wish updated\n");
    }
    else
    {

        printf("\n");
        printf("Invalid index\n");
    }
}

void delete_wish()
{
    if (count <= 0)
    {
        printf("No wishes yet\n");
        return;
    }
    printf("Index (1-%zu): ", count);
    int index = readint() - 1;
    if (index < count)
    {
        free(wishlist[index].title);
        free(wishlist[index].description);
        for (size_t i = index; i < count; i++)
        {
            __builtin_memcpy(&wishlist[i], &wishlist[i + 1], sizeof(Wish));
        }
        count--;
        printf("\n");
        printf("Wish deleted\n");
    }
    else
    {
        printf("\n");
        printf("Invalid index\n");
    }
}

int main()
{
    while (1)
    {
        printf("Menu:\n"
               "1. Add wish\n"
               "2. View wishlist\n"
               "3. Edit wish\n"
               "4. Delete wish\n"
               "> ");

        int choice = readint();

        printf("\n");

        switch (choice)
        {
        case 1:
            add_wish();
            break;
        case 2:
            view_wishlist();
            break;
        case 3:
            edit_wish();
            break;
        case 4:
            delete_wish();
            break;
        default:
            printf("Invalid choice\n");
        }

        printf("\n");
    }
    return 0;
}

void __attribute__((constructor)) init()
{
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

void __attribute__((destructor)) cleanup()
{
    for (size_t i = 0; i < 100; i++)
    {
        if (wishlist[i].title != NULL)
        {
            free(wishlist[i].title);
        }
        if (wishlist[i].description != NULL)
        {
            free(wishlist[i].description);
        }
    }
}
