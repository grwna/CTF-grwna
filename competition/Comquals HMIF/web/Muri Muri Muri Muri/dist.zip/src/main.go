package main

import (
	"net/http"
)

func main() {
	r := MakeRouter()

	// Order of middleware is important for the vulnerability
	r.UseMiddleware(logMiddleware)
	// r.UseMiddleware(sessionMiddleware)
	r.UseMiddleware(antiXSS)
	r.UseMiddleware(cspProtection)

	r.Get("/", http.HandlerFunc(indexView))

	r.Get("/flag", adminOnly, http.HandlerFunc(flagHandler))

	r.Get("/login", http.HandlerFunc(loginHandler))
	r.Post("/admin", http.HandlerFunc(adminLoginHandler))
	r.Get("/logout", http.HandlerFunc(logoutHandler))

	http.ListenAndServe(":8080", r)
}
