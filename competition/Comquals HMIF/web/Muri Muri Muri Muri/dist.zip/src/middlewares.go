package main

import (
	"log"
	"net/http"
	"sync"
	"time"
)

var (
	sessions     = make(map[string]Session)
	sessionMutex sync.RWMutex
)

type Session struct {
	Username  string
	IsAdmin   bool
	LastCheck time.Time
}

func sessionMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		cookie, err := r.Cookie("session")
		if err != nil {
			next.ServeHTTP(w, r)
			return
		}

		// Race condition vulnerability: Read without lock
		session, exists := sessions[cookie.Value]
		if !exists {
			next.ServeHTTP(w, r)
			return
		}

		// Vulnerable time check - can be exploited
		if time.Since(session.LastCheck) > 5*time.Second {
			// Lock only for write - creates race window
			sessionMutex.Lock()
			delete(sessions, cookie.Value)
			sessionMutex.Unlock()
			next.ServeHTTP(w, r)
			return
		}

		// Update last check time - another race window
		go func() {
			sessionMutex.Lock()
			if s, ok := sessions[cookie.Value]; ok {
				s.LastCheck = time.Now()
				sessions[cookie.Value] = s
			}
			sessionMutex.Unlock()
		}()

		next.ServeHTTP(w, r)
	})
}

func adminOnly(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusUnauthorized)
	})
}

func logMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		next.ServeHTTP(w, r)
		duration := time.Since(start)
		log.Printf("%s %s %v", r.Method, r.URL.Path, duration)
	})
}

func antiXSS(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-XSS-Protection", "1; mode=block")
		next.ServeHTTP(w, r)
	})
}

func cspProtection(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Security-Policy", "default-src 'self'")
		next.ServeHTTP(w, r)
	})
}
