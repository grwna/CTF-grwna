package main

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"net/http"
	"os"
	"time"
)

func generateSessionID() string {
	b := make([]byte, 16)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	html := `
    <form action="/admin" method="POST">
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <input type="submit" value="Login">
    </form>
    `
	w.Write([]byte(html))
}

func adminLoginHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	username := r.FormValue("username")
	password := r.FormValue("password")

	// Hardcoded credentials for CTF
	if username == "admin" && password == "supersecret" {
		sessionID := generateSessionID()

		// Vulnerable session creation - race window
		sessionMutex.Lock()
		sessions[sessionID] = Session{
			Username:  username,
			IsAdmin:   true,
			LastCheck: time.Now(),
		}
		sessionMutex.Unlock()

		http.SetCookie(w, &http.Cookie{
			Name:  "session",
			Value: sessionID,
		})

		w.Write([]byte("Login successful! Try to get the flag at /flag"))
		return
	}

	w.WriteHeader(http.StatusUnauthorized)
}

func logoutHandler(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session")
	if err == nil {
		sessionMutex.Lock()
		delete(sessions, cookie.Value)
		sessionMutex.Unlock()
	}
	http.SetCookie(w, &http.Cookie{
		Name:   "session",
		Value:  "",
		MaxAge: -1,
	})
	w.Write([]byte("Logged out"))
}

func indexView(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("testing"))
}

func flagHandler(w http.ResponseWriter, r *http.Request) {
	flag := os.Getenv("FLAG")
	if flag == "" {
		flag = "CTFITB{fake-flag}"
	}
	fmt.Println("SOMEONE GOT THE FLAG!!!")
	w.Write([]byte(flag))
}
