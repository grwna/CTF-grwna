CREATE TABLE IF NOT EXISTS "users" (
    user_id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    -- role VARCHAR(12) CHECK (role IN ('jobseeker', 'company')) NOT NULL,
    role VARCHAR(12) NOT NULL,
    name VARCHAR(255) NOT NULL,
    username VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS "company_detail" (
    user_id INT REFERENCES "users"(user_id) ON DELETE CASCADE,
    location VARCHAR(255) NOT NULL,
    about TEXT,
    PRIMARY KEY (user_id)
);

CREATE TABLE IF NOT EXISTS "job_vacancies" (   
    vacancy_id SERIAL PRIMARY KEY,
    company_id INT REFERENCES "users"(user_id) ON DELETE CASCADE,
    position VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    job_type VARCHAR(255),
    location_type VARCHAR(255),
    is_open BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    count INT
);

CREATE TABLE IF NOT EXISTS "vacancy_attachments" (
    attachment_id SERIAL PRIMARY KEY,
    vacancy_id INT REFERENCES "job_vacancies"(vacancy_id) ON DELETE CASCADE,
    file_path VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS "applications" (
    application_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES "users"(user_id) ON DELETE CASCADE,
    vacancy_id INT REFERENCES "job_vacancies"(vacancy_id) ON DELETE CASCADE,
    cv_path VARCHAR(255) NOT NULL,
    video_path VARCHAR(255),
    status VARCHAR(10) CHECK (status IN ('accepted', 'rejected', 'waiting')) DEFAULT 'waiting',
    status_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);