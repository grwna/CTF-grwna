#!/bin/bash

# Execute the PHP script after PostgreSQL is ready
php /var/www/html/startup-script.php

# Start Apache in the foreground
apache2-foreground