<?php

require_once __DIR__."/config/db.php";

// get db connection
$db = dbConnect();

/**
 * Seeding table users
 */
// Prepare and bind the SQL statement
$query = "INSERT INTO users (email, password, role, name, username) VALUES (:email, :password, :role, :name, :username)";
$stmt = $db->prepare($query);


// User data
$users = [
    ['john.doe@email.com', 'password123', 'jobseeker', 'John Doe', 'john_doe'],
    ['jane.smith@email.com', 'password123', 'company', 'Jane Smith', 'jane_smith'],
    ['mark.johnson@email.com', 'password123', 'jobseeker', 'Mark Johnson', 'mark_johnson'],
    ['emily.davis@email.com', 'password123', 'company', 'Emily Davis', 'emily_davis'],
    ['susan.brown@email.com', 'password123', 'jobseeker', 'Susan Brown', 'susan_brown'],
    ['michael.jones@email.com', 'password123', 'company', 'Michael Jones', 'michael_jones'],
    ['daniel.garcia@email.com', 'password123', 'jobseeker', 'Daniel Garcia', 'daniel_garcia'],
    ['laura.martinez@email.com', 'password123', 'company', 'Laura Martinez', 'laura_martinez'],
    ['david.anderson@email.com', 'password123', 'jobseeker', 'David Anderson', 'david_anderson'],
    ['rachel.lee@email.com', 'password123', 'company', 'Rachel Lee', 'rachel_lee'],
    ['jessica.wilson@email.com', 'password123', 'jobseeker', 'Jessica Wilson', 'jessica_wilson'],
    ['chris.moore@email.com', 'password123', 'company', 'Chris Moore', 'chris_moore'],
    ['paul.taylor@email.com', 'password123', 'jobseeker', 'Paul Taylor', 'paul_taylor'],
    ['hannah.thomas@email.com', 'password123', 'company', 'Hannah Thomas', 'hannah_thomas'],
    ['sarah.white@email.com', 'password123', 'jobseeker', 'Sarah White', 'sarah_white'],
    ['kevin.hall@email.com', 'password123', 'company', 'Kevin Hall', 'kevin_hall'],
    ['alex.clark@email.com', 'password123', 'jobseeker', 'Alex Clark', 'alex_clark'],
    ['emma.walker@email.com', 'password123', 'company', 'Emma Walker', 'emma_walker'],
    ['jacob.young@email.com', 'password123', 'jobseeker', 'Jacob Young', 'jacob_young'],
    ['olivia.harris@email.com', 'password123', 'company', 'Olivia Harris', 'olivia_harris'],
    ['edbert@email.com', 'edbert', 'jobseeker', 'Edbert Eddyson Gunawan', 'edbert'],
    ['edbert-corp@email.com', 'edcorp', 'company', '@BIRD - CORP', 'edcorp'],
    ['denise@email.com', 'denise', 'jobseeker', 'Denise Felicia Tiowanni', 'denise'],
    ['andhita@email.com', 'andhita', 'jobseeker', 'Andhita Naura Hariyanto', 'andhita'],
    ['[REDACTED]', '[REDACTED]', '[REDACTED]', '[REDACTED]', '[REDACTED]']
];

// Loop through each user and insert into the database
foreach ($users as $user) {
    $email = $user[0];
    $hashedPassword = password_hash($user[1], PASSWORD_BCRYPT);  // Hash the password
    $role = $user[2];
    $name = $user[3];
    $username = $user[4];

    // Bind parameters
    $stmt->bindParam(":email", $email);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':role', $role);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':username', $username);
    
    // Execute the prepared statement
    $stmt->execute();
}

/**
 * Seeding table company_detail
 */
$query = "INSERT INTO company_detail (user_id, location, about) VALUES (:user_id, :location, :about)";
$stmt = $db->prepare($query);

// Company details data
$companyDetails = [
    [2, 'New York, NY', 'Jane Smith runs a tech consulting company specializing in software solutions.'],
    [4, 'Los Angeles, CA', 'Emily Davis is the CEO of a media and advertising firm.'],
    [6, 'Chicago, IL', 'Michael Jones is leading an innovative AI startup in healthcare.'],
    [8, 'Miami, FL', 'Laura Martinez owns a construction and engineering company.'],
    [10, 'San Francisco, CA', 'Rachel Lee manages a leading fintech company in Silicon Valley.'],
    [12, 'Seattle, WA', 'Chris Moore heads a cloud services and data management company.'],
    [14, 'Dallas, TX', 'Hannah Thomas runs a renewable energy and green tech company.'],
    [16, 'Austin, TX', 'Kevin Hall operates a blockchain technology firm focused on smart contracts.'],
    [18, 'Denver, CO', 'Emma Walker leads a cybersecurity company that protects financial institutions.'],
    [20, 'Boston, MA', 'Olivia Harris is the CEO of a biotech firm focused on cancer research.'],
    [22, 'Balikpapan', 'Testing Doang si HEHEHEH']
];

// Insert company details
foreach ($companyDetails as $detail) {
    $stmt->bindParam(':user_id', $detail[0]);
    $stmt->bindParam(':location', $detail[1]);
    $stmt->bindParam(':about', $detail[2]);
    $stmt->execute();
}

/**
 * Seeding table job_vacancies
 */
$query = "INSERT INTO job_vacancies (company_id, position, description, job_type, location_type, is_open, count) VALUES (:company_id, :position, :description, :job_type, :location_type, :is_open, :count)";
$stmt = $db->prepare($query);

// Job vacancies data
$jobVacancies = [
    [2, 'Software Engineer', 'Develop and maintain scalable web applications.', 'Full-time', 'On-site', false],
    [2, 'UI/UX Designer', 'Design intuitive user interfaces for mobile and web applications.', 'Part-time', 'Remote', true],
    [4, 'Marketing Manager', 'Oversee marketing strategies and campaigns.', 'Full-time', 'On-site', false],
    [4, 'Content Creator', 'Create engaging multimedia content for social media.', 'Contract', 'Remote', true],
    [6, 'Data Scientist', 'Analyze large datasets to improve medical diagnosis models.', 'Full-time', 'On-site', true],
    [6, 'AI Researcher', 'Research new machine learning algorithms for healthcare.', 'Part-time', 'Remote', false],
    [8, 'Project Manager', 'Manage large-scale construction projects.', 'Full-time', 'On-site', true],
    [8, 'Civil Engineer', 'Oversee civil engineering aspects of the projects.', 'Full-time', 'On-site', false],
    [10, 'Financial Analyst', 'Analyze market trends and forecast financial performance.', 'Full-time', 'On-site', true],
    [10, 'Data Analyst', 'Interpret data and provide business insights.', 'Contract', 'Remote', false],
    [12, 'Cloud Architect', 'Design and manage cloud infrastructure solutions.', 'Full-time', 'On-site', false],
    [12, 'DevOps Engineer', 'Implement CI/CD pipelines and cloud automation.', 'Part-time', 'Remote', true],
    [14, 'Solar Engineer', 'Design and install solar power systems.', 'Full-time', 'On-site', true],
    [14, 'Sustainability Consultant', 'Advise companies on sustainable energy solutions.', 'Contract', 'Remote', false],
    [16, 'Blockchain Developer', 'Develop smart contracts for blockchain applications.', 'Full-time', 'Remote', false],
    [16, 'Full Stack Developer', 'Build decentralized web applications.', 'Full-time', 'Remote', true],
    [18, 'Cybersecurity Analyst', 'Monitor and respond to cybersecurity threats.', 'Full-time', 'On-site', true],
    [22, 'Penetration Tester', 'Test security vulnerabilities in financial software.', 'Contract', 'Remote', false],
    [22, 'Research Scientist', 'Lead cancer research projects in drug discovery.', 'Full-time', 'On-site', true],
    [22, 'Clinical Trials Coordinator', 'Manage and coordinate clinical trials for new treatments.', 'Full-time', 'On-site', true],
    [22, 'Graphic Designer', 'Create visual concepts using computer software or by hand to communicate ideas.', 'Part-time', 'Remote', false]
];

$tempCount = 0;

// Insert job vacancies
foreach ($jobVacancies as $vacancy) {
    $stmt->bindParam(':company_id', $vacancy[0]);
    $stmt->bindParam(':position', $vacancy[1]);
    $stmt->bindParam(':description', $vacancy[2]);
    $stmt->bindParam(':job_type', $vacancy[3]);
    $stmt->bindParam(':location_type', $vacancy[4]);
    $stmt->bindParam(':is_open', $vacancy[5], PDO::PARAM_BOOL);
    $stmt->bindParam(':count', $tempCount);
    $stmt->execute();
}

/**
 * Seeding table vacancy_attachments
 */
$query = "INSERT INTO vacancy_attachments (vacancy_id, file_path) VALUES (:vacancy_id, :file_path)";
$stmt = $db->prepare($query);

// Vacancy attachments data
// /company/{company_id}/{vacancy_id}/file{number}.png
// jadinya : /company/{company_id}/{job_title}/file{number}.png
$vacancyAttachments = [
    [1, '/company/2/1/file1.png'],
    [1, '/company/2/1/file2.png'],
    [3, '/company/4/3/file2.jpg'],
    [5, '/company/6/5/file3.jpg'],
    [7, '/company/8/7/file4.jpg'],
    [9, '/company/10/9/file5.png'],
    [12, '/company/1.jpeg'],
    [12, '/company/2.jpeg'],
    [12, '/company/3.jpeg'],
    [12, '/company/4.jpeg'],
    [12, '/company/5.jpeg'],
];

// Insert vacancy attachments
foreach ($vacancyAttachments as $attachment) {
    $stmt->bindParam(':vacancy_id', $attachment[0]);
    $stmt->bindParam(':file_path', $attachment[1]);
    $stmt->execute();
}

/**
 * Seeding table applications
 */
$query = "INSERT INTO applications (user_id, vacancy_id, cv_path, video_path, status, status_reason) VALUES (:user_id, :vacancy_id, :cv_path, :video_path, :status, :status_reason)";
$stmt = $db->prepare($query);

// Applications data
$applications = [
    [1, 1, '/upload/cv/sample_cv.pdf', null, 'rejected', 'Not enough experience.'],
    [1, 2, '/upload/cv/sample_cv.pdf', null, 'accepted', 'I love you.'],
    [3, 2, '/upload/cv/sample_cv.pdf', null, 'rejected', 'I love you.'],
    [5, 2, '/upload/cv/sample_cv.pdf', null, 'accepted', 'I love you.'],
    [7, 2, '/upload/cv/sample_cv.pdf', null, 'waiting', 'I love you.'],
    [9, 2, '/upload/cv/sample_cv.pdf', null, 'waiting', 'I love you.'],
    [11, 2, '/upload/cv/sample_cv.pdf', null, 'accepted', 'I love you.'],
    [13, 2, '/upload/cv/sample_cv.pdf', null, 'accepted', 'I love you.'],
    [3, 3, '/upload/cv/sample_cv.pdf', null, 'waiting', null],
    [5, 5, '/upload/cv/sample_cv.pdf', null, 'accepted', 'Great qualifications.'],
    [7, 7, '/upload/cv/sample_cv.pdf', null, 'waiting', null],
    [9, 9, '/upload/cv/sample_cv.pdf', null, 'rejected', 'Not enough experience.'],
    [11, 11, '/upload/cv/sample_cv.pdf', null, 'waiting', null],
    [13, 13, '/upload/cv/sample_cv.pdf', null, 'waiting', null],
    [15, 15, '/upload/cv/sample_cv.pdf', null, 'accepted', 'Perfect fit for the role.'],
    [17, 17, '/upload/cv/sample_cv.pdf', null, 'rejected', 'Better candidates available.'],
    [19, 19, '/upload/cv/sample_cv.pdf', null, 'waiting', null],
];

// Insert applications
foreach ($applications as $application) {
    $stmt->bindParam(':user_id', $application[0]);
    $stmt->bindParam(':vacancy_id', $application[1]);
    $stmt->bindParam(':cv_path', $application[2]);
    $stmt->bindParam(':video_path', $application[3]);
    $stmt->bindParam(':status', $application[4]);
    $stmt->bindParam(':status_reason', $application[5]);
    $stmt->execute();
}

// Close the database connection
$db = null;

?>