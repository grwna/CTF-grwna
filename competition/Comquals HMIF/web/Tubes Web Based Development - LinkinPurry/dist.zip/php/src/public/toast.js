function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;

    toast.style.position = 'fixed';
    toast.style.left = '50%';
    toast.style.top = '15%';
    toast.style.transform = 'translate(-50%, -50%)';
    toast.style.padding = '15px';
    toast.style.backgroundColor = '#0073b1';
    toast.style.color = '#fff';
    toast.style.borderRadius = '5px';
    toast.style.boxShadow = '0 0 10px rgba(0,0,0,0.2)';
    toast.style.zIndex = '1000';
    toast.style.transition = 'opacity 0.5s';
    toast.style.height = 'auto';
    toast.style.width = '300px';
    toast.style.fontSize = '14px';
    toast.style.textAlign = 'center';


    document.body.appendChild(toast);

    // fade out n remove after 3 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 500);
    }, 3000);
}

const urlParams = new URLSearchParams(window.location.search);
const myParam = urlParams.get('err');
console.log(myParam);
if(myParam != null){
    showToast(myParam);
}
