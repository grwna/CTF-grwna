let currentPage = 1;
const dataContainer = document.getElementById('job-listings-id');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

let debounceTimeout;
function debouncedSearch() {
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => {
        loadPage(currentPage);
    }, 300); // 300ms delay
}
let x = 1;

// Function to load data for a specific page
function loadPage(page) {
    console.log("X VALUE" + x);
    x++;
    // filter and sort functionality
    const searchInput = document.getElementById('search-input').value;
    const jobTypeCheckboxes = document.querySelectorAll('#job-types input[type="checkbox"]:checked');
    const locationCheckboxes = document.querySelectorAll('#locations input[type="checkbox"]:checked');
    const sortByDateRadio = document.querySelector('#date-sort input[type="radio"]:checked');
    
    // Get the selected values
    const jobTypes = Array.from(jobTypeCheckboxes).map(checkbox => checkbox.value);
    const locationTypes = Array.from(locationCheckboxes).map(checkbox => checkbox.value);
    const sortByDate = sortByDateRadio ? sortByDateRadio.value : 'desc'; // default to 'desc' if none is selected

    const params = new URLSearchParams({
        search: searchInput,
        jobType: jobTypes,
        locationType: locationTypes,
        sortBy: sortByDate
    });

    // pagination functionality

    const xhr = new XMLHttpRequest();
    xhr.open('GET', `/api/list-job-pagination?page=${page}&${params.toString()}`, true); // Replace with your actual API endpoint

    xhr.onload = function () {
        if (xhr.status === 200) {
            // console.log(xhr.responseText);
            const response = JSON.parse(xhr.responseText);
            // console.log(response); 

            const groupedJobs = response; // The API response contains grouped jobs by company
            const totalPages = response['total-pages']; // For pagination control
            console.log(totalPages);
            console.log(currentPage);
            currentPage = response['current-page']; // For knowing the current page

            // Clear previous job listings
            const jobListings = document.querySelector('.job-listings');
            jobListings.innerHTML = ''; // Clear any existing listings
            
            /// Exclude 'current-page' and 'total-pages' from groupedJobs count
            const validJobs = Object.entries(groupedJobs).filter(([companyId]) => {
                return companyId !== 'current-page' && companyId !== 'total-pages';
            });

            // Check if there are valid jobs available
            if (validJobs.length === 0) {
                jobListings.innerHTML = '<p class="no-jobs-message">No job listings available at the moment.</p>';
            } else {
                // If there are jobs, display them grouped by company
                Object.entries(groupedJobs).forEach(([companyId, company]) => {
                    // Skip 'current-page' and 'total-pages'
                    if (companyId === 'current-page' || companyId === 'total-pages') return;

                    // Add company name first
                    jobListings.innerHTML += `<h3>${company.company_name}</h3>`;

                    // Now add jobs for that company
                    company.jobs.forEach(job => {
                        jobListings.innerHTML += `
                            <div class="job-card" onclick="window.location.href='/job-detail?vacancy_id=${job.vacancy_id}'">
                                <div class="job-picture">
                                    <img src="/public/assets/company-profile.svg" alt="company picture" class="job-pic">
                                </div>
                                <div class="job-details">
                                    <h4>${job.position}</h4>
                                    <p>${job.location_type}</p>
                                    <p class="job-info">Posted On: ${job.created_at}</p>
                                </div>
                            </div>
                        `;
                    });
                });
            }

            updatePagination(totalPages);

            // prevBtn.hidden = currentPage === 1;
            // nextBtn.hidden = currentPage === totalPages;
        }
    };

    xhr.onerror = function () {
        console.error("An error occurred while fetching data.");
    };

    xhr.send();
}

function updatePagination(totalPages) {
    const paginationContainer = document.querySelector('.pagination');
    paginationContainer.innerHTML = '';

    // If there's more than one page, show pagination
    if (totalPages > 1) {
        // Add Previous button if not on the first page
        if (currentPage > 1) {
            paginationContainer.innerHTML += `<a style="cursor: pointer;" id="prev-btn" onclick="loadPage(${currentPage - 1})"><</a>`;
        }

        // Add page numbers dynamically
        for (let i = 1; i <= totalPages; i++) {
            paginationContainer.innerHTML += `<a style="cursor: pointer;" class="${i === currentPage ? 'active' : ''}" onclick="loadPage(${i})">${i}</a>`;
        }

        // Add Next button if not on the last page
        if (currentPage < totalPages) {
            paginationContainer.innerHTML += `<a style="cursor: pointer;" id="next-btn" onclick="loadPage(${currentPage + 1})">></a>`;
        }
    }
}

// Initial load
loadPage(currentPage);

// Event listeners for pagination buttons
prevBtn.addEventListener('click', () => {
    if (currentPage > 1) {
        loadPage(currentPage - 1);
    }
});

nextBtn.addEventListener('click', () => {
    loadPage(currentPage + 1);
});