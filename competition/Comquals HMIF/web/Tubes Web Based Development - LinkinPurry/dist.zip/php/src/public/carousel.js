document.addEventListener('DOMContentLoaded', function() {
    loadImages();
});

function loadImages() {
    const params = new URLSearchParams(window.location.search);
    let vacancy_id = params.get('vacancy_id');

    if (!vacancy_id) {
        console.error('Vacancy ID not found in the URL');
        return;
    }

    // Fetch the image names using the vacancy_id
    fetch(`/api/get-attachment-name?vacancy_id=${vacancy_id}`)
        .then(response => response.json())
        .then(imageNames => {
            // Check if the response contains images
            if (!Array.isArray(imageNames) || imageNames.length === 0) {
                console.warn('No image names returned from the API');
                // Show the "No images available" message
                document.getElementById('no-images-message').style.display = 'block';
                return;
            }

            // Hide the "No images available" message if there are images
            document.getElementById('no-images-message').style.display = 'none';

            // For each image name, fetch the image data as a blob
            imageNames.forEach((imageName, index) => fetchImageBlob(imageName, index));
        })
        .catch(error => {
            console.error('Error loading image list:', error);
            // Show the "No images available" message in case of an error
            document.getElementById('no-images-message').style.display = 'block';
        });
}

// Function to convert Blob to base64
function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob); // This will convert blob to base64
    });
  }

// Function to fetch an image blob and display it in the carousel
function fetchImageBlob(imageName, index) {
    fetch(`/api/get-attachment-blob?name=${encodeURIComponent(imageName)}`)
        .then(response => {
            if (!response.ok) throw new Error('Image not found');
            return response.json();
        })
        .then(data => {
            const imgURL = data.data;
            const slide = document.createElement('div');
            
            // Apply the 'carousel-slide' class and 'active' for the first image
            slide.className = `carousel-slide ${index === 0 ? 'active' : ''}`;

            // Create the image element
            const img = document.createElement('img');
            img.src = imgURL;
            img.alt = imageName;

            // Append the image to the slide div
            slide.appendChild(img);

            // Append the slide div to the carousel container
            const carousel = document.getElementById('carousel');
            if (carousel) {
                carousel.appendChild(slide);
                console.log('Image appended to carousel:', imageName);
            } else {
                console.error('Carousel container not found.');
            }
        })
        .catch(error => console.error(`Error loading image ${imageName}:`, error));
}
