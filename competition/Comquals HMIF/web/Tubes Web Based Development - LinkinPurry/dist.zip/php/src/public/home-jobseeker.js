function getTopJobs() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `/api/get-jobs-recommendation`);

    xhr.onload = function() {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);

            const divElement = document.getElementById('recommendations');  
            divElement.innerHTML = '<h3>Top Job Recommendations</h3>'; // Clear the previous content
            
            const validJobs = response;

            // Ensure validJobs is an array before proceeding
            if (Array.isArray(validJobs) && validJobs.length > 0) {
                validJobs.forEach(job => {
                    // Create job card HTML structure
                    const jobCard = document.createElement('div');
                    jobCard.classList.add('job-card');
                    jobCard.onclick = function() {
                        window.location.href = `/job-detail?vacancy_id=${job.vacancy_id}`;
                    };

                    // Job picture section
                    const jobPicture = document.createElement('div');
                    jobPicture.classList.add('job-picture');
                    const img = document.createElement('img');
                    img.src = "/public/assets/company-profile.svg";
                    img.alt = "company picture";
                    img.classList.add('job-pic');
                    jobPicture.appendChild(img);

                    // Job details section
                    const jobDetails = document.createElement('div');
                    jobDetails.classList.add('job-details-top');
                    const jobTitle = document.createElement('h4');
                    jobTitle.textContent = job.position;
                    const jobLocation = document.createElement('p');
                    jobLocation.textContent = job.location_type;
                    const jobInfo = document.createElement('p');
                    jobInfo.classList.add('job-info');
                    jobInfo.textContent = `Posted On: ${job.created_at}`;

                    jobDetails.appendChild(jobTitle);
                    jobDetails.appendChild(jobLocation);
                    jobDetails.appendChild(jobInfo);

                    // Append picture and details to the job card
                    jobCard.appendChild(jobPicture);
                    jobCard.appendChild(jobDetails);

                    // Append the job card to the recommendations container
                    divElement.appendChild(jobCard);
                });
            } else {
                // Handle case where there are no valid jobs
                divElement.innerHTML = '<p>No job recommendations found.</p>';
            }
        }
    };

    xhr.send();
}

getTopJobs();
