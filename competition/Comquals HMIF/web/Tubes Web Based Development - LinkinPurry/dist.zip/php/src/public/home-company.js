// set button
document.querySelectorAll('.filter-toggle').forEach(button => {
    button.addEventListener('click', function() {
        const filterId = this.getAttribute('data-filter');
        const filterOptions = document.getElementById(filterId);
        const icon = this.querySelector('.filter-icon');

        if (filterOptions.style.display === 'block') {
            filterOptions.style.display = 'none';
            icon.textContent = '+'; // Change back to "+"
        } else {
            filterOptions.style.display = 'block';
            icon.textContent = '-'; // Change to "-"
        }
    });
});

function editJob(event, jobId) {
    event.stopPropagation(); // prevents redirect when clicking the button
    // EDIT LOGIC
    console.log('Edit job with ID:', jobId);
}

function deleteJob(event, jobId) {
    event.stopPropagation(); // prevents redirect when clicking the button
    // DELETE LOGIICC
    console.log('Delete job with ID:', jobId);
}

// PAGINATION
let currentPage = 1;
const dataContainer = document.getElementById('job-listings-id');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

let debounceTimeout;
function debouncedSearch() {
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => {
        loadPage(currentPage);
    }, 300); // 300ms delay
}


// Function to load data for a specific page
function loadPage(page) {
    // filter and sort functionality
    const searchInput = document.getElementById('search-input').value;
    const jobTypeCheckboxes = document.querySelectorAll('#job-types input[type="checkbox"]:checked');
    const locationCheckboxes = document.querySelectorAll('#locations input[type="checkbox"]:checked');
    const sortByDateRadio = document.querySelector('#date-sort input[type="radio"]:checked');
    
    // Get the selected values
    const jobTypes = Array.from(jobTypeCheckboxes).map(checkbox => checkbox.value);
    const locationTypes = Array.from(locationCheckboxes).map(checkbox => checkbox.value);
    const sortByDate = sortByDateRadio ? sortByDateRadio.value : 'desc'; // default to 'desc' if none is selected

    console.log(jobTypes);
    const params = new URLSearchParams({
        search: searchInput,
        jobType: jobTypes,
        locationType: locationTypes,
        sortBy: sortByDate
    });

    // pagination functionality

    const xhr = new XMLHttpRequest();
    xhr.open('GET', `/api/company-job-list?page=${page}&${params.toString()}`, true); // Replace with your actual API endpoint

    xhr.onload = function () {
        if (xhr.status === 200) {
            console.log(xhr.responseText);
            const response = JSON.parse(xhr.responseText);
            console.log(response); 

            const groupedJobs = response; // The API response contains grouped jobs by company
            const totalPages = response['total-pages']; // For pagination control
            console.log(totalPages);
            console.log(currentPage);
            currentPage = response['current-page']; // For knowing the current page

            // Clear previous job listings
            const jobListings = document.querySelector('.job-list');
            jobListings.innerHTML = ''; // Clear any existing listings
            
            /// Exclude 'current-page' and 'total-pages' from groupedJobs count
            const validJobs = Object.entries(groupedJobs).filter(([companyId]) => {
                return companyId !== 'current-page' && companyId !== 'total-pages';
            });

            // Check if there are valid jobs available
            if (validJobs.length === 0) {
                jobListings.innerHTML = '<p class="no-jobs-message">No job listings available at the moment.</p>';
            } else {
                // If there are jobs, display them grouped by company
                Object.entries(groupedJobs).forEach(([companyId, company]) => {
                    // Skip 'current-page' and 'total-pages'
                    if (companyId === 'current-page' || companyId === 'total-pages') return;

                    // Add company name first
                    jobListings.innerHTML += `<h3>${company.company_name}</h3>`;

                    // Now add jobs for that company
                    company.jobs.forEach(job => {
                        jobListings.innerHTML += `
                            <div class="job-card">
                                <div onclick="window.location.href='/job-detail-company?vacancy_id=${job.vacancy_id}'">
                                
                                    <div class="job-picture-details">
                                        <!-- Company Picture -->
                                        <div class="job-picture">
                                            <img src="/public/assets/company-profile.svg" alt="company picture" class="job-pic">
                                        </div>
                                        <!-- Job Details -->
                                        <div class="job-details">
                                            <h4>${job.position}</h4>
                                            <p>${job.location_type}</p>
                                            <p class="job-info">Posted On: ${job.created_at}</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Edit and Delete Icons -->
                                <div class="job-actions">
                                    <!-- Pencil Icon (Edit) -->
                                    <button class="icon-button edit-button" aria-label="edit job button" onclick="window.location.href='/edit-lowongan?vacancy_id=${job.vacancy_id}'">
                                        <svg class="icon-pencil" fill="#888888" height="20" width="20" viewBox="0 0 306.637 306.637">
                                            <g>
                                                <path d="M12.809,238.52L0,306.637l68.118-12.809l184.277-184.277l-55.309-55.309L12.809,238.52z M60.79,279.943l-41.992,7.896
                                                    l7.896-41.992L197.086,75.455l34.096,34.096L60.79,279.943z"/>
                                                <path d="M251.329,0l-41.507,41.507l55.308,55.308l41.507-41.507L251.329,0z M231.035,41.507l20.294-20.294l34.095,34.095
                                                    L265.13,75.602L231.035,41.507z"/>
                                            </g>
                                        </svg>
                                    </button>

                                    <!-- Trash Icon (Delete) -->
                                    <form action="/job-detail-company" method="POST" aria-label="delete job button" class="delete-form" onsubmit="return confirm('Are you sure you want to delete this job?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="vacancy_id" value="${job.vacancy_id}">
                                        <button type="submit" aria-label="delete job button" class="icon-button delete-button">
                                        <svg class="icon-trash" fill="#888888" height="20" width="20" viewBox="0 0 256 256">
                                            <g transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">
                                                <path d="M 64.71 90 H 25.291 c -4.693 0 -8.584 -3.67 -8.859 -8.355 l -3.928 -67.088 c -0.048 -0.825 0.246 -1.633 0.812 -2.234 c 0.567 -0.601 1.356 -0.941 2.183 -0.941 h 59.002 c 0.826 0 1.615 0.341 2.183 0.941 c 0.566 0.601 0.86 1.409 0.813 2.234 l -3.928 67.089 C 73.294 86.33 69.403 90 64.71 90 z M 18.679 17.381 l 3.743 63.913 C 22.51 82.812 23.771 84 25.291 84 H 64.71 c 1.52 0 2.779 -1.188 2.868 -2.705 l 3.742 -63.914 H 18.679 z"/>
                                                <path d="M 80.696 17.381 H 9.304 c -1.657 0 -3 -1.343 -3 -3 s 1.343 -3 3 -3 h 71.393 c 1.657 0 3 1.343 3 3 S 82.354 17.381 80.696 17.381 z"/>
                                                <path d="M 58.729 17.381 H 31.271 c -1.657 0 -3 -1.343 -3 -3 V 8.789 C 28.271 3.943 32.214 0 37.061 0 h 15.879 c 4.847 0 8.789 3.943 8.789 8.789 v 5.592 C 61.729 16.038 60.386 17.381 58.729 17.381 z M 34.271 11.381 h 21.457 V 8.789 C 55.729 7.251 54.478 6 52.939 6 H 37.061 c -1.538 0 -2.789 1.251 -2.789 2.789 V 11.381 z"/>
                                            </g>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        `;
                    });
                });
            }

            updatePagination(totalPages);

            // prevBtn.hidden = currentPage === 1;
            // nextBtn.hidden = currentPage === totalPages;
        }
    };

    xhr.onerror = function () {
        console.error("An error occurred while fetching data.");
    };

    xhr.send();
}

function updatePagination(totalPages) {
    const paginationContainer = document.querySelector('.pagination');
    paginationContainer.innerHTML = '';

    // If there's more than one page, show pagination
    if (totalPages > 1) {
        // Add Previous button if not on the first page
        if (currentPage > 1) {
            paginationContainer.innerHTML += `<a style="cursor: pointer;" id="prev-btn" onclick="loadPage(${currentPage - 1})"><</a>`;
        }

        // Add page numbers dynamically
        for (let i = 1; i <= totalPages; i++) {
            paginationContainer.innerHTML += `<a style="cursor: pointer;" class="${i === currentPage ? 'active' : ''}" onclick="loadPage(${i})">${i}</a>`;
        }

        // Add Next button if not on the last page
        if (currentPage < totalPages) {
            paginationContainer.innerHTML += `<a style="cursor: pointer;" id="next-btn" onclick="loadPage(${currentPage + 1})">></a>`;
        }
    }
}

// Initial load
loadPage(currentPage);

// Event listeners for pagination buttons
prevBtn.addEventListener('click', () => {
    if (currentPage > 1) {
        loadPage(currentPage - 1);
    }
});

nextBtn.addEventListener('click', () => {
    loadPage(currentPage + 1);
});

document.addEventListener('DOMContentLoaded', function () {
    // Get modal elements
    const modal = document.getElementById('editProfileModal');
    const editProfileBtn = document.querySelector('.edit-profile');
    const closeBtn = document.querySelector('.close');

    // Show modal when edit profile button is clicked
    editProfileBtn.addEventListener('click', function () {
        modal.style.display = 'block';
    });

    // Close the modal when the user clicks on the 'x'
    closeBtn.addEventListener('click', function () {
        modal.style.display = 'none';
    });

    // Close the modal if the user clicks outside of it
    window.addEventListener('click', function (event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });
});