let currentPage = 1;
const dataContainer = document.getElementById('job-listings-id');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

let debounceTimeout;
function debouncedSearch() {
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => {
        loadPage(currentPage);
    }, 300); // 300ms delay
}


// Function to load data for a specific page
function loadPage(page) {
    // pagination functionality
    
    // get vacancy_id from URL
    const urlParams = new URLSearchParams(window.location.search);
    const vacancyId = urlParams.get('vacancy_id');

    const xhr = new XMLHttpRequest();
    xhr.open('GET', `/api/list-applicants-pagination?page=${page}&vacancy_id=${vacancyId}`, true); // Replace with your actual API endpoint

    xhr.onload = function () {
        if (xhr.status === 200) {
            // console.log(xhr.responseText);
            const response = JSON.parse(xhr.responseText);
            // console.log(response);
    
            // retrieve applicants data from response
            const applicants = Object.entries(response)
                .filter(([key]) => key !== 'current-page' && key !== 'total-pages') // exclude pagination keys
                .map(([, applicant]) => applicant);
    
            const totalPages = response['total-pages']; // total pages data
            // console.log(totalPages);
            currentPage = response['current-page']; // track current page
    
            // Clear previous job listings
            const jobListings = document.querySelector('.job-listings');
            jobListings.innerHTML = ''; // Clear any existing listings
    
            // Check if there are valid applicants available
            if (applicants.length === 0) {
                jobListings.innerHTML = '<p class="no-jobs-message">No applicants at the moment.</p>';
            } else {
                applicants.forEach(applicant => {
                    let imageSrc;
                    switch (applicant.status) {
                        case 'accepted':
                            imageSrc = '/public/assets/accepted-status.svg'; 
                            break;
                        case 'rejected':
                            imageSrc = '/public/assets/rejected-status.svg'; 
                            break;
                        case 'waiting':
                            imageSrc = '/public/assets/waiting-status.svg';
                            break;
                        default:
                            imageSrc = '/public/assets/waiting-status.svg'; 
                            break;
                    }

                    jobListings.innerHTML += `
                        <div class="job-card" onclick="window.location.href='/applicants-detail-company?applicant_user_id=${applicant.user_id}&vacancy_id=${vacancyId}'">
                            <div class="job-details">
                                <h4>${applicant.applicant_name}</h4> <!-- Change position to applicant_name -->
                                <p class="job-info">Applied on: ${applicant.created_at}</p>
                            </div>
                            <img src="${imageSrc}" alt="${applicant.status}" class="applicant-status-image">
                        </div>
                    `;
                });
            }
    
            updatePagination(totalPages);
    
            // prevBtn.hidden = currentPage === 1;
            // nextBtn.hidden = currentPage === totalPages;
        } else {
            console.error("Request failed with status:", xhr.status);
        }
    };

    xhr.onerror = function () {
        console.error("An error occurred while fetching data.");
    };

    xhr.send();
}

function updatePagination(totalPages) {
    const paginationContainer = document.querySelector('.pagination');
    paginationContainer.innerHTML = '';

    // If there's more than one page, show pagination
    if (totalPages > 1) {
        // Add Previous button if not on the first page
        if (currentPage > 1) {
            paginationContainer.innerHTML += `<a style="cursor: pointer;" id="prev-btn" onclick="loadPage(${currentPage - 1})"><</a>`;
        }

        // Add page numbers dynamically
        for (let i = 1; i <= totalPages; i++) {
            paginationContainer.innerHTML += `<a style="cursor: pointer;" class="${i === currentPage ? 'active' : ''}" onclick="loadPage(${i})">${i}</a>`;
        }

        // Add Next button if not on the last page
        if (currentPage < totalPages) {
            paginationContainer.innerHTML += `<a style="cursor: pointer;" id="next-btn" onclick="loadPage(${currentPage + 1})">></a>`;
        }
    }
}

// Initial load
loadPage(currentPage);

// Event listeners for pagination buttons
prevBtn.addEventListener('click', () => {
    if (currentPage > 1) {
        loadPage(currentPage - 1);
    }
});

nextBtn.addEventListener('click', () => {
    loadPage(currentPage + 1);
});