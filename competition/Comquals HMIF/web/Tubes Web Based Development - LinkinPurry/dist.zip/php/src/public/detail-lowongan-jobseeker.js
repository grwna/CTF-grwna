function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;

    toast.style.position = 'fixed';
    toast.style.left = '50%';
    toast.style.top = '15%';
    toast.style.transform = 'translate(-50%, -50%)';
    toast.style.padding = '15px';
    toast.style.backgroundColor = '#0073b1';
    toast.style.color = '#fff';
    toast.style.borderRadius = '5px';
    toast.style.boxShadow = '0 0 10px rgba(0,0,0,0.2)';
    toast.style.zIndex = '1000';
    toast.style.transition = 'opacity 0.5s';
    toast.style.height = 'auto';
    toast.style.width = '300px';
    toast.style.fontSize = '14px';
    toast.style.textAlign = 'center';


    document.body.appendChild(toast);

    // fade out n remove after 3 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 500);
    }, 3000);
}

function displayFile(inputElement, displayElement, fileType) {
    const file = inputElement.files[0];
    if (file) {
        const fileName = file.name;
        let fileDisplayHTML = '';

        if (fileType === 'pdf') {
            fileDisplayHTML = `<div class="file-box pdf-box">
                <span class="file-type">PDF</span>
                <span class="file-name">${fileName}</span>
            </div>`;
        } else if (fileType === 'mp4') {
            fileDisplayHTML = `<div class="file-box mp4-box">
                <span class="file-type">MP4</span>
                <span class="file-name">${fileName}</span>
            </div>`;
        }

        displayElement.innerHTML = fileDisplayHTML;
    }
}

const resumeUpload = document.getElementById('resume-upload');
const resumeDisplay = document.getElementById('resume-display');

if(resumeUpload != null){
    resumeUpload.addEventListener('change', function() {
        displayFile(resumeUpload, resumeDisplay, 'pdf');
    });
}

const videoUpload = document.getElementById('video-upload');
const videoDisplay = document.getElementById('video-display');

if(videoUpload != null){
    videoUpload.addEventListener('change', function() {
        displayFile(videoUpload, videoDisplay, 'mp4');
    });
}

let hasApplied = false;

// popup elements
const applyBtn = document.getElementById('apply-btn');
const closeBtn = document.getElementById('close-btn');
const popup = document.getElementById('apply-popup');
const applicationStatus = document.getElementById('application-status');
const applyForm = document.getElementById('apply-form');

function resetForm() {
    applyForm.reset(); // reset form input fields
    resumeDisplay.innerHTML = ''; // clear file name display
    videoDisplay.innerHTML = ''; 
}

if(applyBtn != null){
    applyBtn.addEventListener('click', function() {
        console.log('clicked');
        console.log('Popup element:', popup);
        popup.style.display = 'block';
    });
}

if(closeBtn != null){
    closeBtn.addEventListener('click', function() {
        popup.style.display = 'none';
        resetForm();
        resumeError.style.display = 'none';
    });
}

window.onclick = function(event) {
    if (event.target == popup) {
        popup.style.display = 'none';
        resetForm();
        resumeError.style.display = 'none';
    }
};

const resumeError = document.getElementById('resume-error');

if(resumeUpload != null){
    resumeUpload.addEventListener('change', function() {
        if (resumeUpload.files.length > 0) {
            resumeError.style.display = 'none';
        }
    });
}

if(applyForm != null){
    applyForm.addEventListener('submit', function(event) {
        const resumeUploaded = resumeUpload.files.length > 0;
        const videoUploaded = videoUpload.files.length > 0;
    
        // If both resume and video are not uploaded, show error and prevent submission
        if (!resumeUploaded && !videoUploaded) {
            event.preventDefault(); // Prevent form submission
            resumeError.style.display = 'block'; // Show error message
            resumeError.innerText = 'This field is required.';
        }
    });
}

if(applyForm != null){
    applyForm.addEventListener('submit', function(event) {
        if (hasApplied) {
            event.preventDefault();
            showToast('You have already applied for this job. Please refresh the page to see your applications.');
        }
    });
}



const urlParams = new URLSearchParams(window.location.search);
const myParam = urlParams.get('err');
// console.log(myParam);
if(myParam != null){
    showToast(myParam);
}

let currentSlideIndex = 0;
let slides = Array.from(document.getElementsByClassName('carousel-slide')); // Convert to array

function showSlide(index) {
    slides.forEach((slide, i) => {
        console.log(slide)
        slide.classList.remove('active');
        if (i === index) {
            slide.classList.add('active');
        }
    });
}

function moveSlide(direction) {
    slides = Array.from(document.getElementsByClassName('carousel-slide')); // Convert to array
    currentSlideIndex += direction;
    if (currentSlideIndex < 0) {
        currentSlideIndex = slides.length - 1;
    } else if (currentSlideIndex >= slides.length) {
        currentSlideIndex = 0;
    }

    showSlide(currentSlideIndex);
}

// Initialize carousel
if (slides.length > 0) {
    showSlide(0);
}
