
    let currentSlideIndex = 0;
    let slides = Array.from(document.getElementsByClassName('carousel-slide')); // Convert to array
    
    function showSlide(index) {
        slides.forEach((slide, i) => {
            console.log(slide)
            slide.classList.remove('active');
            if (i === index) {
                slide.classList.add('active');
            }
        });
    }
    
    function moveSlide(direction) {
        slides = Array.from(document.getElementsByClassName('carousel-slide')); // Convert to array
        currentSlideIndex += direction;
        if (currentSlideIndex < 0) {
            currentSlideIndex = slides.length - 1;
        } else if (currentSlideIndex >= slides.length) {
            currentSlideIndex = 0;
        }
    
        showSlide(currentSlideIndex);
    }
    
    // Initialize carousel
    if (slides.length > 0) {
        showSlide(0);
    }
