<?php
/**
 * Function to create PDO to db for every connection  
 */
function dbConnect() {
    // the values are from docker-compose.yml environment
    $db = 'db';
    $db_name = getenv('POSTGRES_DB');
    $user = getenv('POSTGRES_USER');
    $pw = getenv('POSTGRES_PASSWORD');

    try {
        $pdo = new PDO("pgsql:host=$db;dbname=$db_name", $user, $pw);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        throw $e;
    }
}
?>
