<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job List</title>
    <link rel="stylesheet" href="/public/css/job-list.css">
</head>
<body>
    <!-- HEADER SECTION -->
    <header class="header">
        <div class="container">
            <img src="/public/assets/linkinpurry.svg"
                alt="LinkedIn Logo" class="logo">
            <div class="auth-buttons">
                <a href="/job-list" class="jobs" id="nav-status">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" data-supported-dps="24x24" fill="currentColor" class="mercado-match" width="24" height="24" focusable="false">
                        <path d="M22.84 10.22L21 6h-3.95V5a3 3 0 00-3-3h-4a3 3 0 00-3 3v1H2l2.22 5.18A3 3 0 007 13h14a2 2 0 001.84-2.78zM15.05 6h-6V5a1 1 0 011-1h4a1 1 0 011 1zM7 14h15v3a3 3 0 01-3 3H5a3 3 0 01-3-3V8.54l1.3 3A4 4 0 007 14z"></path>
                    </svg>
                    <p>Jobs</p>
                </a>
                <a href="/signup" class="join-now">Join now</a>
                <a href="/login" class="sign-in">Sign in</a>
            </div>
        </div>
    </header>

    <h2> Unlock your next career adventure, discover exciting job opportunities!</h2>
    <p class="login-text">
        <a href="/login" class="link">Log in</a>, or 
        <a href="/signup" class="link">create an account</a> to apply.
    </p>
    <section id="content">
        <!-- Fixed Sidebar for Profile and Filters -->
        <div class="sidebar">
            <!-- Job Filters Section -->
            <section id="job-filter" class="filter-section">
                <h3>Filter Jobs</h3>

                <!-- Job Type Filter -->
                <div class="filter-group">
                    <button class="filter-toggle" data-filter="job-types">
                        <span class="filter-text">All Job Types</span>
                        <span class="filter-icon">+</span>
                    </button>
                    <div class="filter-options" id="job-types" style="display: none;">
                        <label><input type="checkbox" value="full-time" onchange="loadPage(1)"> Full-time</label>
                        <label><input type="checkbox" value="part-time" onchange="loadPage(1)"> Part-time</label>
                        <label><input type="checkbox" value="contract" onchange="loadPage(1)"> Contract</label>
                    </div>
                </div>

                <!-- Location Filter -->
                <div class="filter-group">
                    <button class="filter-toggle" data-filter="locations">
                        <span class="filter-text">All Locations</span>
                        <span class="filter-icon">+</span>
                    </button>
                    <div class="filter-options" id="locations" style="display: none;">
                        <label><input type="checkbox" value="on-site" onchange="loadPage(1)"> On-site</label>
                        <label><input type="checkbox" value="hybrid" onchange="loadPage(1)"> Hybrid</label>
                        <label><input type="checkbox" value="remote" onchange="loadPage(1)"> Remote</label>
                    </div>
                </div>

                <!-- Date Sorting -->
                <div class="filter-group">
                    <button class="filter-toggle" data-filter="date-sort">
                        <span class="filter-text">Sort by Date</span>
                        <span class="filter-icon">+</span>
                    </button>
                    <div class="filter-options" id="date-sort" style="display: none;">
                        <label><input type="radio" name="date-sort" value="desc" onchange="loadPage(1)" checked> Newest First</label>
                        <label><input type="radio" name="date-sort" value="asc" onchange="loadPage(1)"> Oldest First</label>
                    </div>
                </div>
            </section>
        </div>

        <!-- Main Content Area for Job Listings -->
        <section id="main">
            <!-- Search Input -->
            <input type="text" id="search-input" placeholder="Search job title..." oninput="debouncedSearch()">
            
            <!-- Job Listings -->
            <div id="job-listings-id" class="job-listings"></div>

            <!-- Pagination -->
            <div class="pagination">
                <a style="cursor: pointer;" id="prev-btn"><</a>
                <span id="pagination-numbers"></span>
                <a style="cursor: pointer;" id="next-btn">></a>
            </div>
        </section>
    </section>
    
    <script src="public/pagination.js"></script>
    <script>
        document.querySelectorAll('.filter-toggle').forEach(button => {
            button.addEventListener('click', function() {
                const filterId = this.getAttribute('data-filter');
                const filterOptions = document.getElementById(filterId);
                const icon = this.querySelector('.filter-icon');

                if (filterOptions.style.display === 'block') {
                    filterOptions.style.display = 'none';
                    icon.textContent = '+'; // Change back to "+"
                } else {
                    filterOptions.style.display = 'block';
                    icon.textContent = '-'; // Change to "-"
                }
            });
        });
    </script>

    <section>
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
    </section>

</body>
</html>
