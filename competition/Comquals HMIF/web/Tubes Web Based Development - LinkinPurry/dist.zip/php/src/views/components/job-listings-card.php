<?php 

if (!empty($groupedJobs)){
    foreach($groupedJobs as $companyId => $companyData) {
        $html = <<< "EOT"
            <h3>{$companyData['company_name']}</h3>
        EOT;
        echo $html;
        
        foreach($companyData['jobs'] as $job){
            $datetime = date('F j, Y', strtotime($job['created_at']));
    
            $div = <<< "EOT"
                <div class="job-card" onclick="window.location.href='/job-detail?vacancy_id={$job['vacancy_id']}'">
                    <div class="job-picture">
                        <img src="/public/assets/company-profile.svg" alt="company picture" class="job-pic">
                    </div>
                    <div class="job-details">
                        <h4>{$job['position']}</h4>
                        <p>{$job['location_type']}</p>
                        <p class="job-info">Posted on: {$datetime}</p>
                    </div>
                </div>
            EOT;
            echo $div;
        }
    }
}
else {
    echo "<p>No job listings available at the moment.</p>";
}

/*
<?php foreach ($groupedJobs as $companyId => $companyData):
    <div class="company-section">
        <h3><?php echo $companyData['company_name']; ?></h3>
        <?php foreach ($companyData['jobs'] as $job): ?>
            <div class="job-card" onclick="window.location.href='/job-detail?vacancy_id=<?php echo $job['vacancy_id']; ?>'">
                <div class="job-picture">
                    <img src="/public/assets/company-profile.svg" alt="company picture" class="job-pic">
                </div>
                <div class="job-details">
                    <h4><?php echo $job['position']; ?></h4>
                    <p><?php echo $job['location_type']; ?></p>
                    <p class="job-info">Posted on: <?php echo date('F j, Y', strtotime($job['created_at'])); ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>
*/
?>