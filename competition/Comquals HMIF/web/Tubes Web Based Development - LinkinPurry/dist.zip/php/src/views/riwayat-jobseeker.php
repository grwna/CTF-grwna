<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Application History</title>
    <link rel="stylesheet" href="/public/css/job-history.css">
</head>
<body>
    <!-- HEADER SECTION -->
    <section>
        <?php require __DIR__.'/../includes/header-jobseeker.php'?>
    </section>

    <div class="container">
        <h1>Job Application History</h1>
        <div class="job-list">
            <?php
                if (!empty($applications)) {
                    foreach ($applications as $application) {
                        echo '
                        <div class="job-card" onclick="window.location.href=\'/job-detail?vacancy_id='.$application['vacancy_id'].'\'">
                            <div class="job-info">
                                <img src="'.$application['company_logo'].'" alt="Company Logo" class="company-logo">
                                <div>
                                    <h2>'.$application['position'].'</h2>
                                    <p>'.$application['location'].'</p>
                                    <p>Applied on '.date('d F Y', strtotime($application['applied_date'])).'</p>
                                </div>
                            </div>
                            <div class="status '.$application['status'].'">'.ucfirst($application['status']).'</div>
                        </div>';
                    }
                } else {
                    echo '<p>You have not applied for any jobs yet.</p>';
                }
            ?>
        </div>
    </div>
    <section>
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
    </section>
</body>
</html>
