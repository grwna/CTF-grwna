<?php if ($currentPage > 1): ?>
    <a href="?page=<?php echo $currentPage - 1; ?>">&laquo; Prev</a>
<?php endif; ?>

<?php
// banyak halaman yang akan ditampilkan di pagination
$maxVisiblePages = 7;
$startPage = 1;
$endPage = $totalPages;

if ($totalPages > $maxVisiblePages) {
    if ($currentPage <= ceil($maxVisiblePages / 2)) {
        // if halaman saat ini mendekati awal
        $startPage = 1;
        $endPage = $maxVisiblePages;
    } elseif ($currentPage > $totalPages - floor($maxVisiblePages / 2)) {
        // if halaman saat ini mendekati akhir
        $startPage = $totalPages - $maxVisiblePages + 1;
        $endPage = $totalPages;
    } else {
        // if halaman saat ini di tengah-tengah
        $startPage = $currentPage - floor($maxVisiblePages / 2);
        $endPage = $currentPage + floor($maxVisiblePages / 2);
    }
}

// loop untuk show pages
for ($i = $startPage; $i <= $endPage; $i++): ?>
    <a href="?page=<?php echo $i; ?>" class="<?php echo ($i == $currentPage) ? 'active' : ''; ?>">
        <?php echo $i; ?>
    </a>
<?php endfor; ?>

<?php if ($totalPages > $maxVisiblePages && $currentPage < $totalPages): ?>
    <a href="?page=<?php echo $currentPage + 1; ?>">Next &raquo;</a>
<?php endif; ?>