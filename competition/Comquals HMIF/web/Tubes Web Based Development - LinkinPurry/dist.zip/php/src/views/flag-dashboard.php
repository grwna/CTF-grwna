<?php

$temp = getenv('FLAG');

echo $temp;

?>