
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Lowongan</title>
    <link rel="stylesheet" href="/public/css/detail-lowongan-by-jobseek.css">
</head>
<body>
    <section>
        <?php require __DIR__.'/../includes/header-jobseeker.php'?>
    </section>

    <?php if (isset($jobDetails)) : ?>
        <div class="job-detail-page">
            <div class="company-profile">
                <img src="/public/assets/company-profile.svg" alt="Company Logo" class="company-logo">
                <div class="company-info">
                    <h2><?php echo $jobDetails['company_name']; ?></h2>
                    <p><?php echo $jobDetails['company_location']; ?></p>
                    <p><?php echo 'Posted: ' . date('F j, Y', strtotime($jobDetails['created_at'])); ?></p>
                </div>
            </div>

            <div class="job-title">
                <h1><?php echo $jobDetails['position']; ?></h1>
                <div class="job-tags">
                    <span class="job-tag"><?php echo $jobDetails['job_type']; ?></span>
                    <span class="job-tag"><?php echo $jobDetails['location_type']; ?></span>
                    <!-- if open -->
                    <?php if ($jobDetails['is_open']) : ?>
                        <span class="job-tag-open">Open</span>
                    <?php else : ?>
                        <span class="job-tag-closed">Closed</span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Check if job is open or the user has applied -->
            <?php if ($jobDetails['is_open'] || (isset($hasApplied) && $hasApplied)) : ?>
                <div class="job-description">
                    <h3>About the job</h3>
                    <p><?php echo $jobDetails['description']; ?></p>
                </div>
                <div class="workplace-insight">
                    <h3>Workplace Insight</h3>
                        <div class="carousel-container">
                        <div class="carousel" id="carousel"></div>
                        <p id="no-images-message" style="display: none;">No images available for this job.</p>
                            
                            <button class="carousel-prev" onclick="moveSlide(-1)">&#10094;</button>
                            <button class="carousel-next" onclick="moveSlide(1)">&#10095;</button>
                        </div>
                </div>

                <?php if ($jobDetails['is_open'] && isset($hasApplied) && !$hasApplied && $enableApply) : ?>
                    <div class="action-buttons">
                        <button id="apply-btn" class="apply-btn">Apply</button>
                    </div>
                <?php elseif ( isset($hasApplied) && $hasApplied) : ?>
                    <!-- show application details if the user has already applied -->
                    <div class="application-status" id="application-status">
                        <div class="applied">
                            <h3>Your Application Details</h3>
                            <p><strong>Status:</strong> <?php echo $applicationStatus['status']; ?></p>
                            <p><strong>Attachments:</strong></p>
                            <ul>
                                <li><a href="/api/get-cv?file=<?=$filename?>&vacancy_id=<?=$jobDetails['vacancy_id']?>" target="_blank">Your CV</a></li>
                                <embed src="/api/get-cv?file=<?=$filename?>&vacancy_id=<?=$jobDetails['vacancy_id']?>" id='jobseeker-cv' type="application/pdf" width="100%" height="300px" />
                                <?php if (!empty($applicationStatus['video_path'])) : ?>
                                    <li><a href="/api/get-video?file=<?php echo urlencode($applicationStatus['video_path']); ?>&vacancy_id=<?php echo $jobDetails['vacancy_id']; ?>" target="_blank">Introduction Video</a></li>
                                    <video controls width="100%">
                                        <source src="/api/get-video?file=<?php echo urlencode($applicationStatus['video_path']); ?>&vacancy_id=<?php echo $jobDetails['vacancy_id']; ?>" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php endif; ?>
                            </ul>
                            <p><strong>Status reason:</strong> <?php echo $applicationStatus['status_reason']; ?></p>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else : ?>
                <!-- show message if job is closed and user hasn't applied -->
                <div class="closed-job-message">
                    <h2>This job is no longer taking applications.</h2>
                </div>
            <?php endif; ?>
        </div>
        </div>

        <!-- Popup apply form (shown only if not applied) -->
            <div id="apply-popup" class="popup-overlay">
                <div class="popup-content">
                    <button class="close-btn" id="close-btn">&times;</button>
                    <h2>Apply to <span id="company-name"><?php echo $jobDetails['company_name']; ?></span></h2>
                    <form id="apply-form" action="/apply-job" method="POST" enctype="multipart/form-data">
                        <label for="resume-upload" class="file-label">Resume (.pdf) <span class="required">*</span>:</label>
                        <input type="file" name="resume-upload" id="resume-upload" accept=".pdf" hidden>
                        <div id="resume-display" class="file-display"></div>
                        <label for="resume-upload" class="custom-file-upload">
                            Choose Resume
                        </label>
                        <div id="resume-error" class="error-message"></div>

                        <label for="video-upload" class="file-label">Video (.mp4):</label>
                        <input type="file" name="video-upload" id="video-upload" accept=".mp4" hidden>
                        <div id="video-display" class="file-display"></div>
                        <label for="video-upload" class="custom-file-upload">
                            Choose Video
                        </label>
                        <!-- TODO: THIS IS NOT SECURE -->
                        <input hidden type="text" value=<?=$jobDetails['vacancy_id']?> name="vacancy-id">

                        <button type="submit" id="submit-application" class="submit-btn">Submit application</button>
                    </form>
                </div>
            </div>
    <?php else : ?>
        <p>Job details not found!</p>
    <?php endif; ?>
    
    <!-- JavaScript -->
    <script src="/public/carousel.js"></script>
    <script src="/public/detail-lowongan-jobseeker.js"></script>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
</body>
</html>
