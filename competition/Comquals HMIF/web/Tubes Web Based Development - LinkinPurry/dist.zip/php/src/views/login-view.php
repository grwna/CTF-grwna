<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="/public/css/login-view.css">
</head>

<body>
    <!-- TODO: INI BISA DI TEMPLATEING ? I BELIVE -->
    <header class="header">
        <div class="container">
            <img src="/public/assets/linkinpurry.svg"
                alt="LinkedIn Logo" class="logo">
            <div class="auth-buttons">
                <a href="/job-list" class="jobs" id="nav-status">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" data-supported-dps="24x24" fill="currentColor" class="mercado-match" width="24" height="24" focusable="false">
                        <path d="M22.84 10.22L21 6h-3.95V5a3 3 0 00-3-3h-4a3 3 0 00-3 3v1H2l2.22 5.18A3 3 0 007 13h14a2 2 0 001.84-2.78zM15.05 6h-6V5a1 1 0 011-1h4a1 1 0 011 1zM7 14h15v3a3 3 0 01-3 3H5a3 3 0 01-3-3V8.54l1.3 3A4 4 0 007 14z"></path>
                    </svg>
                    <p>Jobs</p>
                </a>
                <a href="/signup" class="join-now">Join now</a>
                <a href="/login" class="sign-in">Sign in</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="form-card-container">
            <div class="sign-in-container">
                <h1>Sign In</h1>
                <p>Stay updated on your purr-fessional world</p>
            </div>

            <?php
                // Retrieve the error from the URL if it exists
                $error = isset($_GET['error']) ? $_GET['error'] : '';
            ?>

            <form action="/login" method="post">
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Username">
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <div class="password-container">
                        <input type="password" id="password" name="password" placeholder="Password">
                        <span class="show-password" onclick="togglePassword()">Show</span>
                    </div>
                    <?php if ($error): ?>
                        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                </div>
                <div class="sign-in">
                    <button type="submit">Login</button>
                </div>
            </form>
        </div>
    </main>
    
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>

    <script>
        // hapus error pas reload
        document.addEventListener('DOMContentLoaded', function() {
            const url = new URL(window.location.href);
            if (url.searchParams.has('error')) {
                url.searchParams.delete('error');
                window.history.replaceState({}, document.title, url.toString());
            }
        });

        function togglePassword(){
            var passwordField = document.getElementById("password");
            var showPasswordText = document.querySelector(".show-password");
            
            if (passwordField.type === "password") {
                passwordField.type = "text";
                showPasswordText.textContent = "Hide";  // Change the text to 'Hide' when the password is visible
            } else {
                passwordField.type = "password";
                showPasswordText.textContent = "Show";  // Change it back to 'Show' when the password is hidden
            }
        }

    </script>

    <script src="/public/toast.js"></script>
</body>
</html>