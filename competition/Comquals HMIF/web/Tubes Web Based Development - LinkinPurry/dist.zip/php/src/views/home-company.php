<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage - Company</title>
    <link rel="stylesheet" href="public/css/home-company.css">
</head>
<body>
    <!-- HEADER SECTION -->
    <section>
        <?php require __DIR__.'/../includes/header-company.php' ?>
    </section>

    <section id="main-container">
        <!-- Left Sidebar: Profile and Filters -->
        <div id="sidebar">
            <!-- Profile Section -->
            <section class="profile-section">
                <div class="banner">
                    <img src="/public/assets/banner.svg" alt="Banner Image" class="banner-img">
                </div>
                <div class="profile-header">
                    <img src="/public/assets/profile.svg" alt="Profile" class="profile-pic">
                    <div class="profile-info">
                        <?php echo '<h1>'.$_SESSION['name'].'</h1>'; ?>
                        <p>We're hiring! Check out our job listings!</p>
                        <?php echo '<p>'.$_SESSION['email'].'</p>'; ?>
                    </div>
                    <button class="edit-profile" aria-label="edit profile button" name="edit profile button">Edit Profile</button>
                </div>
            </section>

            <!-- Filters Section -->
            <div class="filters">
                <h3>Filter Jobs</h3>
                <div class="filter-section">
                    <button class="filter-toggle" aria-label="toggle filter job types"  name="toggle filter job types" data-filter="job-types">
                        <span class="filter-text">All Job Types</span>
                        <span class="filter-icon">+</span>
                    </button>
                    <div class="filter-options" id="job-types">
                        <label><input type="checkbox" onchange="loadPage(1)" value="full-time"> Full-Time</label>
                        <label><input type="checkbox" onchange="loadPage(1)" value="part-time"> Part-Time</label>
                        <label><input type="checkbox" onchange="loadPage(1)" value="contract"> Contract</label>
                    </div>
                </div>
                <div class="filter-section">
                    <button class="filter-toggle" aria-label="toggle filter locations" data-filter="locations">
                        <span class="filter-text">All Locations</span>
                        <span class="filter-icon">+</span>
                    </button>
                    <div class="filter-options" id="locations">
                        <label><input type="checkbox" onchange="loadPage(1)" value="on-site" > On-site</label>
                        <label><input type="checkbox" onchange="loadPage(1)" value="hybrid" > Hybrid</label>
                        <label><input type="checkbox" onchange="loadPage(1)" value="remote" > Remote</label>
                    </div>
                </div>
                <div class="filter-section">
                    <button class="filter-toggle" aria-label="toggle filter date" data-filter="date">
                        <span class="filter-text">Date Published</span>
                        <span class="filter-icon">+</span>
                    </button>
                    <div class="filter-options" id="date">
                    <label><input type="radio" name="date-sort" value="desc" onchange="loadPage(1)" checked> Newest First</label>
                    <label><input type="radio" name="date-sort" value="asc" onchange="loadPage(1)"> Oldest First</label>
                    </div>
                </div>
            </div>

        </div>

        <!-- Right Content: Search Bar and Job List -->
        <div id="content">
            <!-- Search Bar -->
            <div class="job-search">
                <input type="text" id="search-input" placeholder="Search job title..." oninput="debouncedSearch()">
            </div>

            <!-- Job List -->
            <div class="job-list">
            </div>

            <div class="pagination">
                <a style="cursor: pointer;" id="prev-btn"><</a>
                <span id="pagination-numbers"></span>
                <a style="cursor: pointer;" id="next-btn">></a>
            </div>
        </div>
    </section>

    <?php
        require_once __DIR__ . '/../models/company.php';
        // Assume you have a logged-in user with a valid session
        $userId = $_SESSION['user_id'];

        // Fetch the company details using the user ID
        $companyDetails = CompanyModel::getCompanyById($userId);
        $companyInfo = CompanyModel::getCompanyInfoById($userId);
        ?>

    <!-- Modal for Edit Profile -->
    <div id="editProfileModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Edit Profile</h2>
            <form id="editProfileForm">
                <!-- Form fields for profile editing -->
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($_SESSION['name']); ?>" required>

                <label for="username">Username:</label> 
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($companyInfo['username'] ?? ''); ?>" required>
                
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['email']); ?>" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" value="<?php echo htmlspecialchars($companyInfo['password']); ?>"required>

                <label for="location">Location:</label>
                <input type="text" id="location" name="location" value="<?php echo htmlspecialchars($companyDetails['company_location'] ?? ''); ?>" required>

                <label for="about">About:</label>
                <textarea id="about" name="about" required><?php echo htmlspecialchars($companyDetails['about'] ?? ''); ?></textarea>
                
                <button type="submit" name="submit button">Save Changes</button>
            </form>
        </div>
    </div>

    <script src="/public/home-company.js"></script>
    <script src="/public/toast.js"></script>
    <script>
        document.getElementById('editProfileForm').addEventListener('submit', function (event) {
            event.preventDefault();

            const formData = new FormData(this);

            fetch('/edit-profile-company', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log(response);
                if (response.status === 200) {
                    // console.log('Profile updated successfully.');
                    // Close the modal
                    const modal = document.getElementById('editProfileModal');
                    modal.style.display = 'none';

                    // Refresh the page to show updated data
                    window.location.reload();
                } else {
                    alert('Failed to update profile: ' + (data.message || 'Unknown error'));
                }
            })
            .catch(error => {
                // console.log('Profile updated successfully.');
                // // Close the modal
                // const modal = document.getElementById('editProfileModal');
                // modal.style.display = 'none';

                // Refresh the page to show updated data
                // window.location.reload();
                console.error('Error:', error);
            });
        });

    </script>
<?php
    if (isset($_SESSION['login'])): ?>
    <script>
        showToast('Login Successful!'); // This will trigger the toast when the page loads
    </script>
    <?php
    // Unset the session variable to ensure it only shows once
    unset($_SESSION['login']);
endif;
?>
<script>
const urlParams = new URLSearchParams(window.location.search);
const errorMessage = urlParams.get('err');

// If 'err' exists, show the toast with the error message
if (errorMessage) {
  showToast(errorMessage);
}
</script>
</body>
</html>
