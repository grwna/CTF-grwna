<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Lowongan</title>
    <link rel="stylesheet" href="/public/css/detail-lowongan-company.css">
</head>
<body>
    <!-- HEADER SECTION -->
    <?php require __DIR__.'/../includes/header-company.php'?>

    <div class="job-overview-container">
        <div class="job-info-container">
            <img src="/public/assets/company-profile.svg" alt="company-logo" id="company-logo">
            <div class="job-info-c">
                <h2 id="job-title"><?php echo $job["title"];?></h2>
                <div class="job-info-container-1">
                    <p><?php echo $company["name"];?> • <?php echo $company["location"];?> (<?php echo $job["location_type"];?>) • <?php echo $jobTotalApplicants;?> applicants</p>
                </div>
                <div class="job-info-container-2">
                <p> <?php if ($job["is_open"] == true) { echo "Open"; } else { echo "Closed"; } ?> • <?php echo $job["posted"]; ?> • <?php echo $job["updated"]; ?></p>
                </div>
            </div>
        </div>
        <div class="button-container">
            <!-- <button id="view-applicants-button" onclick="window.location.href='/applicants-detail-company?vacancy_id=<?php echo urlencode($job['id']); ?>'">View Applicants</button> -->
            <button id="edit-job-button" onclick="window.location.href='/edit-lowongan?vacancy_id=<?php echo urlencode($job['id']); ?>'">Edit Job</button>

            <form method="POST" action="/job-detail-company" onsubmit="return confirm('Are you sure you want to delete this job?');" style="display: inline;">
                <input type="hidden" name="vacancy_id" value="<?php echo $job['id']; ?>">
                <input type="hidden" name="action" value="delete"> 
                <button id="delete-job-button" type="submit">Delete Job</button>
            </form> 

            <?php if ($job["is_open"] == true) : ?>
                <form method="POST" action="/job-detail-company" onsubmit="return confirm('Are you sure you want to close this job?');" style="display: inline;">
                    <input type="hidden" name="vacancy_id" value="<?php echo $job['id']; ?>">
                    <input type="hidden" name="action" value="close"> 
                    <button id="close-job-button" type="submit">Close Job</button>
                </form>
            <?php else : ?>
                <form method="POST" action="/job-detail-company" onsubmit="return confirm('Are you sure you want to open this job?');" style="display: inline;">
                    <input type="hidden" name="vacancy_id" value="<?php echo $job['id']; ?>">
                    <input type="hidden" name="action" value="open"> 
                    <button id="open-job-button" type="submit">Open Job</button>
                </form>
            <?php endif; ?>

        </div>
    </div>
    <div class="main-body-container">
        <main>

            <div class="main-container">
                <div class="job-details-container">
                    <div class="job-description-container">
                        <h1 class="container-title">Job Description</h1>
                        <p class="container-p" id="job-description">
                            <?php echo $job["description"];?>
                        </p>
                    </div>
        
                    <div class="right-side-container">
                        <div class="industry-employment-type">
                            <div class="industry-container">
                                <h1 class="container-title">About</h1>
                                <p class="container-p" id="industry"><?php echo $company["about"];?></p>
                            </div>
                            <div class="employment-type-container">
                                <h1 class="container-title">Employment Type</h1>
                                <p class="container-p" id="employment-type"><?php echo $job["job_type"];?></p>
                            </div>
                        </div>

                        <div class="workplace-insight">
                            <h3>Workplace Insight</h3>
                                <div class="carousel-container">
                                    <div class="carousel" id="carousel"></div>
                                    <p id="no-images-message" style="display: none;">No images available for this job.</p>
                                        
                                        <button class="carousel-prev" onclick="moveSlide(-1)">&#10094;</button>
                                        <button class="carousel-next" onclick="moveSlide(1)">&#10095;</button>
                                </div>
                        </div>
                        
                    </div>
                </div>


                <!-- Main Content Area for Job Listings -->
                <section id="main">
                    <!-- Job Listings -->
                    <h2>Applicant List</h2>
                    <div id="job-listings-id" class="job-listings">
                    </div>
        
                    <!-- Pagination -->
                    <div class="pagination">
                        <a style="cursor: pointer;" id="prev-btn"><</a>
                        <span id="pagination-numbers"></span>
                        <a style="cursor: pointer;" id="next-btn">></a>
                    </div>
                </section>
            </div>
        </main>
    </div>
    <!-- FOOTER SECTION -->
    <?php require __DIR__.'/../includes/footer.php'?>
    <script src="/public/carousel.js"></script>
    <script src="/public/applicants-pagination.js"></script>
    <script src="/public/detail-lowongan-company.js"></script>
</body>
</html>