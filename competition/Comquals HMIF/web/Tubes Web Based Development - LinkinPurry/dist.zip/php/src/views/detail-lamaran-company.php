<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Lowongan</title>
    <link rel="stylesheet" href="/public/css/detail-lamaran-company.css">
    <link href="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.snow.css" rel="stylesheet" />
</head>
<body>
    <!-- HEADER SECTION -->
    <?php require __DIR__.'/../includes/header-company.php'?>

    <main>
        <div class="job-overview-container">
            <div class="job-info-container">
                <img src="/public/assets/company-profile.svg" alt="company-logo" id="company-logo">
                <div class="job-info-c">
                    <h2 id="job-title"><?php echo $job["title"];?></h2>
                    <div class="job-info-container-1">
                        <p><?php echo $company["name"];?> • <?php echo $company["location"];?> (<?php echo $job["location_type"];?>) • <?php echo $job["job_type"]?></p>
                    </div>
                    <div class="job-info-container-2">
                        <p><?php if ($job["is_open"] == true) { echo "Open"; } else { echo "Closed"; } ?> • <?php echo $job["posted"]; ?> • <?php echo $job["updated"]; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- <div class="applicants-section-container">
            <div class="list-of-applicants">
                <div class="list-title">
                    <h3> applicants</h3>
                </div>
                <div class="applicants-from-list" onclick="showApplicant('annisa')">
                    <div class="list-applicant-detail">
                        <p class="applicant-name">Annisa Sarah</p>
                        <p class="applicant-upload-date">Applied 1 week ago</p>
                    </div>
                    <div class="applicant-status">
                        <img src="/public/assets/waiting-status.svg" alt="status">
                    </div>
                </div>
                <div class="applicants-from-list" onclick="showApplicant('rakha')">
                    <div class="list-applicant-detail">
                        <p class="applicant-name">Lala Kalula</p>
                        <p class="applicant-upload-date">Applied 3 weeks ago</p>
                    </div>
                    <div class="applicant-status">
                        <img src="/public/assets/accepted-status.svg" alt="status">
                    </div>
                </div>
                <div class="applicants-from-list" onclick="showApplicant('brigitta')">
                    <div class="list-applicant-detail">
                        <p class="applicant-name">Raffa Raharja</p>
                        <p class="applicant-upload-date">Applied 1 month ago</p>
                    </div>
                    <div class="applicant-status">
                        <img src="/public/assets/rejected-status.svg" alt="status">
                    </div>
                </div>
            </div> -->

            <div class="individual-data">
                <div class="applicant-details">
                    <div class="applicants">
                        <div class="applicant-detail">
                            <img src="/public/assets/profile.svg" alt="profile-picture" class="ind-applicant-picture">
                            <div class="ind-applicant-info">
                                <p class="ind-applicant-name"><?php echo $applicantDetail['name'];?></p>
                                <p class="ind-applicant-email"><?php echo $applicantDetail['email'];?></p>
                                <p class="ind-applicant-upload-date">Applied at : <?php echo $applicantDetail['applied_date'];?></p>
                            </div>
                        </div>
                        <div class="applicant-status">
                            <?php
                            $statusImage = '';
                            $statusAlt = '';

                            switch ($applicantDetail['status']) {
                                case 'waiting':
                                    $statusImage = '/public/assets/waiting-status.svg';
                                    $statusAlt = 'Waiting status';
                                    break;
                                case 'accepted':
                                    $statusImage = '/public/assets/accepted-status.svg';
                                    $statusAlt = 'Accepted status';
                                    break;
                                case 'rejected':
                                    $statusImage = '/public/assets/rejected-status.svg';
                                    $statusAlt = 'Rejected status';
                                    break;
                                default:
                                    $statusImage = '/public/assets/default-status.svg';
                                    $statusAlt = 'Status not available';
                                    break;
                            }
                            ?>
                            <img src="<?php echo $statusImage; ?>" alt="<?php echo $statusAlt; ?>">
                        </div>
                    </div>
                    <!-- Embed CV as a PDF -->
                    <h3>Applicant's CV</h3>
                    <embed  src="/api/get-cv-for-company?file=<?=$filename?>&vacancy_id=<?=$vacancyId?>" id='jobseeker-cv' type="application/pdf" width="100%" height="300px" />
                    <!-- <?php var_dump($applicantDetail['video_path']);?> -->
                    <?php if (!empty($applicantDetail['video_path'])) : ?>
                        <h3>Applicant's Video Submission</h3>
                            <!-- Embed video -->
                        <video controls width="100%">
                            <source src="/api/get-video-for-company?file=<?php echo urlencode($applicantDetail['video_path']); ?>&vacancy_id=<?php echo $vacancyId; ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif;?>

                    <!-- <h3>CV</h3>
                    <embed class="applicant-cv" src="/public/assets/dummy-pdf.pdf" type="application/pdf">
                    <h3>Video</h3>
                    <video class="applicant-video" autoplay controls>
                        <source src="/public/assets/videoplayback.mp4" type="video/mp4">
                        Your browser does not support the video tag.
                    </video> -->
                    <?php if ($applicantDetail['status'] === 'waiting') : ?>
                        <form action="/applicants-detail-company" method="post">
                            <h3>Feedback for Applicant</h3>
                            <input type="hidden" name="application_id" value="<?php echo $applicantDetail['application_id']; ?>">
                            <input type="hidden" name="status" id="status">
                            <input type="hidden" name="description" id="reasoneditor">
                            <div id="editor"></div>
                            <div class="button-container">
                                <button type="submit" class="form-button" id="button-reject" onclick="setStatus('rejected')">Reject</button>
                                <button type="submit" class="form-button" id="button-accept" onclick="setStatus('accepted')">Accept</button>
                            </div>
                        </form>
                    <?php else : ?>
                        <h3>Feedback Status</h3>
                        <p><?php echo $applicantDetail['status_reason']; ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- FOOTER SECTION -->
    <?php require __DIR__.'/../includes/footer.php'?>

    <!-- JAVASCRIPT -->
    <script src="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.js"></script>
    <script>
        const quill = new Quill('#editor', {
            theme: 'snow'
        });

        const form = document.querySelector('form');
        form.onsubmit = () => {
            document.querySelector('#reasoneditor').value = quill.root.innerHTML;
        };

        function setStatus(value) {
            document.querySelector('#status').value = value;
            form.submit(); 
        };
    </script>
</body>
</html>