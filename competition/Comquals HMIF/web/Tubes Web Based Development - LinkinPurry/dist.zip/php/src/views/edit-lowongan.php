<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Lowongan</title>
    <link rel="stylesheet" href="/public/css/add-lowongan.css">
    <link href="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.snow.css" rel="stylesheet" />
</head>
<body>
    <!-- HEADER SECTION -->
    <?php require __DIR__.'/../includes/header-company.php'?>

    
    <main>
        <?php if(isset($jobDetails)) : ?>
            <div class="publish-job-container">
                <div class="job-form-advice-container">
                    <img src="/public/assets/bulb-icon.svg" alt="info-icon">
                    <div class="advice-container">
                        <p class="advice-points">Target your job to the right people</p>
                        <p class="advice-explanation">Include an informative job description and add relevant images to target job seekers who match your criteria.</p>
                    </div>
                    <div class="advice-container">
                        <p class="advice-points">What information can applicants see about me and my job?</p>
                        <p class="advice-explanation">When you post your job, you agree to share details about your job such as company location</p>
                    </div>
                </div>
                
                <div class="job-form-container">
                    <div class="form-header">
                        <h1>Publish Job Details</h1>
                    </div>
                    <form action="/edit-lowongan?vacancy_id=<?php echo urlencode($jobDetails['vacancy_id'])?>" method="POST" enctype="multipart/form-data">
                        <div class="form-content">
                            <p id="additional-info"><sup>*</sup>Indicates required</p>

                            <div class="job-title-container">
                                <label for="job-title">Job Title<sup>*</sup></label>
                                <input type="text" id="job-title" name="job-title" value="<?php echo $job['title']; ?>" required>
                            </div>
                            
                            <div class="dropdown-container">
                                <div class="job-type-container">
                                    <label for="job-type">Job Type<sup>*</sup></label>
                                    <select name="job-type" id="job-type">
                                        <option value="Full-time" <?php echo ($job['job_type'] === "Full-time") ? 'selected' :''?>>Full-time</option>
                                        <option value="Part-time" <?php echo ($job['job_type'] === "Part-time") ? 'selected' :''?>>Part-time</option>
                                        <option value="Internship" <?php echo ($job['job_type'] === "Internship") ? 'selected' :''?>>Internship</option>
                                    </select required>
                                </div>

                                <div class="job-workplace-type-container">
                                    <label for="job-workplace-type">Workplace Type<sup>*</sup></label>
                                    <select name="job-workplace-type" id="job-workplace-type">
                                        <option value="On-site" <?php echo ($job['location_type'] === "On-site") ? 'selected' :''?>>On-Site</option>
                                        <option value="Hybrid" <?php echo ($job['location_type'] === "Hybrid") ? 'selected' :''?>>Hybrid</option>
                                        <option value="Remote" <?php echo ($job['location_type'] === "Remote") ? 'selected' :''?>>Remote</option>
                                    </select required>
                                </div>      
                            </div>

                            <div class="job-description-container">
                                <p id="desc-title">Description<sup>*</sup></p>
                                <!-- Create the editor container -->
                                <input type="hidden" name="description" id="hiddenDesc">
                                <div id="editor">
                                    <?php echo $job['description']; ?>
                                </div>
                            </div>

                            <div class="job-image-container">
                                <label for="job-image">Image Attachments</label>
                                <div class="job-input-button">
                                    <input type="file" id="inpFile" name="job-image[]" accept=".jpg,.jpeg,.png" multiple>
                                </div>
                            </div>
                        </div>

                        <div class="button-container">
                            <!-- <button type="submit" class="form-button" name="action" value="back" id="button-back">Back</button> -->
                            <button type="submit" class="form-button" name="action" value="post" id="button-post">Post</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php else : ?>
            <p>Job details not found!</p>
        <?php endif; ?>
    </main>

    <!-- FOOTER SECTION -->
    <?php require __DIR__.'/../includes/footer.php'?>

    <!-- Include the Quill library -->
    <script src="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.js"></script>

    <!-- Initialize Quill editor -->
    <script>
    const quill = new Quill('#editor', {
        theme: 'snow'
    });

    // Update the hidden input on form submission
    const form = document.querySelector('form');
    form.onsubmit = () => {
        document.querySelector('#hiddenDesc').value = quill.root.innerHTML;
    };

    // const inpFile = document.getElementById('inpFile');
    // const btnUpload = document.getElementById('btnUpload');

    // btnUpload.addEventListener("click", function() {
    //     const xhr = new XMLHttpRequest();
    //     const formData = new FormData();

    //     for (const file of inpFile.files) {
    //         formData.append("myFiles[]", file);
    //     }

    //     xhr.open("POST", "upload.php", true);
    //     xhr.onload = function() {
    //         if (xhr.status === 200) {
    //             console.log("Upload successful");
    //         } else {
    //             console.log("Upload failed");
    //         }
    //     };
    //     xhr.send(formData);
    // });
    </script>
</body>