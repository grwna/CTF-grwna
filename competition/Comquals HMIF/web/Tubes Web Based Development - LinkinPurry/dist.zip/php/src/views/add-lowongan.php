<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Lowongan</title>
    <link rel="stylesheet" href="/public/css/add-lowongan.css">
    <link href="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.snow.css" rel="stylesheet" />
</head>
<body>
    <!-- HEADER SECTION -->
    <?php require __DIR__.'/../includes/header-company.php'?>

    <main>
        <div class="publish-job-container">
            <div class="job-form-advice-container">
                <img src="/public/assets/bulb-icon.svg" alt="info-icon">
                <div class="advice-container">
                    <p class="advice-points">Target your job to the right people</p>
                    <p class="advice-explanation">Include an informative job description and add relevant images to target job seekers who match your criteria.</p>
                </div>
                <div class="advice-container">
                    <p class="advice-points">What information can applicants see about me and my job?</p>
                    <p class="advice-explanation">When you post your job, you agree to share details about your job such as company location</p>
                </div>
            </div>
            <div class="job-form-container">
                <div class="form-header">
                    <h1>Publish Job Details</h1>
                </div>
                <form action="/add-lowongan" method="POST" enctype="multipart/form-data">
                    <div class="form-content">
                        <p id="additional-info"><sup>*</sup>Indicates required</p>

                        <div class="job-title-container">
                            <label for="job-title">Job Title<sup>*</sup></label>
                            <input type="text" id="job-title" name="job-title" required>
                        </div>
                        
                        <div class="dropdown-container">
                            <div class="job-type-container">
                                <label for="job-type">Job Type<sup>*</sup></label>
                                <select name="job-type" id="job-type">
                                    <option value="Full-time">Full-time</option>
                                    <option value="Part-time">Part-time</option>
                                    <option value="Internship">Internship</option>
                                </select required>
                            </div>

                            <div class="job-workplace-type-container">
                                <label for="job-workplace-type">Workplace Type<sup>*</sup></label>
                                <select name="job-workplace-type" id="job-workplace-type">
                                    <option value="On-site">On-Site</option>
                                    <option value="Hybrid">Hybrid</option>
                                    <option value="Remote">Remote</option>
                                </select required>
                            </div>      
                        </div>

                        <div class="job-description-container">
                            <p id="desc-title">Description<sup>*</sup></p>
                            <!-- Create the editor container -->
                            <input type="hidden" name="description" id="description">
                            <div id="editor">Tips: Provide a summary of the role, what success in the position looks like, and how this role fits into the organization overall.<br><br>Responsibilities<br>[Be specific when describing each of the responsibilities. Use gender-neutral, inclusive language.]<br>Example: Determine and develop user requirements for systems in production, to ensure maximum usability<br><br>Qualifications<br>[Some qualifications you may want to include are Skills, Education, Experience, or Certifications.]<br>Example: Excellent verbal and written communication skills
                            </div>
                        </div>

                        <div class="job-image-container">
                            <label for="job-image">Image Attachments</label>
                            <div class="job-input-button">
                                <input type="file" id="job-image" name="job-image[]" accept=".jpg,.jpeg,.png" multiple>
                            </div>
                        </div>
                    </div>

                    <div class="button-container">
                        <!-- <a href="/company-dashboard" class="form-button" id="button-back">Back</a> -->
                        <button type="submit" class="form-button" name="action" value="post" id="button-post">Post</button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <!-- FOOTER SECTION -->
    <?php require __DIR__.'/../includes/footer.php'?>

    <!-- Include the Quill library -->
    <script src="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.js"></script>
    <script src="/public/toast.js"></script>
    <!-- Initialize Quill editor -->
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const quill = new Quill('#editor', {
            theme: 'snow'
        });

        // Update the hidden input on form submission
        const form = document.querySelector('form');
        form.onsubmit = () => {
            document.querySelector('#description').value = quill.root.innerHTML;
        };

    });
    </script>
    <script>
        const urlParams = new URLSearchParams(window.location.search);
        const errorMessage = urlParams.get('err');

        // If 'err' exists, show the toast with the error message
        if (errorMessage) {
            showToast(errorMessage);
        }
    </script>
</body>