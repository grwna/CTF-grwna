<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Landing Page</title>
    <link rel="stylesheet" href="/public/css/landing-view.css">
</head>

<body>
    <header class="header">
        <div class="container">
            <img src="/public/assets/linkinpurry.svg" alt="LinkedIn Logo" class="logo">
            <div class="auth-buttons">
                <a href="/job-list" class="jobs" id="nav-status">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" data-supported-dps="24x24" fill="currentColor" class="mercado-match" width="24" height="24" focusable="false">
                        <path d="M22.84 10.22L21 6h-3.95V5a3 3 0 00-3-3h-4a3 3 0 00-3 3v1H2l2.22 5.18A3 3 0 007 13h14a2 2 0 001.84-2.78zM15.05 6h-6V5a1 1 0 011-1h4a1 1 0 011 1zM7 14h15v3a3 3 0 01-3 3H5a3 3 0 01-3-3V8.54l1.3 3A4 4 0 007 14z"></path>
                    </svg>
                    <p>Jobs</p>
                </a>
                <a href="/signup" class="join-now">Join now</a>
                <a href="/login" class="sign-in">Sign in</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="welcome-container">
            <h1>Welcome to your purr-fessional community</h1>

            <div class="login-options">
                <div class="email-log-in" onclick="window.location.href='/login'">
                    <button>Login</button>
                </div>

                <!-- <div class="email-sign-in">
                    <button>Sign in with email</button>
                </div> -->

                <p class="legal-text">
                    By clicking Continue to join or sign in, you agree to LinkInPurry’s <a href="#">User Agreement</a>, <a
                        href="#">Privacy Policy</a>, and <a href="#">Cookie Policy</a>.
                </p>
            </div>

            <div class="new-to-linkedin">
                <p>New to LinkInPurry? <a href="/signup">Join now</a></p>
                <!-- <img src="public/assets/landingpage-illustration.svg" alt="Illustration" class="illustration"> -->
                <img src="public/assets/perry-3.webp" alt="Illustration" class="illustration">
              </div>
        </div>

        <section class="explore-section">
            <h2>About this website</h2>
            <p>Nope, you're not on LinkedIn—welcome to the much cooler, platypus-powered world of <strong> LinkInPurry</strong>! This quirky corner of the internet was created by three adventurous students, Denise, Edbert, and Andhita, as part of their epic school project. We hope you enjoy exploring the job opportunities here and maybe learn something new along the way. Thanks for stopping by, and who knows—you might just bump into Agent P on your way! Enjoy the search... *strange platypus noises*!</p>
        </section>
    </main>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
</body>
</html>