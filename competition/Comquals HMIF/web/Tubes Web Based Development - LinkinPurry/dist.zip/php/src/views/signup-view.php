<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <link rel="stylesheet" href="/public/css/signup-view.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <img src="/public/assets/linkinpurry.svg"
                 alt="LinkedIn Logo" class="logo">
            <div class="auth-buttons">
                <a href="/job-list" class="jobs" id="nav-status">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" data-supported-dps="24x24" fill="currentColor" class="mercado-match" width="24" height="24" focusable="false">
                        <path d="M22.84 10.22L21 6h-3.95V5a3 3 0 00-3-3h-4a3 3 0 00-3 3v1H2l2.22 5.18A3 3 0 007 13h14a2 2 0 001.84-2.78zM15.05 6h-6V5a1 1 0 011-1h4a1 1 0 011 1zM7 14h15v3a3 3 0 01-3 3H5a3 3 0 01-3-3V8.54l1.3 3A4 4 0 007 14z"></path>
                    </svg>
                    <p>Jobs</p>
                </a>
                <a href="/signup" class="join-now">Join now</a>
                <a href="/login" class="sign-in">Sign in</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="form-card-container">
            <h1>Join Our Community</h1>
            <p>Connect with purr-fessionals around the world</p>
            <div class="toggle-buttons">
                <button type="button" id="jobSeekerBtn" class="active">Job Seeker</button>
                <button type="button" id="companyBtn">Company</button>
            </div>
            
            <!-- Signup Form -->
            <form action="/signup" method="post" id="signupForm">
                <!-- Job Seeker Form Fields -->
                <div class="job-seeker-fields" style="display: block;">
                    <div class="input-group">
                        <label for="name">Name: <span class="required">*</span></label>
                        <input type="text" name="name" placeholder="Your Name" required>
                    </div>
                    <div class="input-group">
                        <label for="username">Userame: <span class="required">*</span></label>
                        <input type="text" name="username" placeholder="Your Username" required>
                    </div>
                    <div class="input-group">
                        <label for="email">Email: <span class="required">*</span></label>
                        <input type="email" name="email" placeholder="example@example.com" required>
                    </div>
                    <div class="input-group">
                        <label for="password">Password: <span class="required">*</span></label>
                        <input type="password" name="password" placeholder="Your Password" required>
                    </div>
                    <div class="input-group">
                        <label for="confirm-password">Confirm Password: <span class="required">*</span></label>
                        <input type="password" name="confirm-password" placeholder="Confirm Password" required>
                    </div>
                </div>

                <!-- Company Form Fields -->
                <div class="company-fields" style="display:none;">
                    <div class="input-group">
                        <label for="name">Company Name: <span class="required">*</span></label>
                        <input type="text" name="name" placeholder="Your Company Name" required disabled>
                    </div>
                    <div class="input-group">
                        <label for="username">Company Userame: <span class="required">*</span></label>
                        <input type="text" name="username" placeholder="Your Company Username" required disabled>
                    </div>
                    <div class="input-group">
                        <label for="email">Company Email: <span class="required">*</span></label>
                        <input type="email" name="email" placeholder="example@company.com" required disabled>
                    </div>
                    <div class="input-group">
                        <label for="password">Password: <span class="required">*</span></label>
                        <input type="password" name="password" placeholder="Your Password" required disabled>
                    </div>
                    <div class="input-group">
                        <label for="confirm-password">Confirm Password: <span class="required">*</span></label>
                        <input type="password" name="confirm-password" placeholder="Confirm Password" required disabled>
                    </div>
                    <div class="input-group">
                        <label for="location">Location: <span class="required">*</span></label>
                        <input type="text" name="location" placeholder="Company Location" required disabled>
                    </div>
                    <div class="input-group">
                        <label for="about">About: <span class="required">*</span></label>
                        <!-- <input type="about" name="company-description" placeholder="Tell us about your company" required> -->
                        <textarea name="about" placeholder="Tell us about your company" required disabled></textarea>
                    </div>
                </div>

                <input type="hidden" name="role" value="jobseeker" id="roleInput">
                <button type="submit" id="signUpBtn">Sign Up</button>
            </form>
        </div>
    </main>

    <script>
        document.getElementById('jobSeekerBtn').addEventListener('click', function() {
            // show job seeker form and hide company form
            document.querySelector('.job-seeker-fields').style.display = 'block';
            document.querySelector('.company-fields').style.display = 'none';
            
            // active to job seeker
            this.classList.add('active');
            document.getElementById('companyBtn').classList.remove('active');

            // Enable job seeker inputs and disable company inputs
            enableInputs('.job-seeker-fields');
            disableInputs('.company-fields');

            document.getElementById('roleInput').value = 'jobseeker';
        });

        document.getElementById('companyBtn').addEventListener('click', function() {
            // show company form and hide job seeker form
            document.querySelector('.job-seeker-fields').style.display = 'none';
            document.querySelector('.company-fields').style.display = 'block';
            
            // company active
            this.classList.add('active');
            document.getElementById('jobSeekerBtn').classList.remove('active');

            // Enable company inputs and disable job seeker inputs
            enableInputs('.company-fields');
            disableInputs('.job-seeker-fields');

            document.getElementById('roleInput').value = 'company';
        });

        // Function to disable all inputs in a given form section
        function disableInputs(section) {
            const inputs = document.querySelectorAll(section + ' input, ' + section + ' textarea');
            inputs.forEach(input => input.setAttribute('disabled', 'disabled'));
        }

        // Function to enable all inputs in a given form section
        function enableInputs(section) {
            const inputs = document.querySelectorAll(section + ' input, ' + section + ' textarea');
            inputs.forEach(input => input.removeAttribute('disabled'));
            inputs.forEach(input => {
                input.removeAttribute('disabled');
                console.log('Enabled:', input);  // Debugging line
            });
        }

        // Handle the form submit event
        document.getElementById('signupForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission

            // Get form data
            const formData = new FormData(this);

            // Submit data using fetch
            fetch('/signup', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.ok) {
                    // Redirect to login page if signup is successful
                    window.location.href = '/login';
                } else {
                    return response.text().then(text => {
                        // Show error to the user if there is a failure
                        showToast(text);
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred during signup. Please try again.');
            });
        });

    </script>

    <script src="/public/toast.js"></script>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
</body>
</html>
