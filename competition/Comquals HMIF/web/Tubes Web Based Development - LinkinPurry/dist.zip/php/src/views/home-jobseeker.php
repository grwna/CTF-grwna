<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage - Jobseeker</title>
    <link rel="stylesheet" href="public/css/home-jobseeker.css">
</head>
<body>
    <!-- HEADER SECTION -->
    <section>
        <?php require __DIR__.'/../includes/header-jobseeker.php'?>
    </section>

    <section id="content">
        <!-- Fixed Sidebar for Profile and Filters -->
        <div class="sidebar">
            <!-- Profile Section -->
            <section class="profile-section">
                <div class="banner">
                    <img src="/public/assets/banner.svg" alt="Banner Image" class="banner-img">
                </div>
                <div class="profile-header">
                    <img src="/public/assets/profile.svg" alt="Profile" class="profile-pic">
                    <div class="profile-info">
                        <?php echo '<h1>'.$_SESSION['name'].'</h1>'; ?>
                        <p>I'm looking for job! Please hire me!</p>
                        <?php echo '<p>'.$_SESSION['email'].'</p>'; ?>
                    </div>
                </div>
            </section>

            <!-- Job Filters Section -->
            <section id="job-filter" class="filter-section">
                <h3>Filter Jobs</h3>

                <!-- Job Type Filter -->
                <div class="filter-group">
                    <button class="filter-toggle" data-filter="job-types">
                        <span class="filter-text">All Job Types</span>
                        <span class="filter-icon">+</span>
                    </button>
                    <div class="filter-options" id="job-types" style="display: none;">
                        <label><input type="checkbox" value="full-time" onchange="loadPage(1)"> Full-time</label>
                        <label><input type="checkbox" value="part-time" onchange="loadPage(1)"> Part-time</label>
                        <label><input type="checkbox" value="contract" onchange="loadPage(1)"> Contract</label>
                    </div>
                </div>

                <!-- Location Filter -->
                <div class="filter-group">
                    <button class="filter-toggle" data-filter="locations">
                        <span class="filter-text">All Locations</span>
                        <span class="filter-icon">+</span>
                    </button>
                    <div class="filter-options" id="locations" style="display: none;">
                        <label><input type="checkbox" value="on-site" onchange="loadPage(1)"> On-site</label>
                        <label><input type="checkbox" value="hybrid" onchange="loadPage(1)"> Hybrid</label>
                        <label><input type="checkbox" value="remote" onchange="loadPage(1)"> Remote</label>
                    </div>
                </div>

                <!-- Date Sorting -->
                <div class="filter-group">
                    <button class="filter-toggle" data-filter="date-sort">
                        <span class="filter-text">Sort by Date</span>
                        <span class="filter-icon">+</span>
                    </button>
                    <div class="filter-options" id="date-sort" style="display: none;">
                        <label><input type="radio" name="date-sort" value="desc" onchange="loadPage(1)" checked> Newest First</label>
                        <label><input type="radio" name="date-sort" value="asc" onchange="loadPage(1)"> Oldest First</label>
                    </div>
                </div>
            </section>
        </div>

        <!-- Main Content Area for Job Listings -->
        <section id="main">
            <!-- Search Input -->
            <input type="text" id="search-input" placeholder="Search job title..." oninput="debouncedSearch()">
            
            <!-- Job Listings -->
            <div id="job-listings-id" class="job-listings"></div>

            <!-- Pagination -->
            <div class="pagination">
                <a style="cursor: pointer;" id="prev-btn"><</a>
                <span id="pagination-numbers"></span>
                <a style="cursor: pointer;" id="next-btn">></a>
            </div>
        </section>

        <section id="recommendations">
            <h3>Top Job Recommendations</h3>
            <div class="recommendation-card">
                <!-- contoh only -->
                <h4>Software Engineer</h4>
                <p>Company ABC</p>
                <p>Full-time, Remote</p>
            </div>
            <div class="recommendation-card">
                <h4>Product Manager</h4>
                <p>Company XYZ</p>
                <p>On-site, Full-time</p>
            </div>
        </section>

    </section>

    <section>
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
    </section>

    <script src="public/pagination.js"></script>
    <script src="public/toast.js"></script>
    <script src="public/home-jobseeker.js"></script>
    <script>
        document.querySelectorAll('.filter-toggle').forEach(button => {
            button.addEventListener('click', function() {
                const filterId = this.getAttribute('data-filter');
                const filterOptions = document.getElementById(filterId);
                const icon = this.querySelector('.filter-icon');

                if (filterOptions.style.display === 'block') {
                    filterOptions.style.display = 'none';
                    icon.textContent = '+'; // Change back to "+"
                } else {
                    filterOptions.style.display = 'block';
                    icon.textContent = '-'; // Change to "-"
                }
            });
        });
    </script>
<?php
    if (isset($_SESSION['login'])): ?>
    <script>
        window.onload = function() {
            showToast('Login Successful!'); // This will trigger the toast when the page loads
        };
    </script>
    <?php
    // Unset the session variable to ensure it only shows once
    unset($_SESSION['login']);
endif;
?>
</body>
</html>
