<?php

require_once __DIR__.'/../config/db.php';

/**
 * Class to handle data related to DB for user
 */
class User {
    /**
     * Function to find data from db based on username
     */
    public static function findByUsername($username) {
        $db = dbConnect();
        $query = "SELECT user_id, name, password, role, email FROM users WHERE username = :username";
        $st = $db->prepare($query);

        // bind param for sqli proof
        $st->bindParam(':username', $username, PDO::PARAM_STR);

        // TODO: Create exception handling for execute
        //exec
        $st->execute();

        $user = $st->fetch(PDO::FETCH_ASSOC);

        // close the connection
        $db = null;

        return $user;
    }

    public static function findById($id){
        $db = dbConnect();
        $query = "SELECT user_id, name, password, role, email FROM users WHERE user_id = :id";
        $st = $db->prepare($query);

        // bind param for sqli proof
        $st->bindParam(':id', $id, PDO::PARAM_STR);

        // TODO: Create exception handling for execute
        //exec
        $st->execute();

        $user = $st->fetch(PDO::FETCH_ASSOC);

        // close the connection
        $db = null;

        return $user;
    }

    public static function addUserAccount($username, $name, $password, $email, $role){
        try {
            $db = dbConnect();
            $query = "INSERT INTO \"users\" (email, password, role, name, username) VALUES (:email, :password, :role, :name, :username)";
            $st = $db->prepare($query);
            
            $st->bindParam(":username", $username, PDO::PARAM_STR);
            $st->bindParam(":name", $name, PDO::PARAM_STR);
            $st->bindParam(":email", $email, PDO::PARAM_STR);
            $st->bindParam(":password", $password, PDO::PARAM_STR);
            $st->bindParam(":role", $role, PDO::PARAM_STR);
            
            $st->execute();

            $userId = $db->lastInsertId();
            // close connection
            $db = null;
            return $userId;
        } catch (PDOException $e) {
            error_log('Signup Database error: '.$e->getMessage());  // Optional logging
            throw $e;  // Rethrow the exception
        }
    }

    public static function addCompanyDetails($userId, $location, $about) {
        try {
            $db = dbConnect();
            $query = "INSERT INTO company_detail (user_id, location, about) VALUES (:user_id, :location, :about)";
            $st = $db->prepare($query);
            $st->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $st->bindParam(':location', $location, PDO::PARAM_STR);
            $st->bindParam(':about', $about, PDO::PARAM_STR);
            $st->execute();

            $db = null;
        } catch (PDOException $e) {
            throw $e;
        }
    }
}
?>