<?php

require_once __DIR__ . '/../config/db.php';

class JobModel {
    // Fungsi untuk menambah lowongan pekerjaan
    public static function submitJobVacancy($company_id, $position, $description, $job_type, $location_type) : void {
        try {
            $db = dbConnect();
            $stmt = $db->prepare("
            INSERT INTO job_vacancies (company_id, position, description, job_type, location_type)
            VALUES (:company_id, :position, :description, :job_type, :location_type)
            ");
            $stmt->bindParam(":company_id", $company_id, PDO::PARAM_STR);
            $stmt->bindParam(":position", $position, PDO::PARAM_STR);
            $stmt->bindParam(":description", $description, PDO::PARAM_STR);
            $stmt->bindParam(":job_type", $job_type, PDO::PARAM_STR);
            $stmt->bindParam(":location_type", $location_type, PDO::PARAM_STR);
            $stmt->execute();
            $db = null;
        } catch (PDOException $e) {
            error_log('Add Job Vacancy Database error: '.$e->getMessage());  // Optional logging
            throw $e;  // Rethrow the exception
        }
    } 

    // Fungsi untuk mengubah detail lowongan pekerjaan
        // Fungsi untuk mengubah detail lowongan pekerjaan
    public static function updateJobVacancy($vacancy_id, $position, $description, $job_type, $location_type) {
        try {
            $db = dbConnect();
            $stmt = $db->prepare("
                UPDATE job_vacancies 
                SET position = :position, description = :description, job_type = :job_type, location_type = :location_type
                WHERE vacancy_id = :vacancy_id");
            $stmt->bindParam(":vacancy_id", $vacancy_id, PDO::PARAM_INT);
            $stmt->bindParam(":position", $position, PDO::PARAM_STR);
            $stmt->bindParam(":description", $description, PDO::PARAM_STR);
            $stmt->bindParam(":job_type", $job_type, PDO::PARAM_STR);
            $stmt->bindParam(":location_type", $location_type, PDO::PARAM_STR);
            
            $stmt->execute();
            $db = null;
        } catch (PDOException $e) {
            error_log('Update Job Vacancy Database error: '.$e->getMessage());  
            throw $e;
        }
    }

    // Fungsi untuk menambah jumlah orang yang sudah pernah submit aplikasi
    public static function addNumberJobVacancyApplicant($vacancy_id) {
        try {
            $db = dbConnect();
            $stmt = $db->prepare("
                UPDATE job_vacancies
                SET count = count + 1
                WHERE vacancy_id = :vacancy_id
            ");
            
            // Bind the parameter and execute the query
            $stmt->bindParam(':vacancy_id', $vacancy_id, PDO::PARAM_INT);
            $stmt->execute();
            $db = null;
        } catch (PDOException $e) {
            error_log('Update jumlah peminat gagal');
            throw $e;
        }
    }


    // Fungsi untuk mengambil total jumlah pekerjaan
    public static function getTotalJobVacancies($company_id) {
        $db = dbConnect();

        // Query untuk menghitung total pekerjaan
        $query = "
            SELECT COUNT(*) as total_jobs
            FROM job_vacancies jv";

        if($company_id != null){
            $query .= ' AND jv.company_id = :company_id';
        }

        $stmt = $db->prepare($query);

        if($company_id != null){
            $stmt->bindParam(':company_id', $company_id, PDO::PARAM_STR);
        }

        $stmt->execute();
        $result = $stmt->fetch( PDO::FETCH_ASSOC);
        $db = null;
        return $result['total_jobs'];
    }

    public static function getTotalJobVacanciesFiltered($search, $jobType, $locationType, $company_id) {
        $db = dbConnect();

        // Query untuk menghitung total pekerjaan
        $query = "
            SELECT COUNT(*) as total_jobs
            FROM job_vacancies v
            JOIN users u
            ON v.company_id = u.user_id";

        // Add filters based on parameters
        if ($company_id != null){
            $query .= ' AND v.company_id = ?';
        }
        if (!empty($jobType)) {
            // Split the input string by commas to create an array
            $jobTypes = explode(',', $jobType);
            $jobTypes = array_map('strtolower', $jobTypes);
            $placeholders = implode(',', array_fill(0, count($jobTypes), '?'));
            $query .= " AND LOWER(job_type) IN ($placeholders)";
        }
        if (!empty($locationType)) {
            // Convert all location types to lowercase
            $locationTypes = explode(',', $locationType);
            $locationTypes = array_map('strtolower', $locationTypes); 
            $placeholders = implode(',', array_fill(0, count($locationTypes), '?'));
            $query .= " AND LOWER(location_type) IN ($placeholders)";
        }
        if ($search) {
            $query .= " AND LOWER(position) LIKE LOWER(?)"; // Use placeholders to prevent SQL injection
        }

        // Prepare the SQL statement
        $stmt = $db->prepare($query);

        $index = 1;
        if ($company_id != null){
            $stmt->bindValue($index, $company_id, PDO::PARAM_STR);
            $index++;
        }

        if (!empty($jobTypes)) {
            foreach ($jobTypes as $jobType) {
                $stmt->bindValue($index, $jobType, PDO::PARAM_STR);
                $index++;
            }
        }

        if (!empty($locationTypes)) {
            foreach ($locationTypes as $locationType) {
                $stmt->bindValue($index, $locationType, PDO::PARAM_STR);
                $index++;
            }
        }

        if ($search) {
            $stmt->bindValue($index, '%'.$search.'%', PDO::PARAM_STR);
            $index++;
        }


        $stmt->execute();
        $result = $stmt->fetch( PDO::FETCH_ASSOC);
        $db = null;
        return $result['total_jobs'];
    }   

    /**
     * Fungsi untuk mendapatkan pekerjaan degan filtered
     */
    public static function getJobVacanciesFiltered($offset, $limit, $search, $jobType, $locationType, $sortBy, $company_id){
        $db = dbConnect();
        $query = "
        SELECT
            v.vacancy_id,
            u.user_id as company_id,
            u.name as company_name,
            v.position,
            v.description,
            v.job_type,
            v.location_type,
            v.created_at
        from job_vacancies v
        JOIN users u
        ON v.company_id = u.user_id";

        // Add filters based on parameters
        if ($company_id != null) {
            $query .= ' AND company_id = ?';
        }
        if (!empty($jobType)) {
            // Split the input string by commas to create an array
            $jobTypes = explode(',', $jobType);
            $jobTypes = array_map('strtolower', $jobTypes);
            $placeholders = implode(',', array_fill(0, count($jobTypes), '?'));
            $query .= " AND LOWER(job_type) IN ($placeholders)";
        }
        if (!empty($locationType)) {
            // Convert all location types to lowercase
            $locationTypes = explode(',', $locationType);
            $locationTypes = array_map('strtolower', $locationTypes); 
            $placeholders = implode(',', array_fill(0, count($locationTypes), '?'));
            $query .= " AND LOWER(location_type) IN ($placeholders)";
        }
        if ($search) {
            $query .= " AND LOWER(position) LIKE LOWER(?)"; // Use placeholders to prevent SQL injection
        }
        if ($sortBy) {
            $query .= " ORDER BY u.name ASC, v.created_at $sortBy";
        }

        $query .= " LIMIT ? OFFSET ?";
        
        // Prepare the SQL statement
        $stmt = $db->prepare($query);
        
        $index = 1;
        if($company_id != null){
            $stmt->bindValue($index, $company_id, PDO::PARAM_INT);
            $index++;
        }

        if (!empty($jobTypes)) {
            foreach ($jobTypes as $jobType) {
                $stmt->bindValue($index, $jobType, PDO::PARAM_STR);
                $index++;
            }
        }
        
        if (!empty($locationTypes)) {
            foreach ($locationTypes as $locationType) {
                $stmt->bindValue($index, $locationType, PDO::PARAM_STR);
                $index++;
            }
        }
        
        if ($search) {
            $stmt->bindValue($index, '%' . $search . '%', PDO::PARAM_STR);
            $index++;
        }
        
        // Bind limit and offset
        $stmt->bindValue($index, (int)$limit, PDO::PARAM_INT);
        $stmt->bindValue($index + 1, (int)$offset, PDO::PARAM_INT);
        
        
        // Execute the query
        $stmt->execute();

        $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $db = null;

        return $jobs;
    }

    // Fungsi untuk mengambil pekerjaan dengan pagination
    public static function getJobVacancies($offset, $limit, $company_id) {
        $db = dbConnect();

        // Query untuk mengambil data lowongan kerja beserta detail perusahaan dengan limit dan offset
        $query = "
            SELECT 
                v.vacancy_id,
                u.user_id as company_id,
                u.name as company_name,
                v.position,
                v.description,
                v.job_type,
                v.location_type,
                v.created_at
            FROM job_vacancies v
            JOIN users u ON v.company_id = u.user_id";

        if ($company_id != null){
            $query .= ' AND company_id = :company_id';
        }
        
        $query .= " ORDER BY u.name ASC, v.created_at DESC
            LIMIT :limit OFFSET :offset";
            
        $stmt = $db->prepare($query);

        // Bind parameters untuk limit dan offset
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        
        if ($company_id != null){
            $stmt->bindParam(':company_id', $company_id, PDO::PARAM_INT);
        }

        $stmt->execute();
        $db = null;
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengambil pekerjaan berdasarkan vacancy_id
    public static function getJobVacancyById($vacancyId) {
        global $db;
        $db = dbConnect();

        // Query untuk mengambil data pekerjaan berdasarkan vacancy_id
        $stmt = $db->prepare("
            SELECT 
                v.vacancy_id,
                u.user_id as company_id,
                u.name as company_name,
                c.location as company_location,
                c.about,
                v.position,
                v.description,
                v.job_type,
                v.location_type,
                v.is_open,
                v.created_at,
                v.updated_at
            FROM job_vacancies v
            JOIN users u ON v.company_id = u.user_id
            JOIN company_detail c ON u.user_id = c.user_id
            WHERE v.vacancy_id = :vacancy_id
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);

        $stmt->execute();
        $db = null;

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function getJobVacancyByPosition($position, $company_id) {
        global $db;
        $db = dbConnect();

        // Query untuk mengambil data pekerjaan berdasarkan vacancy_id
        $stmt = $db->prepare("
            SELECT 
                v.vacancy_id,
                u.user_id as company_id,
                u.name as company_name,
                c.location as company_location,
                c.about,
                v.position,
                v.description,
                v.job_type,
                v.location_type,
                v.is_open,
                v.created_at,
                v.updated_at
            FROM job_vacancies v
            JOIN users u ON v.company_id = u.user_id
            JOIN company_detail c ON u.user_id = c.user_id
            WHERE v.position = :position AND v.company_id = :company_id;
        ");
        $stmt->bindParam(':position', $position, PDO::PARAM_INT);
        $stmt->bindParam(':company_id', $company_id, PDO::PARAM_INT);

        $stmt->execute();
        $db = null;

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengambil nama/posisi pekerjaan berdasarkan vacancy_id
    public static function getJobVacancyPosition($vacancyId) {
        $db = dbConnect();
        $stmt = $db->prepare('
            SELECT position
            FROM job_vacancies
            WHERE vacancy_id = :vacancy_id');
        
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch( PDO::FETCH_ASSOC);
        $db = null;
        return $result['position'];
    }

    // Fungsi untuk mengambil tipe pekerjaan berdasarkan vacancy_id
    public static function getJobVacancyJobType($vacancyId) {
        $db = dbConnect();
        $stmt = $db->prepare("
            SELECT job_type
            FROM job_vacancies
            WHERE vacancy_id = :vacancy_id
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch( PDO::FETCH_ASSOC);
        $db = null;
        return $result['job_type'];
    }

    // Fungsi untuk mengambil tipe lokasi pekerjaan berdasarkan vacancy_id
    public static function getJobVacancyLocationType($vacancyId) {
        $db = dbConnect();
        $stmt = $db->prepare("
            SELECT location_type
            FROM job_vacancies
            WHERE vacancy_id = :vacancy_id
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch( PDO::FETCH_ASSOC);
        $db = null;
        return $result['location_type'];
    }

    // Fungsi untuk mengambil status pekerjaan berdasarkan vacancy_id
    public static function getJobVacancyIsOpen($vacancyId) {
        $db = dbConnect();
        $stmt = $db->prepare('
            SELECT is_open
            FROM job_vacancies
            WHERE vacancy_id = :vacancy_id');
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch( PDO::FETCH_ASSOC);
        $db = null;
        return $result['is_open'];
    }

    // fungsi untuk kembalikan top $limit jobs based on count
    public static function getJobVacancyTopRecommended($limit){
        $db = dbConnect();

        $query = "
            SELECT *
            FROM job_vacancies
            ORDER BY count DESC
            LIMIT";
        
        if($limit !== null && $limit > 0){
            $query .= ' ' . $limit;
        } else {
            $query .= ' 3';
        }

        $stmt = $db->prepare($query);

        $stmt->execute();

        $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $db = null;

        return $jobs;
    }

    // Fungsi untuk mengambil waktu unggah pekerjaan berdasarkan vacancy_id
    public static function getJobVacancyCreateTime($vacancyId) {
        $db = dbConnect();
        $stmt = $db->prepare("
            SELECT created_at
            FROM job_vacancies
            WHERE vacancy_id = :vacancy_id
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch( PDO::FETCH_ASSOC);
        $db = null;
        return $result['created_at'];
    }

    // Fungsi untuk mengambil waktu terakhir detail pekerjaan diubah berdasarkan vacancy_id
    public static function getJobVacancyUpdateTime($vacancyId) {
        $db = dbConnect();
        $stmt = $db->prepare("
            SELECT updated_at
            FROM job_vacancies
            WHERE vacancy_id = :vacancy_id
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch( PDO::FETCH_ASSOC);
        $db = null;
        return $result['updated_at'];
    }

    public static function getAttachmentsByVacancyId($vacancyId) {
        $db = dbConnect();
        $stmt = $db->prepare("
            SELECT file_path
            FROM vacancy_attachments
            WHERE vacancy_id = :vacancy_id
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->execute();
        $db = null;
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function getTotalApplicantsByVacancyId($vacancyId) {
        $db = dbConnect();
        $stmt = $db->prepare("
                SELECT DISTINCT COUNT(user_id) as total_applicants
                FROM applications
                WHERE vacancy_id = :vacancy_id
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $db = null;

        return $result["total_applicants"];
    }

    public static function getJobApplicantsDataByVacancyId($vacancyId, $offset, $limit) {
        $db = dbConnect();
        $stmt = $db->prepare("
            SELECT 
                a.application_id,  
                u.user_id,
                u.name as applicant_name, 
                u.email as applicant_email, 
                a.created_at, 
                a.status, 
                a.cv_path,
                a.video_path
            FROM applications a
            JOIN users u ON  a.user_id = u.user_id
            WHERE vacancy_id = :vacancy_id
            ORDER BY a.created_at DESC, u.name ASC
            LIMIT :limit OFFSET :offset
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $db = null;
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk menutup lowongan pekerjaan
    public static function closeJobVacancy($vacancy_id) {
        try {
            $db = dbConnect();
            $stmt = $db->prepare("
                UPDATE job_vacancies 
                SET is_open = FALSE
                WHERE vacancy_id = :vacancy_id
            ");
            $stmt->bindParam(":vacancy_id", $vacancy_id, PDO::PARAM_INT);
            $stmt->execute();
            $db = null;
        } catch (PDOException $e) {
            error_log('Close Job Vacancy Database error: ' . $e->getMessage());
            throw $e;
        }
    }

    public static function openJobVacancy($vacancyId) {
        try {
            $db = dbConnect();
            $stmt = $db->prepare("
                UPDATE job_vacancies 
                SET is_open = TRUE
                WHERE vacancy_id = :vacancy_id
            ");
            $stmt->bindParam(":vacancy_id", $vacancyId, PDO::PARAM_INT);
            $stmt->execute();
            $db = null;
        } catch (PDOException $e) {
            error_log('Open Job Vacancy Database error: ' . $e->getMessage());
            throw $e;
        }
    }

    // Fungsi untuk menghapus lowongan pekerjaan
    public static function deleteJobVacancy($vacancy_id) {
        try {
            $db = dbConnect();
            $stmt = $db->prepare("
                DELETE FROM job_vacancies
                WHERE vacancy_id = :vacancy_id
            ");
            $stmt->bindParam(":vacancy_id", $vacancy_id, PDO::PARAM_INT);
            
            $stmt->execute();
            $db = null;
        } catch (PDOException $e) {
            error_log('Delete Job Vacancy Database error: ' . $e->getMessage());
            throw $e;
        }
    }
}
?>
