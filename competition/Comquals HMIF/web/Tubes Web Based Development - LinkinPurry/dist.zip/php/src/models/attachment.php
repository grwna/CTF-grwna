<?php

class AttachmentModel {
    public static function constructAttechmentsDirectory($attachments) {
        $attachments_path = [];
        $target_dir = '/var/www/html/uploads/company/';

        // Create the directory if it doesn't exist
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        // Allowable file extensions
        $file_extensions = ['jpg', 'jpeg', 'png'];

        // original name of the uploaded file
        foreach ($attachments['name'] as $index => $file_name) {
            $tempPath = $attachments['tmp_name'][$index]; // Temporary location of the uploaded file
            $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION)); // lowering extension name

            if (in_array($file_type, $file_extensions)) {
                $target_file = $target_dir . basename($file_name);

                // generate a unique name for the file
                $new_file_name = uniqid() . '_' . basename($file_name);
                $target_file_path = $target_dir . $new_file_name;

                if (move_uploaded_file($tempPath, $target_file_path)) {
                    $attachments_path[] = '/company/'. $new_file_name;
                }
            }
        }
        return $attachments_path;
    }

    public static function saveVacancyAttachments($attachments, $vacancy_id){
        foreach($attachments as $attachment){
            try {
                $db = dbConnect();
                $stmt = $db->prepare("
                    INSERT INTO vacancy_attachments (vacancy_id, file_path) VALUES (:vacancy_id, :file_path)
                ");
                $stmt->bindParam(':vacancy_id', $vacancy_id, PDO::PARAM_INT);
                $stmt->bindParam(':file_path', $attachment, PDO::PARAM_STR);
                $stmt->execute();
                $db = null;
            } catch (PDOException $e) {
                error_log('Add image error: '.$e->getMessage());  // Optional logging
                throw $e;  // Rethrow the exception
            }
        }
    }

    //     $targetFile = $targetDir . basename($attachments['name'][0]);
    //     $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    //     $fileExtensions = ['jpg', 'jpeg', 'png', 'pdf'];

    //     $companyId = $_SESSION["user_id"];

    //     if (in_array($fileType, $fileExtensions)) {
    //         if (move_uploaded_file($attachments['tmp_name'][0], $targetFile)) {
    //             $attachmentsPath[] = '/company/'. $companyId. '/'.  $job_title. '/'. basename($attachments['name'][0]);
    //         }
    //     }
    //     return $attachmentsPath;
    // }

    public static function getVacancyAttachments($vacancyId) {
        global $db;
        $db = dbConnect();

        $stmt = $db->prepare("
            SELECT file_path 
            FROM vacancy_attachments 
            WHERE vacancy_id = :vacancy_id 
            LIMIT 5
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);

        $stmt->execute();
        $attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $db = null;
        return $attachments;
    }
    
}
?>