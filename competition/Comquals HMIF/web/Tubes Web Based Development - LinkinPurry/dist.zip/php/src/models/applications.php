<?php

require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/job.php';

class Application {
    /**
     * get job applications by user_id
     */
    public static function getApplicationsByUserId($user_id) {
        $db = dbConnect();
        $query = "
            SELECT 
                a.status, 
                a.created_at AS applied_date,
                v.vacancy_id,
                v.position, 
                v.location_type AS location,
                v.company_id,
                u.name AS company_name,
                'public/assets/company-profile.svg' AS company_logo 
            FROM applications a
            JOIN job_vacancies v ON a.vacancy_id = v.vacancy_id
            JOIN users u ON v.company_id = u.user_id
            WHERE a.user_id = :user_id
            ORDER BY a.created_at DESC";
    
        $st = $db->prepare($query);
        $st->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $st->execute();
    
        $applications = $st->fetchAll(PDO::FETCH_ASSOC);
    
        $db = null;
    
        return $applications;
    }
    

    /**
     * Check if a user has applied for a specific job vacancy
     */
    public static function hasApplied($user_id, $vacancy_id) {
        $db = dbConnect();
        $query = "
            SELECT 1 FROM applications 
            WHERE user_id = :user_id 
              AND vacancy_id = :vacancy_id
            LIMIT 1";
        
        $st = $db->prepare($query);
        $st->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $st->bindParam(':vacancy_id', $vacancy_id, PDO::PARAM_INT);
        $st->execute();
        
        // Check if any row is returned
        $hasApplied = $st->fetchColumn();
        
        $db = null;

        return $hasApplied;
    }

    public static function getApplicationDetails($user_id, $vacancy_id) {
        $db = dbConnect();
        $query = "
            SELECT 
                a.status,
                a.cv_path,
                a.video_path,
                a.status_reason,
                v.position,
                v.company_id,
                u.name AS company_name
            FROM applications a
            JOIN job_vacancies v ON a.vacancy_id = v.vacancy_id
            JOIN users u ON v.company_id = u.user_id
            WHERE a.user_id = :user_id
              AND a.vacancy_id = :vacancy_id
            LIMIT 1";

        $st = $db->prepare($query);
        $st->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $st->bindParam(':vacancy_id', $vacancy_id, PDO::PARAM_INT);
        $st->execute();

        $application = $st->fetch(PDO::FETCH_ASSOC);

        $db = null;

        return $application;
    }

    public static function submitApplication($user_id, $vacancy_id, $cv_path, $video_path = null) {
        $db = dbConnect();
        
        // Insert the new application
        $query = "
            INSERT INTO applications (user_id, vacancy_id, cv_path, video_path)
            VALUES (:user_id, :vacancy_id, :cv_path, :video_path)
        ";
        
        $st = $db->prepare($query);
        $st->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $st->bindParam(':vacancy_id', $vacancy_id, PDO::PARAM_INT);
        $st->bindParam(':cv_path', $cv_path, PDO::PARAM_STR);
        // if ($video_path) {
        //     $st->bindParam(':video_path', $video_path, PDO::PARAM_STR);
        // }
        if ($video_path !== null) {
            $st->bindParam(':video_path', $video_path, PDO::PARAM_STR);
        } else {
            $st->bindValue(':video_path', null, PDO::PARAM_NULL);
        }
        
        $st->execute();
        $db = null;

        // add peminat by 1
        JobModel::addNumberJobVacancyApplicant($vacancy_id);

        
        // return $db->lastInsertId();  // Return the ID of the inserted application
    }

    public static function getApplicantDetailsbyUserId($user_id, $vacancy_id) {
        $db = dbConnect();
        $query = "
            SELECT 
                a.application_id,
                a.user_id,
                u.name,
                u.email,
                a.status,
                a.cv_path,
                a.video_path,
                a.status_reason,
                a.created_at AS applied_date,
                v.vacancy_id,
                v.position,
                v.location_type AS location,
                v.company_id
            FROM applications a
            JOIN job_vacancies v ON a.vacancy_id = v.vacancy_id
            JOIN users u ON a.user_id = u.user_id
            WHERE a.user_id = :user_id AND v.vacancy_id = :vacancy_id AND u.role = 'jobseeker'";
    
        $st = $db->prepare($query);
        $st->bindParam(':user_id', $user_id, PDO::PARAM_INT); 
        $st->bindParam(':vacancy_id', $vacancy_id, PDO::PARAM_INT); 
        $st->execute();
    
        $applicant = $st->fetch(PDO::FETCH_ASSOC);
    
        $db = null;
    
        return $applicant;
    }

    public static function getApplicantDetailsbyApplicantId($application_id) {
        $db = dbConnect();
        $query = "
            SELECT 
                a.application_id,
                a.user_id,
                u.name,
                u.email,
                a.status,
                a.cv_path,
                a.video_path,
                a.status_reason,
                a.created_at AS applied_date,
                v.vacancy_id,
                v.position,
                v.location_type AS location,
                v.company_id
            FROM applications a
            JOIN job_vacancies v ON a.vacancy_id = v.vacancy_id
            JOIN users u ON a.user_id = u.user_id
            WHERE a.application_id = :application_id AND u.role = 'jobseeker'";
    
        $st = $db->prepare($query);
        $st->bindParam(':application_id', $application_id, PDO::PARAM_INT); 
        $st->execute();
    
        $applicant = $st->fetch(PDO::FETCH_ASSOC);
    
        $db = null;
    
        return $applicant;
    }

    public static function getApplicationsByVacancyId($vacancy_id){
        try {

            $db = dbConnect();

            $query = "
                SELECT *
                FROM applications a
                JOIN job_vacancies jv
                ON a.vacancy_id = jv.vacancy_id
                WHERE a.vacancy_id = :vacancy_id
            ";

            $smt = $db->prepare($query);
            $smt->bindParam(":vacancy_id", $vacancy_id, PDO::PARAM_INT);

            $smt->execute();

            $applicant = $smt->fetchAll(PDO::FETCH_ASSOC);
            $db = null;
            return $applicant;
        } catch (PDOException $e){
            echo $e;
        }
    }

    // Fungsi utk submit status oleh company
    public static function submitApplicationStatus($application_id, $status, $status_reason) {
        $db = dbConnect();
        
        $query = "
            UPDATE applications
            SET status = :status,
                status_reason = :status_reason
            WHERE application_id = :application_id
        ";
        
        $st = $db->prepare($query);
        $st->bindParam(':application_id', $application_id, PDO::PARAM_INT);
        $st->bindParam(':status', $status, PDO::PARAM_STR);
        $st->bindParam(':status_reason', $status_reason, PDO::PARAM_STR);
        
        $st->execute();
        $db = null;
    }
}
