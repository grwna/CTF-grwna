<?php

require_once __DIR__ . '/../config/db.php';

class CompanyModel {
    public static function getCompanyById($userId) {
        global $db;
        $db = dbConnect();

        // Query untuk mengambil data pekerjaan berdasarkan vacancy_id
        $stmt = $db->prepare("
            SELECT 
                u.user_id as company_id,
                u.name as company_name,
                c.location as company_location,
                c.about
            FROM users u
            JOIN company_detail c ON u.user_id = c.user_id
            WHERE u.user_id = :user_id
        ");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);

        $stmt->execute();
        $db = null;

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function updateUserProfileById($userId) {
        global $db;
        $db = dbConnect();

        $stmt = $db->prepare("
            UPDATE users
            SET name = :name, email = :email, username = :username, password = :password
            WHERE user_id = :user_id
        ");
        $stmt->bindParam(':name', $_POST['name'], PDO::PARAM_STR);
        $stmt->bindParam(':username', $_POST['username'], PDO::PARAM_STR);
        $stmt->bindParam(':email', $_POST['email'], PDO::PARAM_STR);
        $stmt->bindParam(':password', $_POST['password'], PDO::PARAM_STR);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);

        $stmt->execute();
        $db = null;
    }

    public static function updateCompanyDetails($userId) {
        global $db;
        $db = dbConnect();

        $stmt = $db->prepare("
            UPDATE company_detail
            SET location = :location, about = :about
            WHERE user_id = :user_id
        ");
        $stmt->bindParam(':location', $_POST['location'], PDO::PARAM_STR);
        $stmt->bindParam(':about', $_POST['about'], PDO::PARAM_STR);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);

        $stmt->execute();
        $db = null;
    }

    public static function updateCompanyProfile($userId, $data) {
        global $db;
        $db = dbConnect();

        try {
            $db->beginTransaction();

            // Update `users` table if needed
            if ($data['name'] || $data['username'] || $data['email'] || $data['password']) {
                $stmt = $db->prepare("
                    UPDATE users
                    SET 
                        name = COALESCE(:name, name), 
                        username = COALESCE(:username, username), 
                        email = COALESCE(:email, email), 
                        password = COALESCE(:password, password)
                    WHERE user_id = :user_id
                ");
                $stmt->bindParam(':name', $data['name'], PDO::PARAM_STR);
                $stmt->bindParam(':username', $data['username'], PDO::PARAM_STR);
                $stmt->bindParam(':email', $data['email'], PDO::PARAM_STR);
                $stmt->bindParam(':password', $data['password'], PDO::PARAM_STR);
                $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);

                $stmt->execute();
            }

            // Update `company_detail` table if needed
            if ($data['location'] || $data['about']) {
                $stmt = $db->prepare("
                    UPDATE company_detail
                    SET 
                        location = COALESCE(:location, location), 
                        about = COALESCE(:about, about)
                    WHERE user_id = :user_id
                ");
                $stmt->bindParam(':location', $data['location'], PDO::PARAM_STR);
                $stmt->bindParam(':about', $data['about'], PDO::PARAM_STR);
                $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);

                $stmt->execute();
            }

            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        } finally {
            $db = null;
        }
    }

    public static function getCompanyInfoById($userId) {
        global $db;
        $db = dbConnect();

        // Query untuk mengambil data pekerjaan berdasarkan vacancy_id
        $stmt = $db->prepare("
            SELECT 
                u.username,
                u.password
            FROM users u
            WHERE u.user_id = :user_id
        ");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $db = null;

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function getCompanyByVacancyId($vacancyId) {
        global $db;
        $db = dbConnect();

        // Query untuk mengambil data pekerjaan berdasarkan vacancy_id
        $stmt = $db->prepare("
            SELECT 
                u.user_id as company_id,
                u.name as company_name,
                c.location as company_location,
                c.about
            FROM users u
            JOIN company_detail c ON u.user_id = c.user_id
            JOIN job_vacancies jv ON u.user_id = jv.company_id
            WHERE jv.vacancy_id = :vacancy_id
        ");
        $stmt->bindParam(':vacancy_id', $vacancyId, PDO::PARAM_INT);
        $stmt->execute();
        $db = null;
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>