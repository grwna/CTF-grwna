<?php

// include the user model
require_once __DIR__.'/../models/User.php';

// Check if the form is submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? null;
    $password = $_POST['password'] ?? null;

    // Validate the input
    if (empty($username) || empty($password)) {
        header("Location: /../views/login_view.php?error=Please fill in all fields");
        exit();
    }

    // Fetch the user from the database
    // $user = User::findByUsername($username, $password);
    $user = User::findByUsername($username);

    // Check if the user exists and the password is correct
    // use password_verify because we are comparing HASH BCRYPT
    if ($user && password_verify($password, $user['password'])) {
        // If the login is successful, set session variables
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['login'] = true;
        
        // Redirect to the dashboard or another protected page
        header("Location: /job-seeker");
        exit();
    } else {
        // TODO: Check XSS Vuln
        header("Location: /login?error=Incorrect username or password. Please try again.");
        exit();
    }
} else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // If not a POST request, redirect to the login form
    require __DIR__.'/../views/login-view.php';
    exit();
}
