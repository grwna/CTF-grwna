<?php


if (isLoggedIn()){
    $_SESSION = array();
    
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    session_destroy();
    
    header("Location: /");
    exit();
} else {
    echo '
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .modal {
            display: block;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.7);
        }

        .modal-content {
            background-color: #ffffff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            width: 80%;
            max-width: 600px;
        }

        .close {
            color: #0077b5;
            float: right;
            font-size: 24px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #005582;
            text-decoration: none;
            cursor: pointer;
        }

        h1 {
            color: #333333;
            text-align: center;
        }
    </style>

    <div id="logout-modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="redirectToHome()">&times;</span>
            <h1>Please Sign In First</h1>
        </div>
    </div>

    <script>
        function redirectToHome() {
            window.location.href = "/";
        }

        var modal = document.getElementById("logout-modal");

        modal.style.display = "block";

        window.onclick = function(event) {
            if (event.target == modal) {
                redirectToHome();
            }
        }
    </script>';
    exit();
}

?>
