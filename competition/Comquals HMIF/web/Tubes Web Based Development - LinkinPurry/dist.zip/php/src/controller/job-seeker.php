<?php

require __DIR__ . '/../models/job.php';

if ($_SERVER['REQUEST_METHOD'] == "GET"){
    // send data ke view
    require __DIR__."/../views/home-jobseeker.php";
}

?>
