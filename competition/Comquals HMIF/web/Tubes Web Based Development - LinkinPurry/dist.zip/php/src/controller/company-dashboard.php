<?php

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    require __DIR__.'/../views/home-company.php';
}

?>