<?php


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/public/css/job-list.css">
    <title>Page Not Found | LinkedIn</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #F4F2ED;
            color: #333;
        }
        
        /* Header */
        header {
            background-color: #0073b1;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 30px;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        /* Main Content */
        .main-content {
            text-align: center;
            padding: 50px;
            margin: 0 auto;
        }

        .error-code {
            font-size: 80px;
            color: #0073b1;
            font-weight: bold;
        }

        .error-message {
            font-size: 24px;
            color: #333;
            margin: 10px 0;
        }

        .error-description {
            font-size: 18px;
            color: #666;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <img src="/public/assets/linkinpurry.svg"
                alt="LinkedIn Logo" class="logo">
            <div class="auth-buttons">
                <a href="/job-list" class="jobs" id="nav-status">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" data-supported-dps="24x24" fill="currentColor" class="mercado-match" width="24" height="24" focusable="false">
                        <path d="M22.84 10.22L21 6h-3.95V5a3 3 0 00-3-3h-4a3 3 0 00-3 3v1H2l2.22 5.18A3 3 0 007 13h14a2 2 0 001.84-2.78zM15.05 6h-6V5a1 1 0 011-1h4a1 1 0 011 1zM7 14h15v3a3 3 0 01-3 3H5a3 3 0 01-3-3V8.54l1.3 3A4 4 0 007 14z"></path>
                    </svg>
                    <p>Jobs</p>
                </a>
                <a href="/signup" class="join-now">Join now</a>
                <a href="#" class="sign-in">Sign in</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="main-content">
        <div class="error-code">404</div>
        <div class="error-message">Oops! Page not found.</div>
        <div class="error-description">Sorry, the page you were looking for might have been moved or deleted.</div>
        <!-- Navigation Links -->
        <div class="navigation-links">
            <a href="/">Go back to Home</a>
        </div>
    </div>

    <!-- Footer -->
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; ?>
</body>
</html>
