<?php

require_once __DIR__.'/../models/job.php';
require_once __DIR__.'/../models/company.php';
require_once __DIR__.'/../models/user.php';
require_once __DIR__.'/../models/attachment.php';

// Function to validate the job type
function isValidJobType($jobType) {
    return in_array($jobType, ['Full-time', 'Part-time', 'Internship']);
}

// Function to validate the workplace type
function isValidWorkplaceType($workplaceType) {
    return in_array($workplaceType, ['On-site', 'Hybrid', 'Remote']);
}

if ($_SERVER['REQUEST_METHOD'] === "GET"){
    if (isset($_GET['vacancy_id']) && is_numeric($_GET['vacancy_id'])) {
        $vacancyId = (int) $_GET['vacancy_id'];

        $jobDetails = JobModel::getJobVacancyById($vacancyId);
        
        if($jobDetails){
            if (isset($jobDetails)) {
                $job = [
                    'title' => $jobDetails['position'],
                    'job_type' => $jobDetails['job_type'], 
                    'location_type' => $jobDetails['location_type'],
                    'description' => $jobDetails['description'],
                    'vacancy_id' => $jobDetails['vacancy_id']
                ];
            } else {
                echo "Job details not found!";
                exit();
            }
    
            $jobAttachments = JobModel::getAttachmentsByVacancyId($vacancyId);
            
            if (count($jobAttachments) == 0){
                $jobAttachments = null;
            }
    
            // Send data to the view
            require __DIR__ . '/../views/edit-lowongan.php';
    
        } else {
            // If job not found, display error message
            echo "Job not found!";
        }
    } else {
        echo "Invalid vacancy ID!";
    }
}
elseif ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $position = htmlspecialchars($_POST['job-title'] ?? null, ENT_QUOTES, 'UTF-8');
    $jobType = $_POST['job-type'] ?? null;
    $workplaceType = $_POST['job-workplace-type'] ?? null;
    $description = $_POST['description'] ?? null;
    $vacancyId = isset($_GET['vacancy_id']) ? (int)$_GET['vacancy_id'] : null;
    $attachments = $_FILES['job-image'] ?? null;
    
    $companyId = $_SESSION["user_id"];
    $action = $_POST['action'] ?? '';

    if ($action === 'post') {
        try {
            if (empty($position) || empty($jobType) || empty($workplaceType) || empty($description)) {
                header("Location: /add-lowongan?err=Please fill in all required fields");
                exit();
            }
    
            if (!isValidJobType($jobType)) {
                http_response_code(400); // Set the response status to 400 Bad Request
                echo "Job type must be between full-time, part-time, internship";
                exit();
            }
            
            if (!isValidWorkplaceType($workplaceType)) {
                http_response_code(400); // Set the response status to 400 Bad Request
                echo "Workplace type must be between on-site, hybrid, and remote";
                exit();
            }
            
            // Add job vacancy to the database
            try {
                var_dump($vacancyId,$position, $description, $jobType, $workplaceType);
                JobModel::updateJobVacancy( $vacancyId, $position, $description, $jobType, $workplaceType);
                // handle attachments upload
                if (isset($_FILES['job-image'])) {
                    if ($_FILES['job-image']['error'][0] === UPLOAD_ERR_OK) {
                        try {
                            // Upload attachments
                            $attachmentsDirectories = AttachmentModel::constructAttechmentsDirectory($attachments);
                            AttachmentModel::saveVacancyAttachments($attachmentsDirectories, $vacancyId);
                        } catch (PDOException $e) {
                            echo $e->getMessage();
                        }
                    }
                }
                header("Location: /company-dashboard");
                exit();
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    } else {
        header('Location: /company-dashboard');
        exit();
    }
}
?>