<?php
require_once __DIR__ . '/../models/job.php';
require_once __DIR__ . '/../models/applications.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['vacancy_id']) && is_numeric($_GET['vacancy_id'])) {
        $vacancyId = (int) $_GET['vacancy_id'];

        $jobDetails = JobModel::getJobVacancyById($vacancyId);
    
        if ($jobDetails) {
            if (isset($jobDetails)) {
                $company = [
                    'name' => $jobDetails['company_name'],
                    'location' => $jobDetails['company_location'], // data lokasi harus diambil dari COMPANY, wait yaa
                    'about' => $jobDetails['about']
                ];
    
                $job = [
                    'id' => $jobDetails['vacancy_id'],
                    'title' => $jobDetails['position'],
                    'job_type' => $jobDetails['job_type'],
                    'location_type' => $jobDetails['location_type'],
                    'description' => $jobDetails['description'],
                    'is_open' => $jobDetails['is_open'],
                    'posted' => 'Posted: ' . date('F j, Y', strtotime($jobDetails['created_at'])),
                    'updated' => 'Updated: ' . date('F j, Y', strtotime($jobDetails['updated_at']))
                    // 'responsibilities' => ['Responsibility 1', 'Responsibility 2'], //blom ada sih for now di db
                ];
    
                $jobAttachments = JobModel::getAttachmentsByVacancyId($vacancyId);
                
                if (count($jobAttachments) == 0){
                    $jobAttachments = null;
                }

                $jobTotalApplicants = JobModel::getTotalApplicantsByVacancyId($vacancyId);
            } else {
                header('Location: /company-dashboard?err=Job details not found!');
                // echo "Job details not found!";
                exit();
            }
            // Send data to the view
            require __DIR__ . '/../views/detail-lowongan-company.php';
        } else {
            header('Location: /company-dashboard?err=Job not found!');
            // echo "Job not found!";
            exit();
        }
    } else  {
        header('Location: /company-dashboard?err=Invalid vacancy ID!');
        // echo "Invalid vacancy ID!";
        exit();
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['vacancy_id'])) {
        $vacancyId = (int) $_POST['vacancy_id'];

        // check if the user id is the owner of the vacancy id
        $vacancyDetail = JobModel::getJobVacancyById($vacancyId);

        if($vacancyDetail['company_id'] !== $_SESSION['user_id']){
            header("HTTP/1.1 401 Unauthorized");
            header("Content-Type: text/html");
            exit();
        }

        if ($_POST['action'] === 'close') {
            try {
                JobModel::closeJobVacancy($vacancyId);
                header('Location: /job-detail-company?vacancy_id=' . $vacancyId);
                // echo "Job closed successfully!";
            } catch (Exception $e) {
                echo "Error closing job: " . $e->getMessage();
            }
        } elseif ($_POST['action'] === 'open') {
            try {
                JobModel::openJobVacancy($vacancyId);
                header('Location: /job-detail-company?vacancy_id=' . $vacancyId);
                // echo "Job opened successfully!";
            } catch (Exception $e) {
                echo "Error opening job: " . $e->getMessage();
            }
        } elseif ($_POST['action'] === 'delete') {
            try {
                // echo $vacancyId;
                // Mechanism TO DELETE ALL FILES in Filesystem
                $application = Application::getApplicationsByVacancyId($vacancyId);
                // print_r($application);
                if (!empty($application)){
                    foreach ($application as $row) {
                        $cv_path = $row['cv_path'];
                        $video_path = $row['video_path'];
                        
                        $base_dir = '/var/www/html/';
                        
                        // Full paths to the files
                        $cv_full_path = ($cv_path != null) ? $base_dir . $cv_path : null;
                        // Check if CV file exists, then delete it
                        if ($cv_full_path != null && file_exists($cv_full_path)) {
                            if (unlink($cv_full_path)) {
                                // echo "CV file deleted successfully.";
                            } else {
                                echo "Failed to delete CV file.";
                            }
                        } else {
                            echo "CV file does not exist.";
                        }
                        
                        // Check if Video file exists, then delete it
                        $video_full_path = ($video_path != null) ? $base_dir . $video_path : null;
                        if (($video_full_path != null) && file_exists($video_full_path)) {
                            if (unlink($video_full_path)) {
                                // echo "Video file deleted successfully.";
                            } else {
                                echo "Failed to delete Video file.";
                            }
                        } else {
                            echo "Video file does not exist.";
                        }
                    }                    
                }

                JobModel::deleteJobVacancy($vacancyId);
                // echo "Job deleted successfully!";
                header('Location: /company-dashboard');
                exit();
            } catch (Exception $e) {
                echo "Error deleting job: " . $e->getMessage();
                exit();
            }
        }
    } else {
        echo "Invalid action or vacancy ID!";
        exit();
    }
}
?>
