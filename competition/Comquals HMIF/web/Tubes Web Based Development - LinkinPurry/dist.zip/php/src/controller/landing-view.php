<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo 1;
}
else if ($_SERVER['REQUEST_METHOD'] === "GET"){
    if(isLoggedIn()){
        if(isset($_SESSION['role']) && $_SESSION['role'] === 'jobseeker'){
            header('Location: /job-seeker');
        } else if(isset($_SESSION['role']) && $_SESSION['role'] === 'company'){
            header('Location: /company-dashboard');
        }
        exit();
    } else {
        require __DIR__.'/../views/landing-view.php';
    }
}

?>