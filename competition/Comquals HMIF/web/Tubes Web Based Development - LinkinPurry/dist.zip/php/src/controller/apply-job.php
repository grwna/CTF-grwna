<?php
require_once __DIR__ . '/../models/applications.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/job.php';

// if not login or not a jobseeker, you can't submit!
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'jobseeker') {
    header('Location: /login');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $vacancy_id = $_POST['vacancy-id'] ?? null; // Get vacancy ID
    
    // add check mechanism if job still open or not
    $jobDetails = JobModel::getJobVacancyById($vacancy_id);
    $is_job_vacancy_open = $jobDetails['is_open'];

    // check has applied or not (so no doble applied)
    $hasApplied = Application::hasApplied($user_id, $vacancy_id);

    if (!$vacancy_id) {
        header('Location: /job-seeker');
        exit();
    }

    if (!$is_job_vacancy_open) {
        $str = "Location: /job-detail?vacancy_id=" . urlencode($vacancy_id) . "&err=This job vacancy is already closed.";
        header($str);
        exit();
    }
    
    if ($hasApplied) {
        $str = "Location: /job-detail?vacancy_id=" . urlencode($vacancy_id) . "&err=You have already applied for this job.";
        header($str);
        exit();
    }    

    // File paths
    $cv_path = null;
    $video_path = null;

    // Debugging variables
    $cv_error = '';
    $video_error = '';

    // Handling resume upload
    if ($_FILES['resume-upload']['error'] === UPLOAD_ERR_OK) {
        $cv_tmp_name = $_FILES['resume-upload']['tmp_name'];
        $cv_size = $_FILES['resume-upload']['size'];

        // Check file size (max 5MB = 5 * 1024 * 1024 bytes)
        // if ($cv_size > 5 * 1024 * 1024) {
        //     $cv_error = "File size exceeds 5MB.";
        //     header('Location: /apply-job?vacancy_id=' . urlencode($vacancy_id) . '&err=' . urlencode($cv_error));
        //     exit();
        // }

        // check magic bytes
        // Open the file and read the first few bytes to check the magic bytes
        $file = fopen($cv_tmp_name, 'rb');
        $magicBytes = fread($file, 4); // PDF files start with "%PDF"
        fclose($file);

        // if ($magicBytes !== "%PDF") {
        //     $cv_error = "Uploaded file is not a valid PDF.";
        //     header('Location: /apply-job?vacancy_id=' . urlencode($vacancy_id) . '&err=' . urlencode($cv_error));
        //     exit();
        // }

        $cv_name = uniqid() . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "", basename($_FILES['resume-upload']['name']));
        $cv_path = 'uploads/cv/' . $cv_name;

        if (!file_exists('uploads/cv')) {
            // Directory does not exist, so create it
            if (mkdir('uploads/cv', 0777, true)) {
                
            }
        }

        // Move uploaded file to the target directory
        
        if (move_uploaded_file($cv_tmp_name, __DIR__.'/../'.$cv_path)) {
            // echo "Resume uploaded successfully to $cv_path<br>";
        } else {
            $cv_error = "Failed to move resume file.";
            // echo $cv_error . "<br>";
        }
    } else {
        $cv_error = "Error during resume upload: " . $_FILES['resume-upload']['error'];
        // echo $cv_error . "<br>";
    }

    // Handling video upload (if exists)
    if (isset($_FILES['video-upload']) && $_FILES['video-upload']['error'] === UPLOAD_ERR_OK) {
        $video_tmp_name = $_FILES['video-upload']['tmp_name'];
        $video_size = $_FILES['video-upload']['size'];
        // var_dump($video_size);
        
        // Check file size (max 10MB = 10 * 1024 * 1024 bytes)
        // if ($video_size > 1 * 1024 * 1024) {
        //     $video_error = "Video file size exceeds 10MB.";
        //     header('Location: /apply-job?vacancy_id=' . urlencode($vacancy_id) . '&err=' . urlencode($video_error));
        //     exit();
        // }

        // Open the file and check magic bytes for MP4
        $file = fopen($video_tmp_name, 'rb');
        $magicBytes = fread($file, 12); // First 12 bytes are typical for MP4s
        fclose($file);

        // MP4 files have specific bytes in the beginning (ftyp or moov)
        // if (strpos($magicBytes, 'ftyp') === false && strpos($magicBytes, 'moov') === false) {
        //     $video_error = "Uploaded file is not a valid MP4 video.";
        //     header('Location: /apply-job?vacancy_id=' . urlencode($vacancy_id) . '&err=' . urlencode($video_error));
        //     exit();
        // }

        $video_name = uniqid() . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "", basename($_FILES['video-upload']['name']));
        $video_path = 'uploads/video/' . $video_name;

        if (!file_exists('uploads/video/')) {
            // Directory does not exist, so create it
            if (mkdir('uploads/video/', 0777, true)) {

            }
        }

        // Move uploaded video file
        if (move_uploaded_file($video_tmp_name, __DIR__.'/../'.$video_path)) {
            // echo "Video uploaded successfully to $video_path<br>";
        } else {
            $video_error = "Failed to move video file.";
            // echo $video_error . "<br>";
        }
    }

    // Insert into database (if files were uploaded successfully)
    if ($cv_path && !$cv_error) {
        if ($video_path && !$video_error) {
            Application::submitApplication($user_id, $vacancy_id, $cv_path, $video_path);
        } else {
            Application::submitApplication($user_id, $vacancy_id, $cv_path, null);
        }
        // redirect to job-detail after submission
        header("Location: /job-detail?vacancy_id=$vacancy_id");
        exit();
    }
}
