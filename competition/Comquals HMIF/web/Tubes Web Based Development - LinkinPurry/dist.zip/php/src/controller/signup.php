<?php

// include the user model
require_once __DIR__.'/../models/User.php';

// Function for username validation
function isValidUsername($username) {
    return preg_match('/^[a-zA-Z0-9]{3,20}$/', $username);
}

// Function for email validation
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Function for password validation (at least 8 characters, contains letters and numbers)
function isValidPassword($password) {
    return preg_match('/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/', $password);
}

// Function to validate and sanitize the display name
function isValidDisplayName($name) {
    // Validate: Only allows letters, spaces, hyphens, and apostrophes (e.g., O'Connor, Mary-Jane)
    return preg_match("/^[a-zA-Z' -]{2,50}$/", $name);
}

// Check if the form is submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? null;  // Username field for both roles
    $name = $_POST['name'] ?? null;
    $password = $_POST['password'] ?? null;
    $email = $_POST['email'] ?? null;
    $role = $_POST['role'] ?? null;

    // Hash the password
    $passwordHash = password_hash($password, PASSWORD_BCRYPT);

    try {
        // Insert user based on role
        if ($role === 'jobseeker') {
            // Validasi untuk job seeker
            if (empty($username) || empty($name) || empty($password) || empty($email)) {
                header("Location: /signup?err=Please fill in all fields");
                exit();
            }

            // Validate display name
            if (!isValidDisplayName($name)){
                http_response_code(400); // Set the response status to 400 Bad Request
                echo "Invalid Display Name. Please only use letters, spaces, hyphens, and apostrophes.";
                exit();
            }

            // Validate username
            if (!isValidUsername($username)) {
                http_response_code(400); // Set the response status to 400 Bad Request
                echo "Invalid username. It must be 3-20 characters and alphanumeric.";
                exit();
            }
            
            // Validate email
            if (!isValidEmail($email)) {
                http_response_code(400); // Set the response status to 400 Bad Request
                echo "Invalid email format";
                exit();
            }
            
            // Validate password
            if (!isValidPassword($password)) {
                http_response_code(400); // Set the response status to 400 Bad Request
                echo "Password must be at least 8 characters long and contain both letters and numbers.";
                exit();
            }
            
            // Add job seeker to the database
            try {
                User::addUserAccount($username, $name, $passwordHash, $email, 'jobseeker');
                header("Location: /login");
                exit();
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        } elseif ($role === 'company') {
            $location = $_POST['location'] ?? null;
            $about = $_POST['about'] ?? null;
            
            if (empty($username) || empty($name) || empty($location) || empty($about) || empty($email) || empty($password)) {
                header("Location: /signup?err=Please fill in all fields for company");
                exit();
            }

            // Validate display name
            if (!isValidDisplayName($name)){
                http_response_code(400); // Set the response status to 400 Bad Request
                echo "Invalid Display Name. Please only use letters, spaces, hyphens, and apostrophes.";
                exit();
            }

            // Validate username
            if (!isValidUsername($username)) {
                header("Location: /signup?err=Invalid username. It must be 3-20 characters and alphanumeric.");
                exit();
            }

            // Validate email
            if (!isValidEmail($email)) {
                header("Location: /signup?err=Invalid email format");
                exit();
            }

            echo $password;
            // Validate password
            if (!isValidPassword($password)) {
                header("Location: /signup?err=Password must be at least 8 characters long and contain both letters and numbers.");
                exit();
            }
        
            // Insert company into the database
            try {
                $userId = User::addUserAccount($username, $name, $passwordHash, $email, 'company');
                User::addCompanyDetails($userId, $location, $about);
                header("Location: /login");
                exit();
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }
        // Redirect to login page after successful signup
        header("Location: /login");
        exit();
    } catch (PDOException $e) {
        echo $e->getMessage();
    }

} else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // check if authenticated or not
    if (isLoggedIn()){
        header("Location: /job-seeker");
    }
    // If not a POST request, redirect to the login form
    require __DIR__.'/../views/signup-view.php';
    exit();
}
