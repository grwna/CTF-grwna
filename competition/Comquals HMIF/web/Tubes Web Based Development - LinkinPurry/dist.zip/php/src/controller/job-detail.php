<?php
require_once __DIR__ . '/../models/job.php';
require_once __DIR__ . '/../models/applications.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['vacancy_id']) && is_numeric($_GET['vacancy_id'])) {
        $enableApply = true;
        $vacancyId = (int) $_GET['vacancy_id'];
        $applicationStatus = null; // Initialize $applicationStatus to null

        if (!isset($_SESSION['user_id'])) {
            $enableApply = false;
        } else {
            $userId = $_SESSION['user_id']; // Get the logged-in user's ID
            // Check if the user has already applied to this job
            $hasApplied = Application::hasApplied($userId, $vacancyId);
            // If the user has applied, fetch application details      
            $applicationStatus = Application::getApplicationDetails($userId, $vacancyId);
        }    
        // Get job details by vacancy_id
        $jobDetails = JobModel::getJobVacancyById($vacancyId);
    
        if ($jobDetails) {
            if (isset($jobDetails)) {
                $company = [
                    'name' => $jobDetails['company_name'],
                    'location' => $jobDetails['company_location'], // data lokasi harus diambil dari COMPANY, wait yaa
                    'posted' => 'Posted: ' . date('F j, Y', strtotime($jobDetails['created_at'])),
                ];
    
                $job = [
                    'title' => $jobDetails['position'],
                    'job_tags' => [$jobDetails['job_type'], $jobDetails['location_type']],
                    'description' => $jobDetails['description'],
                ];
            } else {
                echo "Job details not found!";
                exit();
            }

            // check if $applicationStatus is valid and has 'cv_path'
            if ($applicationStatus && isset($applicationStatus['cv_path']) && !empty($applicationStatus['cv_path'])) {
                // make sure explode() only runs if the path is valid!!!!
                $pathParts = explode('/', $applicationStatus['cv_path']);
                $filename = isset($pathParts[2]) ? $pathParts[2] : 'Unknown file';
            } else {
                $filename = 'Unknown file';
            }

            // $attachments = JobModel::getVacancyAttachments($vacancyId);
    
            require __DIR__ . '/../views/detail-lowongan-jobseeker.php';
        } else {
            // if job not found, display error message
            echo "Job not found!";
            // redirect to login page
            header('Location: /login');
            exit();
        }
    } else {
        // echo "Invalid vacancy ID!";
        header('Location: /login');
        exit();
    }
}
