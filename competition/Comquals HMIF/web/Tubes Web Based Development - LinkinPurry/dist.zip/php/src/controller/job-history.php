<?php

// cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: /login');  // redirect jika belum login
    exit();
}

require_once __DIR__.'/../models/applications.php';

// ambil user_id dari session
$user_id = $_SESSION['user_id'];

// ambil data aplikasi pekerjaan dari database berdasarkan user_id
$applications = Application::getApplicationsByUserId($user_id);

require __DIR__.'/../views/riwayat-jobseeker.php';

?>