<?php
require_once __DIR__ . '/../models/job.php';
require_once __DIR__ . '/../models/applications.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['vacancy_id']) && is_numeric($_GET['vacancy_id']) && isset($_GET['applicant_user_id']) && is_numeric($_GET['applicant_user_id'])) {
        $vacancyId = (int) $_GET['vacancy_id'];
        $applicantId = (int) $_GET['applicant_user_id'];

        // check if the user id is the owner of the vacancy id
        $jobDetails = JobModel::getJobVacancyById($vacancyId);

        if($jobDetails['company_id'] !== $_SESSION['user_id']){
            header("HTTP/1.1 401 Unauthorized");
            header("Content-Type: text/html");
            exit();
        }

        $applicantDetail = Application::getApplicantDetailsbyUserId($applicantId, $vacancyId);
        if ($jobDetails && !empty($applicantDetail)) {
            if (isset($jobDetails)) {
                $company = [
                    'name' => $jobDetails['company_name'],
                    'location' => $jobDetails['company_location'], // data lokasi harus diambil dari COMPANY, wait yaa
                ];
    
                $job = [
                    'title' => $jobDetails['position'],
                    'job_type' => $jobDetails['job_type'],
                    'location_type' => $jobDetails['location_type'],
                    'is_open' => $jobDetails['is_open'],
                    'posted' => 'Posted: ' . date('F j, Y', strtotime($jobDetails['created_at'])),
                    'updated' => 'Updated: ' . date('F j, Y', strtotime($jobDetails['updated_at']))
                    // 'responsibilities' => ['Responsibility 1', 'Responsibility 2'], //blom ada sih for now di db
                ];

                $applicant = [
                    'user_id' => $applicantDetail['user_id'],
                    'name' => $applicantDetail['name'],
                    'email' => $applicantDetail['email'],
                    'status' => $applicantDetail['status'],
                    'status_reason' => $applicantDetail['status_reason'],
                    'cv_path' => $applicantDetail['cv_path'],
                    'video_path' => $applicantDetail['video_path'],
                    'applied_at' => $applicantDetail['applied_date']
                ];

                // check if $applicantDetail is valid and has 'cv_path'
                if ($applicantDetail && isset($applicantDetail['cv_path']) && !empty($applicantDetail['cv_path'])) {
                    // make sure explode() only runs if the path is valid!!!!
                    $pathParts = explode('/', $applicantDetail['cv_path']);
                    $filename = isset($pathParts[2]) ? $pathParts[2] : 'Unknown file';
                } else {
                    $filename = 'Unknown file';
                }

                $jobTotalApplicants = JobModel::getTotalApplicantsByVacancyId($vacancyId);

                // $jobApplicantsDetail = JobModel::getJobApplicantsDataByVacancyId($vacancyId, $offset, $limit);
            } else {
                header('Location: /company-dashboard?err=Job details not found!');
                // echo "Job details not found!";
                exit();
            }
            // Send data to the view
            require __DIR__ . '/../views/detail-lamaran-company.php';
        } else {
            header('Location: /company-dashboard?err=Job not found!');
            // echo "Job not found!";
            exit();
        }
    } else  {
        header('Location: /company-dashboard?err=Invalid vacancy ID!');
        // echo "Invalid vacancy ID!";
        exit();
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $applicationId = $_POST['application_id'] ?? null;
    $status = $_POST['status'];
    $status_reason = $_POST['description'];

    Application::submitApplicationStatus($applicationId, $status, $status_reason);

    $applicantDetail = Application::getApplicantDetailsbyApplicantId($applicationId);
    header("Location: /applicants-detail-company?vacancy_id={$applicantDetail['vacancy_id']}&applicant_user_id={$applicantDetail['user_id']}"); 
    exit();
}
?>