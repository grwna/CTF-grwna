<?php
require_once __DIR__ . '/../models/company.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header("Location: /login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $name = $_POST['name'] ?? null;
    $username = $_POST['username'] ?? null;
    $email = $_POST['email'] ?? null;
    $password = $_POST['password'] ?? null;
    $location = $_POST['location'] ?? null;
    $about = $_POST['about'] ?? null;

    // fetch current data from the database
    $currentData = CompanyModel::getCompanyById($userId);

    // update only if the value has changed
    if ($currentData) {
        $updateData = [
            'name' => ($name && $name !== $currentData['company_name']) ? $name : null,
            'username' => ($username && $username !== $currentData['username']) ? $username : null,
            'email' => ($email && $email !== $_SESSION['email']) ? $email : null,
            'password' => ($password) ? password_hash($password, PASSWORD_BCRYPT) : null,
            'location' => ($location && $location !== $currentData['company_location']) ? $location : null,
            'about' => ($about && $about !== $currentData['about']) ? $about : null
        ];

        // update data
        CompanyModel::updateCompanyProfile($userId, $updateData);
        
        // update session data if any field was changed
        if ($updateData['name']) $_SESSION['name'] = $updateData['name'];
        if ($updateData['email']) $_SESSION['email'] = $updateData['email'];
        // if ($updateData['location']) $_SESSION['location'] = $updateData['location'];
        // if ($updateData['about']) $_SESSION['about'] = $updateData['about'];
    }

    header("HTTP/1.1 200 OK");
    
    // redirect
    // header("Location: /views/home-company.php");
    // exit();
}
?>
