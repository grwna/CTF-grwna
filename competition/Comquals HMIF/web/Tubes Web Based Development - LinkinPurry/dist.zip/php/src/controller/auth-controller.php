<?php

function isLoggedIn(){
    if (isset($_SESSION['user_id']) &&
        isset($_SESSION['role'])){
        return true;
    }
    return false;
}

?>