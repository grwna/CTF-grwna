<?php

require __DIR__."/controller/auth-controller.php";

session_start();

$request = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

switch (true) {
    case ($request === '/'):
        require __DIR__ . '/controller/landing-view.php';
        break;
    
    case ($request === '/signup'):
        require __DIR__ . '/controller/signup.php';
        break;

    case ($request === '/login'):
        // check if authenticated or not
        if (isLoggedIn() && $_SESSION['role'] === 'jobseeker'){
            header("Location: /job-seeker");
            exit();
        }
        else if (isLoggedIn() && $_SESSION['role'] === 'company'){
            header("Location: /company-dashboard");
            exit();
        }
        else if (isLoggedIn() && $_SESSION['role'] === 'flag'){
            header("Location: /flag-dashboard");
            exit();
        } else {
            require __DIR__ . '/controller/login.php';
        }
        require __DIR__ . '/controller/login.php';
        break;

    case ($request === '/job-seeker'):
        if(isLoggedIn() && $_SESSION['role'] === 'jobseeker'){
            require __DIR__ . '/controller/job-seeker.php';
        } else {
            header('Location: /login');
            exit();
        }
        break;

    case ($request === '/job-detail'):
        require __DIR__ . '/controller/job-detail.php';
        break;

    case ($request === '/job-history'):
        if(isLoggedIn() && $_SESSION['role'] === 'jobseeker'){
            require __DIR__ . '/controller/job-history.php';
        } else {
            header('Location: /login');
            exit();
        }
        break;
    
    case ($request === '/apply-job'):
        if(isLoggedIn() && $_SESSION['role'] === 'jobseeker'){
            require __DIR__ . '/controller/apply-job.php';
        } else {
            header('Location: /login');
            exit();
        }
        break;

    case ($request === '/job-list'):
        require __DIR__ . '/controller/job-list.php';
        break;

    case ($request === '/company-dashboard'):
        if(isLoggedIn() && $_SESSION['role'] === 'company'){
            require __DIR__.'/controller/company-dashboard.php';
        } else {
            header('Location: /login');
            exit();
        }
        break;

    case ($request === '/add-lowongan'):
        if(isLoggedIn() && $_SESSION['role'] === 'company'){
            require __DIR__ . '/controller/add-lowongan.php';
            exit();
        }
        header('Location: /login');
        break;

    case ($request === '/edit-lowongan'):
        if(isLoggedIn() && $_SESSION['role'] === 'company'){
            require __DIR__ . '/controller/edit-lowongan.php';
            exit();
        }
        header('Location: /login');
        break;

    case ($request === '/job-detail-company'):
        if(isLoggedIn() && $_SESSION['role'] === 'company'){
            require __DIR__ . '/controller/job-detail-company.php';
            exit();
        }
        header('Location: /login');
        break;

    case ($request === '/applicants-detail-company'):
        if(isLoggedIn() && $_SESSION['role'] === 'company'){
            require __DIR__ . '/controller/applicants-detail-company.php';
            exit();
        }
        header('Location: /login');
        break;
    
    case ($request === '/logout'):
        require __DIR__.'/controller/logout.php';
        break;
    
    case ($request === '/company'):
        require __DIR__.'/views/home-company.php';
        break;

    case ($request === '/flag-dashboard'):
        if(isLoggedIn() && $_SESSION['role'] === 'flag'){
            require __DIR__.'/views/flag-dashboard.php';
        }
        break;

    case ($request === '/edit-profile-company'):
        require __DIR__.'/controller/edit-profile-company.php';

        break;
    // Handle api routing
    case (strpos(strtok($request, '/'), 'api') === 0):
        require __DIR__.'/api/main_api.php';
        break;
    
    case ($request === '/debug'):
        print_r($_SESSION);
        break;

    // Handle dynamic route like /user/{id}
    case preg_match('#^/user/(\d+)$#', $request, $matches):
        $userId = $matches[1]; // Extracted user ID
        require __DIR__ . '/controller/user.php';
        break;
    
    default:
        http_response_code(404);
        require __DIR__ . '/controller/404.php';
        break;
}

?>
