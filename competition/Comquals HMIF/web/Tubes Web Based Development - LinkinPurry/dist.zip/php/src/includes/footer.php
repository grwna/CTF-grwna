<?php

$all_routes = ['/'];

?>

<link rel="stylesheet" href="/public/css/footer_style.css">

<footer>
    <div class="footer-links">
        <a href="#">About</a>
        <a href="#">Help Center</a>
        <a href="#">Contact Us</a>
    </div>
    <div class="footer-icons">
        <img src="/public/assets/linkinpurry.svg" alt="LinkedIn Logo" class="logo">
        <p>LinkedIn Corporation © 2024</p>
    </div>
</footer>