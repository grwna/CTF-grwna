<?php

$all_routes = ['/'];

?>

<link rel="stylesheet" href="/public/css/header-company.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:ital,wght@0,200..900;1,200..900&display=swap" rel="stylesheet">

<header>
    <nav>
        <div class="nav-logo-and-search">
            <a href="#"><img src="/public/assets/linkinpurry.svg" alt="LinkedIn Logo" id="logo-icon"></a>
            <!-- <div class="nav-search">
                <img src="/public/assets/search-icon.svg" alt="search" id="search-icon">
                <input class = "search-bar" type="text" placeholder="Search">
            </div> -->
        </div>
        <div class="menu-container-group">
            <a href="/company-dashboard" class="menu-container" id="nav-home">
                <img src="/public/assets/home-icon.svg" alt="home icon" id="home-icon">
                <p>Home</p>
            </a>
            <a href="/add-lowongan" class="menu-container" id="nav-post">
                <img src="/public/assets/jobpost-icon.svg" alt="post" id="post-icon">
                <p>Post a Job</p>
            </a>
            <!-- <a href="#" class="menu-container" id="nav-profile">
                <img src="/public/assets/company-profile.svg" alt="profile" id="profile-icon">
                <p>Company▼</p>
            </a> -->
            <button id="logout-btn" class="btn-logout">Logout</button>
        </div>
    </nav>
</header>

<div id="logoutModal" class="modal">
    <div class="modal-content-header">
        <p>Are you sure you want to log out?</p>
        <!-- <button id="confirmLogout" class="btn">Logout</button>
        <button id="cancelLogout" class="btn">Cancel</button> -->
        <button id="cancelLogout" class="btn-cancel">Cancel</button>
        <button id="confirmLogout" class="btn-confirm">Logout</button>
    </div>
</div>

<!-- JAVASCRIPT -->
<script>
    /* HOVER */
    /* Changing icon while hovering through each menu in navigation bar */
    document.addEventListener('DOMContentLoaded', function () {
        // Function to handle icon change on mouse hover and change back to its original icon on mouse leave
        function addHoverEffect(linkElement, iconElement, hoverSrc, originalSrc) {
            // Change icon on mouse enter
            linkElement.addEventListener('mouseenter', () => {
                iconElement.src = hoverSrc;
            });

            // Change back to original icon on mouse leave
            linkElement.addEventListener('mouseleave', () => {
                if (!linkElement.classList.contains('active')) {
                    iconElement.src = originalSrc;
                }
            });
        }

        // Get the icon and link elements
        const homeIcon = document.getElementById('home-icon');
        const homeLink = document.getElementById('nav-home');
        const postIcon = document.getElementById('post-icon');
        const postLink = document.getElementById('nav-post');

        // Call the function for each menu item
        addHoverEffect(homeLink, homeIcon, '/public/assets/home-hover.svg', '/public/assets/home-icon.svg');
        addHoverEffect(postLink, postIcon, '/public/assets/jobpost-hover.svg', '/public/assets/jobpost-icon.svg');


        /* ACTIVE */
        // Function to handle border-bottom addition when the link is active
        function setActiveIcon(iconId, newSrc) {
            const icon = document.getElementById(iconId);
            icon.src = newSrc;
        }

        /* Changing icon while active (current page matched to the menu hyperlink) on each menu in navigation bar */
        const currentPage = window.location.pathname;

        // Changing icon based on the current page
        if (currentPage.includes('/company-dashboard')) {
            // setActiveIcon('home-icon', '/public/assets/home-hover.svg');
            homeLink.classList.add('active');
            homeIcon.src = '/public/assets/home-hover.svg';
        } else if (currentPage.includes('/add-lowongan')) {
            // setActiveIcon('post-icon', '/public/assets/jobpost-hover.svg');
            postLink.classList.add('active');
            postIcon.src = '/public/assets/jobpost-hover.svg';
        }

        // Get all menu container links
        const menuItems = document.querySelectorAll('.menu-container');

        // Loop through each menu item and add a click event
        menuItems.forEach(item => {
            item.addEventListener('click', function() {
                menuItems.forEach(link => link.classList.remove('active'));
                
                // Add the active class to the clicked menu item
                this.classList.add('active');
            });
        });
        /* LOGOUT BUTTON */
        const logoutBtn = document.getElementById('logout-btn');
        const logoutModal = document.getElementById('logoutModal');
        const confirmLogout = document.getElementById('confirmLogout');
        const cancelLogout = document.getElementById('cancelLogout');

        // modal is hidden initially
        logoutModal.style.display = 'none';

        // show popup
        logoutBtn.addEventListener('click', function (event) {
            event.preventDefault();
            logoutModal.style.display = 'flex';
        });

        // confirm logout, redirect to /logout
        confirmLogout.addEventListener('click', function () {
            window.location.href = '/logout';
        });

        // cancel logout, hide modal
        cancelLogout.addEventListener('click', function () {
            logoutModal.style.display = 'none';
        });

        // close modal if clicking outside of the content
        window.addEventListener('click', function (event) {
            if (event.target === logoutModal) {
                logoutModal.style.display = 'none';
            }
        });
    });
</script>