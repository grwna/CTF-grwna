<?php require __DIR__.'/header.php'; ?>

<!-- CONTENT GOES HERE -->
<div class="container">
    
</div>

<?php require __DIR__.'/footer.php'; ?>