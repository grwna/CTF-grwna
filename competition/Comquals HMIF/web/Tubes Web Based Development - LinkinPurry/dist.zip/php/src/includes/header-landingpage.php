<?php

$all_routes = ['/'];

?>

<link rel="stylesheet" href="/public/css/header-landing.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:ital,wght@0,200..900;1,200..900&display=swap" rel="stylesheet">

<header>
    <div class="logo-container">
        <img src="/public/assets/linkinpurry.svg" alt="LinkedIn Logo" id="logo-icon">
    </div>
    <div class="nav-buttons">
        <div class="nav-home-container">
            <a href="#" class="menu-container" id="nav-home">
                <img src="/public/assets/home-icon.svg" alt="home" id="home-icon">
                <p>Home</p>
            </a>
        </div>
        <div class="auth-buttons">
            <a href="/signup" class="join-now">Join now</a>
            <a href="#" class="sign-in">Sign in</a>
        </div>
    </div>
</header>
<script>
    /* HOVER */
    /* Changing icon while hovering through each menu in navigation bar */

    // Function to handle icon change on mouse hover and change back to its original icon on mouse leave
    function addHoverEffect(linkElement, iconElement, hoverSrc, originalSrc) {
        // Change icon on mouse enter
        linkElement.addEventListener('mouseenter', () => {
            iconElement.src = hoverSrc;
        });

        // Change back to original icon on mouse leave
        linkElement.addEventListener('mouseleave', () => {
            iconElement.src = originalSrc;
        });
    }

    // Get the icon and link elements
    const homeIcon = document.getElementById('home-icon');
    const homeLink = document.getElementById('nav-home');

    // Call the function for each menu item
    addHoverEffect(homeLink, homeIcon, '/public/assets/home-hover.svg', '/public/assets/home-icon.svg');

    /* ACTIVE */
    // Function to handle border-bottom addition when the link is active
    function setActiveIcon(iconId, newSrc) {
        const icon = document.getElementById(iconId);
        icon.src = newSrc;
    }

    /* Changing icon while active (current page matched to the menu hyperlink) on each menu in navigation bar */
    const currentPage = window.location.pathname;

    // Changing icon based on the current page
    if (currentPage.includes('home.html')) {
        setActiveIcon('home-icon', '/public/assets/home-hover.svg');
    }

    // Get all menu container links
    const menuItems = document.querySelectorAll('.menu-container');

    // Loop through each menu item and add a click event
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            menuItems.forEach(link => link.classList.remove('active'));
            
            // Add the active class to the clicked menu item
            this.classList.add('active');
        });
    });
</script>