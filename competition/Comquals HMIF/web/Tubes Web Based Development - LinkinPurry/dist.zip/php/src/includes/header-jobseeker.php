<?php

$all_routes = ['/'];

?>

<link rel="stylesheet" href="/public/css/header-jobseek.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:ital,wght@0,200..900;1,200..900&display=swap" rel="stylesheet">

<header>
    <nav>
        <div class="nav-logo-and-search">
            <a href="#"><img src="/public/assets/linkinpurry.svg" alt="LinkedIn Logo" id="logo-icon"></a>
            <!-- <div class="nav-search">
                <img src="/public/assets/search-icon.svg" alt="search" id="search-icon">
                <input class="search-bar" type="text" placeholder="Search">
            </div> -->
        </div>
        <div class="menu-container-group">
            <!-- Add proper href for redirect -->
            <a href="/job-seeker" class="menu-container" id="nav-home">
                <img src="/public/assets/home-icon.svg" alt="home icon" id="home-icon">
                <p>Home</p>
            </a>
            <a href="/job-history" class="menu-container" id="nav-status">
                <img src="/public/assets/status-icon.svg" alt="status icon" id="status-icon">
                <p>Applications</p>
            </a>
            <!-- <a href="#" id="logout-btn" class="menu-container">
                <img src="/public/assets/linkinpurry.svg" alt="Logout" id="logout-icon">
                <p>Logout</p>
            </a> -->
            <button id="logout-btn" class="btn-logout">Logout</button>
        </div>
    </nav>
</header>

<div id="logoutModal" class="modal">
    <div class="modal-content">
        <p>Are you sure you want to log out?</p>
        <!-- <button id="confirmLogout" class="btn">Logout</button>
        <button id="cancelLogout" class="btn">Cancel</button> -->
        <button id="cancelLogout" class="btn-cancel">Cancel</button>
        <button id="confirmLogout" class="btn-confirm">Logout</button>
    </div>
</div>

<!-- JAVASCRIPT -->
<script>
    document.addEventListener('DOMContentLoaded', function () {

        /* HOVER EFFECT */
        function addHoverEffect(linkElement, iconElement, hoverSrc, originalSrc) {
            linkElement.addEventListener('mouseenter', () => iconElement.src = hoverSrc);
            linkElement.addEventListener('mouseleave', () => {
                if (!linkElement.classList.contains('active')) {
                    iconElement.src = originalSrc;
                }
            });
        }

        // Get the icon and link elements
        const homeIcon = document.getElementById('home-icon');
        const homeLink = document.getElementById('nav-home');
        const statusIcon = document.getElementById('status-icon');
        const statusLink = document.getElementById('nav-status');

        // Hover effects for icons
        addHoverEffect(homeLink, homeIcon, '/public/assets/home-hover.svg', '/public/assets/home-icon.svg');
        addHoverEffect(statusLink, statusIcon, '/public/assets/status-hover.svg', '/public/assets/status-icon.svg');

        /* ACTIVE ICON BASED ON CURRENT PAGE */
        const currentPage = window.location.pathname;

        // Change icon when on the home or applications page
        if (currentPage.includes('/job-seeker')) {
            homeLink.classList.add('active');
            homeIcon.src = '/public/assets/home-hover.svg'; // Keep it black as active
        } else if (currentPage.includes('/job-history')) {
            statusLink.classList.add('active');
            statusIcon.src = '/public/assets/status-hover.svg'; // Keep it black as active
        }

        /* CLICK EVENT TO ADD ACTIVE CLASS */
        const menuItems = document.querySelectorAll('.menu-container');
        menuItems.forEach(item => {
            item.addEventListener('click', function () {
                // Remove active class from all items
                menuItems.forEach(link => link.classList.remove('active'));

                // Add the active class to the clicked item
                this.classList.add('active');
            });
        });

        /* LOGOUT BUTTON */
        const logoutBtn = document.getElementById('logout-btn');
        const logoutModal = document.getElementById('logoutModal');
        const confirmLogout = document.getElementById('confirmLogout');
        const cancelLogout = document.getElementById('cancelLogout');

        // modal is hidden initially
        logoutModal.style.display = 'none';

        // show popup
        logoutBtn.addEventListener('click', function (event) {
            event.preventDefault();
            logoutModal.style.display = 'flex';
        });

        // confirm logout, redirect to /logout
        confirmLogout.addEventListener('click', function () {
            window.location.href = '/logout';
        });

        // cancel logout, hide modal
        cancelLogout.addEventListener('click', function () {
            logoutModal.style.display = 'none';
        });

        // close modal if clicking outside of the content
        window.addEventListener('click', function (event) {
            if (event.target === logoutModal) {
                logoutModal.style.display = 'none';
            }
        });

    });
</script>
