<?php

// require application model
require_once __DIR__.'/../../models/applications.php';

if($_SERVER['REQUEST_METHOD'] === 'GET'){
    $baseDir = 'uploads/video/';

    $file = $_GET['file'];
    $decodedFile = urldecode($file);

    $safeFile = basename($decodedFile);
    
    $filePath = $baseDir . $safeFile;
    if (!isset($_GET['vacancy_id'])){
        die('Vacancy ID not set');
    }

    $user_application = Application::getApplicationDetails($_SESSION['user_id'], $_GET['vacancy_id']);
    if(($user_application === false) || $user_application['video_path'] !== $filePath){
        header("HTTP/1.1 401 Unauthorized");
        header("Content-Type: text/html");
        die('Unauthorized Access');
    }

    if ($filePath === false || strpos($filePath, $baseDir) !== 0) {
        die('Invalid file path.');
    }

    $filePath = '/var/www/html/' . $filePath;

    if (!file_exists($filePath)) {
        die('File not found.');
    }

    $fileSize = filesize($filePath);
    $fileExtension = strtolower(pathinfo($safeFile, PATHINFO_EXTENSION));

    // MIME type for video files
    $mimeTypes = [
        'mp4' => 'video/mp4',
    ];

    $contentType = $mimeTypes[$fileExtension] ?? 'application/octet-stream';

    header('Content-Type: ' . $contentType);
    header('Content-Disposition: inline; filename="' . $safeFile . '"');
    header('Content-Transfer-Encoding: binary');

    if (isset($_SERVER['HTTP_RANGE'])) {
        $range = $_SERVER['HTTP_RANGE'];
        $range = str_replace('bytes=', '', $range);
        $range = explode('-', $range);
        $start = intval($range[0]);
        $end = $range[1] !== '' ? intval($range[1]) : $fileSize - 1;
        
        header('HTTP/1.1 206 Partial Content');
        header('Content-Range: bytes ' . $start . '-' . $end . '/' . $fileSize);
        header('Content-Length: ' . ($end - $start + 1));
        
        $fp = fopen($filePath, 'rb');
        fseek($fp, $start);
        $bufferSize = 1024 * 8; // 8KB buffer
        while(!feof($fp) && ($pos = ftell($fp)) <= $end){
            if($pos + $bufferSize > $end){
                $bufferSize = $end - $pos + 1;
            }
            echo fread($fp, $bufferSize);
            flush();
        }
        fclose($fp);
    } else {
        // serve the full video if no range is specified
        header('Content-Length: ' . $fileSize);
        readfile($filePath);
    }
    
    exit();
}

?>
