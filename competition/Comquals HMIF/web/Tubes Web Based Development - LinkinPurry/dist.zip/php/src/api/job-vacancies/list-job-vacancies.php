<?php
/**
 * API TO HANDLE List Job Vacancies
 */

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    $search = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : null;
    $jobType = isset($_GET['jobType']) ? htmlspecialchars($_GET['jobType']) : null;
    $locationType = isset($_GET['locationType']) ? htmlspecialchars($_GET['locationType']) : null;
    $sortBy = isset($_GET['sortBy']) ? $_GET['sortBy'] : 'desc'; // Default to 'desc'

    if($search === '') $search = null;
    if($jobType === '') $jobType = null;
    if($locationType === '') $locationType = null;
    if($sortBy === '') $sortBy = null;

    // Check if all parameters are null (no filters applied)
    if ($search === null && $jobType === null && $locationType === null && $sortBy === null) {
        http_response_code(200);
        
        echo json_encode([]); // Return an empty array when no filters are applied
        exit();
    }

    $db = dbConnect();
    $query = "
    SELECT
        v.vacancy_id,
        u.user_id as company_id,
        u.name as company_name,
        v.position,
        v.description,
        v.job_type,
        v.location_type,
        v.created_at
    from job_vacancies v
    JOIN users u
    ON v.company_id = u.user_id
    WHERE is_open = TRUE";

    // Add filters based on parameters
    if ($jobType) {
        $query .= " AND LOWER(job_type) = :jobType";
    }
    if ($locationType) {
        $query .= " AND LOWER(location_type) = :locationType";
    }
    if ($search) {
        $query .= " AND LOWER(position) LIKE :search"; // Use placeholders to prevent SQL injection
    }
    if ($sortBy) {
        $query .= " ORDER BY $sortBy DESC";
    }

    // Prepare the SQL statement
    $stmt = $db->prepare($query);

    if ($search) {
        $stmt->bindValue(':search', '%'.$search.'%', PDO::PARAM_STR);
    }
    if ($jobType) {
        $stmt->bindParam(':jobType', $jobType);
    }
    if ($locationType) {
        $stmt->bindValue(':locationType', $locationType);
    }
    
    
    // Execute the query
    $stmt->execute();

    // Fetch the results
    $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($jobs);
    
    $db = null;
    exit();
}

?>