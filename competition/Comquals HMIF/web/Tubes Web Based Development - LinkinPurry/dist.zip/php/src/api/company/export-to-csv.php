<?php

require_once __DIR__.'/../../models/applications.php';
require_once __DIR__.'/../../models/company.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // check only the current logged in company export its own applicant data
    if(!isset($_GET['vacancy_id']) || $_GET['vacancy_id'] === ''){
        die('Vacancy ID not set');
    }
    
    $vacancy_id = $_GET['vacancy_id'];
    
    // verify if the vacancy_id belong to the company_id
    $vacancyDetail = JobModel::getJobVacancyById($vacancy_id);

    if($vacancyDetail['company_id'] !== $_SESSION['user_id']){
        header("HTTP/1.1 401 Unauthorized");
        exit();
    }
    
    $data = Application::getApplicationsByVacancyId($vacancy_id);

    // print_r($data);
    // print_r(array_keys($data));
    // Set the headers for downloading the file
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename="exported_data.csv"');
    // Open output stream
    $output = fopen('php://output', 'w');

    // if (!empty($data)){
    //     print_r(array_keys($data));
    //     foreach ($data as $row){
    //         print_r($row);
    //         echo '\n';
    //     }
    // }

    // Output column headers (optional)
    if (!empty($data)) {
        // Output column headers using the keys from the first row
        fputcsv($output, array_keys($data[0]));
        
        // Output each row
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
    }
    // Close the file handle
    fclose($output);
    exit();
}

?>