<?php

// require applicaiton model
require_once __DIR__.'/../../models/attachment.php';

if($_SERVER['REQUEST_METHOD'] === 'GET'){
    $baseDir = 'uploads/company/';

    if (!isset($_GET['vacancy_id'])){
        die('Vacancy ID not set');
    }

    $vacancyId = $_GET['vacancy_id'];

    // retrieve all attachment
    $attachments = AttachmentModel::getVacancyAttachments($vacancyId);

    $imageNames = [];

    // Extract image names
    foreach ($attachments as $image) {
        $imageNames[] = basename($image['file_path']); // Only the filename, not the path
    }


    echo json_encode($imageNames);
    exit();
}

?>