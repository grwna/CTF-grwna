<?php
/**
 * API TO HANDLE List Applicants for a Job Vacancy with pagination
 */

require_once __DIR__."/../../models/job.php";
require_once __DIR__."/../../models/applications.php";

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // jumlah applicants per halaman
    $applicantsPerPage = 4;

    // get halaman saat ini dari query string (default halaman 1)
    $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($currentPage - 1) * $applicantsPerPage;

    $vacancyId = isset($_GET['vacancy_id']) ? (int)$_GET['vacancy_id'] : null;

    if ($vacancyId === null) {
        // handle the error, return a response indicating the vacancyId is missing
        http_response_code(400);
        echo json_encode(['error' => 'vacancyId is required']);
        exit();
    }

    $totalApplicants = JobModel::getTotalApplicantsByVacancyId($vacancyId); 

    // hitung jumlah total halaman
    $totalPages = ceil($totalApplicants / $applicantsPerPage);

    // ambil data applicants untuk halaman saat ini
    $applicants = JobModel::getJobApplicantsDataByVacancyId($vacancyId, $offset, $applicantsPerPage);

    foreach ($applicants as $applicant) {
        $applicantId = $applicant['application_id'];
    }

    $applicants['current-page'] = $currentPage;
    $applicants['total-pages'] = $totalPages;

    echo json_encode($applicants);
    exit();
}