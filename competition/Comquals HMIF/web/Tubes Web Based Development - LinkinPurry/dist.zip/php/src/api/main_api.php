<?php

require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../controller/auth-controller.php';

header('Content-Type: application/json');

// Use parse_url to extract the path from the current URL
$request = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

switch ($request) {
    case '/api/list-job-vacancies':
        require __DIR__.'/job-vacancies/list-job-vacancies.php';
        break;

    case '/api/list-job-pagination':
        require __DIR__.'/job-vacancies/list-job-vacancies-pagination.php';
        break;

    case '/api/get-cv':
        if (isLoggedIn()) {
            require __DIR__.'/file-handling/get-pdf.php';
        } else {
            header('Location: /login');
        }
        break;

    case '/api/get-video':
        if (isLoggedIn()) {
            require __DIR__.'/file-handling/get-video.php';
        } else {
            header('Location: /login');
        }
        break;

    case '/api/company-job-list':
        if (isLoggedIn() && $_SESSION['role'] === 'company') {
            require __DIR__.'/company/company-list-job-pagination.php';
        } else {
            header('Location: /login');
        }
        break;

    case '/api/list-applicants-pagination':
        if (isLoggedIn() && $_SESSION['role'] === 'company') {
            require __DIR__.'/company/list-applicants-pagination.php';
        } else {
            header('Location: /login');
        }
        break;

    case '/api/get-cv-for-company':
        if (isLoggedIn()) {
            require __DIR__.'/file-handling/get-pdf-for-company.php';
        } else {
            header('Location: /login');
        }
        break;

    case '/api/get-attachment-name':
        require __DIR__.'/file-handling/get-attachment.php';
        break;

    case '/api/get-attachment-blob':
        require __DIR__.'/file-handling/get-blob-attachment.php';
        break;
    

    case '/api/get-video-for-company':
        if (isLoggedIn()) {
            require __DIR__.'/file-handling/get-video-for-company.php';
        } else {
            header('Location: /login');
        }
        break;

    case '/api/export-csv':
        if (isLoggedIn() && $_SESSION['role'] === 'company') {
            require __DIR__.'/company/export-to-csv.php';
        }
        break;

    case '/api/get-jobs-recommendation':
        require __DIR__.'/job-vacancies/top-job-recommended.php';
        break;

    default:
        header('Content-Type: text/html');
        require __DIR__.'/../controller/404.php';
        exit();
}

?>
