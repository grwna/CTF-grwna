<?php
/**
 * API TO HANDLE List Job Vacancies with pagination
 */

require_once __DIR__."/../../models/job.php";

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    //  jumlah lowongan per halaman
    $jobsPerPage = 6;

    // get halaman saat ini dari query string (default halaman 1)
    $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($currentPage - 1) * $jobsPerPage;

    // HANDLE FILTERING
    $search = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : null;
    $jobTypes = isset($_GET['jobType']) ? htmlspecialchars($_GET['jobType']) : [];
    $locationTypes = isset($_GET['locationType']) ? htmlspecialchars($_GET['locationType']) : [];
    $sortBy = isset($_GET['sortBy']) ? htmlspecialchars($_GET['sortBy']) : 'desc'; // Default to 'desc'

    if($search === '') $search = null;
    if($jobTypes === '') $jobType = null;
    if($locationTypes === '') $locationType = null;
    if($sortBy === '') $sortBy = null;

    // Check if all parameters are null (no filters applied)
    if ($search === null && $jobTypes === null && $locationTypes === null) {
        // ambil total jumlah pekerjaan untuk pagination
        $totalJobs = JobModel::getTotalJobVacancies($_SESSION['user_id']);
        
        // hitung jumlah total halaman
        $totalPages = ceil($totalJobs / $jobsPerPage);

        // ambil data lowongan kerja untuk halaman saat ini
        $jobVacancies = JobModel::getJobVacancies($offset, $jobsPerPage, $_SESSION['user_id']);

        // group job berdasarkan company_id
        $groupedJobs = [];
        foreach ($jobVacancies as $job) {
            $companyId = $job['company_id'];
            $groupedJobs[$companyId]['company_name'] = $job['company_name'];
            $groupedJobs[$companyId]['jobs'][] = $job;
        }

        $groupedJobs['current-page'] = $currentPage;
        $groupedJobs['total-pages'] = $totalPages;

        echo json_encode($groupedJobs);
        exit();
    } 

    

    // filter first then return it
    $jobVacancies = JobModel::getJobVacanciesFiltered($offset, $jobsPerPage, $search, $jobTypes, $locationTypes, $sortBy, $_SESSION['user_id']);

    // ambil total jumlah pekerjaan untuk pagination
    $totalJobs = JobModel::getTotalJobVacanciesFiltered($search, $jobTypes, $locationTypes, $_SESSION['user_id']);

    // hitung jumlah total halaman
    $totalPages = ceil($totalJobs / $jobsPerPage);

    $groupedJobs = [];
    foreach ($jobVacancies as $job) {
        $companyId = $job['company_id'];
        $groupedJobs[$companyId]['company_name'] = $job['company_name'];
        $groupedJobs[$companyId]['jobs'][] = $job;
    }
    
    $groupedJobs['current-page'] = $currentPage;
    $groupedJobs['total-pages'] = $totalPages;
    echo json_encode($groupedJobs);

    exit();
}

?>