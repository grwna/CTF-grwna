<?php
// Private images directory
$imagesDir = '/var/www/html/uploads/company/';

if (isset($_GET['name'])) {
    $imageName = basename($_GET['name']); // Sanitize input
    $imagePath = $imagesDir . $imageName;

    if (file_exists($imagePath)) {
        // Get file contents and encode to Base64
        $imageData = base64_encode(file_get_contents($imagePath));
        $mimeType = mime_content_type($imagePath);

        // Return JSON response with the Base64 data and MIME type
        header('Content-Type: application/json');
        echo json_encode([
            'mime' => $mimeType,
            'data' => 'data:' . $mimeType . ';base64,' . $imageData
        ]);
        exit();
    }
}

http_response_code(404);
echo json_encode(['error' => 'Image not found']);
?>
