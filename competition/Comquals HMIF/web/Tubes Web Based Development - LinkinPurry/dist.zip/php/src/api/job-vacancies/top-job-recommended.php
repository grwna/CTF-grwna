<?php

// include job model
require_once __DIR__.'/../../models/job.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    $limit = isset($_GET['limit']) ?htmlspecialchars($_GET['limit']) : null;
    $jobs = JobModel::getJobVacancyTopRecommended($limit);

    echo json_encode($jobs);
    exit();
}

?>