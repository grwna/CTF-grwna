<?php

// require applicaiton model
require_once __DIR__.'/../../models/applications.php';
require_once __DIR__.'/../../models/company.php';

if($_SERVER['REQUEST_METHOD'] === 'GET'){
    $baseDir = 'uploads/cv/';

    $file = $_GET['file'];
    $decodedFile = urldecode($file);  // Ensure that URL-encoded characters are decoded

    // Strip any directory traversal components

    $safeFile = basename($decodedFile);
    
    $filePath = $baseDir . $safeFile;
    if (!isset($_GET['vacancy_id'])){
        die('Vacancy ID not set');
    }

    // Validate Input With Database
    $user_application = CompanyModel::getCompanyById($_SESSION['user_id']);
    $company_profile = CompanyModel::getCompanyByVacancyId($_GET['vacancy_id']);

    if($user_application['company_id'] !== $company_profile['company_id']){
        header("HTTP/1.1 401 Unauthorized");
        header("Content-Type: text/html");
        die('Unauthorized Access');
    }

    // Ensure the file exists and is within the allowed directory
    if ($filePath === false || strpos($filePath, $baseDir) !== 0) {
        die('Invalid file path.');
    }

    $filePath = '/var/www/html/' . $filePath;

    // Serve the file safely
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . $safeFile . '"');
    header('Content-Transfer-Encoding: binary');
    header('Content-Length: ' . filesize($filePath));
    readfile($filePath);
    
    // $fp = fopen($filePath, "r") ;
    
    // ob_clean();
    // flush();
    // while (!feof($fp)) {
    //     $buff = fread($fp, 512);
    //     print $buff;
    // }
    exit();
}

?>