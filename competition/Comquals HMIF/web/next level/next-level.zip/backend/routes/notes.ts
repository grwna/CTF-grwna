import express from "express"
import { Note } from "../models/Note"
import { Request, Response, NextFunction } from "express"
import { InternalConfig } from "../models/InternalConfig"
import { JwtPayload } from "jsonwebtoken"

interface AuthenticatedRequest extends Request {
  user: string | JwtPayload
}

const router = express.Router()

router.post("/", async (req: Request, res: Response) => {
  try {
    const { title, content, isPrivate } = req.body as {
      title: string
      content: string
      isPrivate: boolean
    }
    const user = (req as AuthenticatedRequest).user
    const note = new Note({
      title,
      userId: (user as JwtPayload).userId,
      content,
      isPrivate,
    })
    await note.save()
    res.status(201).json(note)
  } catch (error) {
    res.status(400).json({ error: "Failed to create note" })
  }
})

router.get("/", async (req: Request, res: Response) => {
  try {
    const user = (req as AuthenticatedRequest).user

    const notes = await Note.find({
      $or: [
        { userId: (user as JwtPayload).userId },
        { sharedWith: (user as JwtPayload).userId },
      ],
    })
    res.json(notes)
  } catch (error) {
    res.status(400).json({ error: "Failed to fetch notes" })
  }
})

router.get("/internal/config", async (req: Request, res: Response) => {
  // Vulnerable endpoint - no proper authorization check
  // This is what attackers need to find and access
  const config = await InternalConfig.findOne()
  res.json(config)
})

export default router
