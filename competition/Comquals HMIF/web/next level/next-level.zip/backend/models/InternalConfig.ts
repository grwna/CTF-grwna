import mongoose from "mongoose"

const internalConfigSchema = new mongoose.Schema({
  apiKeys: {
    stripe: { type: String, required: true },
    sendgrid: { type: String, required: true },
  },
  databaseCredentials: {
    username: { type: String, required: true },
    password: { type: String, required: true },
  },
  flag: { type: String, required: true },
  lastUpdated: { type: Date, default: Date.now },
})

export const InternalConfig = mongoose.model(
  "InternalConfig",
  internalConfigSchema
)
