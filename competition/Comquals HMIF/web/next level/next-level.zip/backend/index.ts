import express from "express"
import mongoose from "mongoose"
import cors from "cors"
import authRoutes from "./routes/auth"
import notesRoutes from "./routes/notes"

const app = express()

app.use(cors())
app.use(express.json())

app.use("/api/auth", authRoutes)
app.use("/api/notes", notesRoutes)

// Initialize internal config with secret data
async function initializeInternalConfig() {
  const InternalConfig = mongoose.model("InternalConfig")
  const exists = await InternalConfig.findOne()
  if (!exists) {
    await InternalConfig.create({
      apiKeys: {
        stripe: "sk_live_51secret",
        sendgrid: "SG.secretkey",
      },
      databaseCredentials: {
        username: "admin_user",
        password: "super_secret_db_pass",
      },
      flag: "CTFITB{REDACTED}",
    })
  }
}

mongoose
  .connect(process.env.MONGODB_URI!)
  .then(() => {
    console.log("Connected to MongoDB")
    initializeInternalConfig()
    app.listen(4000, () => {
      console.log("Backend API running on port 4000")
    })
  })
  .catch(console.error)
