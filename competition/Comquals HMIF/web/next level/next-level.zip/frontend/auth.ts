import NextAuth from "next-auth"
import Credentials from "next-auth/providers/credentials"
import { z } from "zod"
import crypto from "crypto"

export const { auth, signIn, signOut } = NextAuth({
  providers: [
    Credentials({
      async authorize(credentials) {
        const parsedCredentials = z
          .object({
            email: z.string().email(),
            password: z.string().min(8),
          })
          .safeParse(credentials)

        if (!parsedCredentials.success) {
          return null
        }

        // Simulated verification
        const verificationToken = crypto.randomBytes(32).toString("hex")
        return { id: verificationToken, email: parsedCredentials.data.email }
      },
    }),
  ],
})
