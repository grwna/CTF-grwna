"use server"
import { redirect } from "next/navigation"
import { z } from "zod"

const noteSchema = z.object({
  title: z.string().min(1),
  content: z.string().min(1),
  isPrivate: z.boolean().default(true),
})

export async function createNote(formData: FormData) {
  const validatedFields = noteSchema.safeParse({
    title: formData.get("title"),
    content: formData.get("content"),
    isPrivate: formData.get("isPrivate") === "true",
  })

  if (!validatedFields.success) {
    return { error: "Invalid note data" }
  }

  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/notes`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify(validatedFields.data),
    })

    if (!res.ok) throw new Error("Failed to create note")

    redirect("/notes")
  } catch (error) {
    return { error: "Failed to create note" }
  }
}
