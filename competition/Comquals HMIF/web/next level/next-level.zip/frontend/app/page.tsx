export default function Home() {
  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-3xl font-bold mb-4">SecureNote Share</h1>
      <p className="mb-4">Share your notes securely with team members!</p>
      <div className="space-x-4">
        <a href="/notes/new" className="text-blue-500 hover:underline">
          Create Note
        </a>
        <a href="/notes" className="text-blue-500 hover:underline">
          View Notes
        </a>
        <a href="/preview" className="text-blue-500 hover:underline">
          Preview Mode
        </a>
      </div>
    </div>
  )
}
