import { redirect } from "next/navigation"

export default function PreviewPage() {
  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-2xl font-bold mb-4">Note Preview</h1>
      <form
        action={async () => {
          "use server"

          // Simplified vulnerable redirect
          // This makes it easier to exploit as it doesn't process any form data
          redirect("/api/preview")
        }}
      >
        <div className="space-y-4">
          <textarea
            name="content"
            className="w-full border p-2 rounded h-32"
            placeholder="Enter note content to preview..."
          />
          <button
            type="submit"
            className="bg-green-500 text-white px-6 py-2 rounded"
          >
            Generate Preview
          </button>
        </div>
      </form>
    </div>
  )
}
